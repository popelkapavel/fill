﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;


namespace grcol {
    public struct fillres {
      public int x0,y0,x1,y1,m;
    }
    public class Shape {
      public int[] pts;
      public bool[] move;
      
      public Shape(int len) { pts=new int[len];}      
      public Shape(Shape src) { 
        if(src.pts!=null) pts=src.pts.Clone() as int[];
        if(src.move!=null) move=src.move.Clone() as bool[];
      }
      public static int[] BoundingBox(int[] pts) {
        if(pts==null||pts.Length<2) return null;
        int[] bb=new int[4];
        bb[0]=bb[2]=pts[0];bb[1]=bb[3]=pts[1];
        for(int i=2;i<pts.Length;i++) {
          if(pts[i]<bb[0]) bb[0]=pts[i];else if(pts[i]>bb[2]) bb[2]=pts[i];
          i++;
          if(pts[i]<bb[1]) bb[1]=pts[i];else if(pts[i]>bb[3]) bb[3]=pts[i];
        }
        return bb;
      }
      public static void Move(int[] pts,int dx,int dy) {
        if(pts==null) return;
        for(int i=0;i<pts.Length;i++)
          pts[i]+=0==(i&1)?dx:dy;
      }
    }    

    public class bmap {
      public int Width,Height;
      public int[] Data; //r,g,b,h
      public const int White=0xffffff,Black=0;
      public static readonly int[] sqrt=new int[1048677];      

      public override string ToString() {
        return ""+Width+"x"+Height;
      }
      
      static bmap() {
        int j=0,j2=0;
        for(int i=0;i<sqrt.Length;i++) {
          if(j2<=i) {j2+=2*j+1;j++;}
          sqrt[i]=j-1;
        }
      }
      public static int isqrt(int x) {
        if(x<1) return 0;
        else if(x<sqrt.Length) return sqrt[x];
        else return (int)Math.Sqrt(x);
      }
      public static int isqrt(int x,int y) {
        return isqrt(x*x+y*y);
      }
      public static int sabs(int x,int y) { return Math.Abs(x)+Math.Abs(y);}
      public int isqrt2(int x) {
        uint a,a2;
        if(x<4) return x>0?1:0;
        a=(uint)(x>>(bitscan(x)>>1));
        do {
          a2=a;
          a=(uint)(a2+x/a2)>>1;
        } while(a<a2);
        return (int)a2;
      }
      public static int idiv(int x,int div) {
        if(div<0) {x=-x;div=-div;}
        if(x>=0) return x/div;
        int r=x/div;
        return x==r*div?r:r-1;
      }
      public static int ceil(int x,int div) {
        if(div<2) return x;
        int r=x%div;
        return r==0?x:x-r+div;
      }
      public static int floor(int x,int div) {
        return div>1?x-x%div:x;
      }
      public static int modp(int x,int div) {
        if(div<2) return 0;
        x=x%div;
        if(x<0) x+=div;
        return x;
      }
      public static int round(int x,int div) {
        if(div<2) return 0;
        int r=x%div;
        if(2*r<div) x-=r;else x+=div-r;
        return x;
      }       

      
      public bmap() {}
      public bmap(int width,int height) {Alloc(width,height);}
      public bmap(bmap src,int x,int y,int x2,int y2,int extent) {
        int w=x2-x+1+extent,h=y2-y+extent;
        Alloc(w,h);
        if(src!=null) CopyRectangle(src,x,y,x2,y2,extent,extent,-1);
      }
      public bmap(string brush) {
        string[] line=brush.Split('.');
        Width=line[0].Length;Height=line.Length;
        Alloc(Width,Height);
        for(int y=0;y<Height;y++) {
          string l=line[y];
          for(int x=0;x<l.Length;x++)
            Data[y*Width+x]=l[x]!='0'?White:0;
        }
      }      
      public bmap(bmap src) {Copy(src);}
      public bmap Clone() { return new bmap(this);}
      public void Copy(bmap src) {
        if(src==null) return;
        Data=src.Data.Clone() as int[];
        Width=src.Width;Height=src.Height;
      }
      public void Alloc(int width,int height) {        
        Data=new int[(Width=width)*(Height=height)];
      }
      public int XY(int x,int y) {
        if(x<0||y<0||x>=Width||y>=Height) return -1;
        return Data[y*Width+x];
      }
      public void XY(int x,int y,int color) {
        if(x<0||y<0||x>=Width||y>=Height) return;
        Data[y*Width+x]=color;
      }
      public void XY(int x,int y,int color,bool whiteonly) {
        if(x<0||y<0||x>=Width||y>=Height) return;
        if(!whiteonly||(Data[y*Width+x]&0xffffff)==White)
          Data[y*Width+x]=color;
      }
      
      public void Brush(int x,int y,int color,bmap brush,bool whiteonly) {
        if(brush==null) { XY(x,y,color,whiteonly);return;}
        int bx=brush.Width/2,by=brush.Height/2;
        if(x<-brush.Width||y<-brush.Height||x>=Width+brush.Width||y>=Height+brush.Height) return;
        for(int i=0;i<brush.Height;i++) {
          int dy=y+i-by;
          if(dy<0||dy>=Height) continue;
          for(int j=0;j<brush.Width;j++) {
           int dx=x+j-bx;
           if(dx<0||dx>=Width) continue;
           if(brush.Data[i*brush.Width+j]!=0) 
             if(!whiteonly||(Data[dy*Width+dx]&0xffffff)==White) Data[dy*Width+dx]=color;
          }
        }
      }

      public void LeaveBlack() {
        for(int i=0;i<Data.Length;i++) {
          int x=Data[i]&White;
          if(x!=0&&x!=White) Data[i]=White;
        }
      }      
      public void FillRectangle(int x,int y,int x2,int y2,int color) {
        int r;
        if(x2<x) {r=x;x=x2;x2=r;}
        if(y2<y) {r=y;y=y2;y2=r;}
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        if(x<0) x=0;if(x2>=Width) x2=Width-1;
        if(y<0) y=0;if(y2>=Height) y2=Height-1;
        int h=y*Width+x,n=x2-x+1;
        while(y<=y2) {
          for(int he=h+n;h<he;h++) Data[h]=color;
          h+=Width-n;
          y++;
        }        
      }
			public void SmartSelect(int[] rect) {
			  R.Norm(rect);
				R.Intersect(rect,0,0,Width-1,Height-1);			
				if(rect[0]==rect[2]||rect[1]==rect[3]) return;
				int c=White&(Data[rect[1]*Width+rect[0]]),x,y;
				while(rect[0]<rect[2]) {
					for(y=rect[1];y<=rect[3];y++)
					  if((Data[y*Width+rect[0]]&White)!=c) break;
				  if(y>rect[3]) rect[0]++;else break;
				}
				while(rect[0]<rect[2]) {
					for(y=rect[1];y<=rect[3];y++)
					  if((Data[y*Width+rect[2]]&White)!=c) break;
				  if(y>rect[3]) rect[2]--;else break;
				}
				while(rect[1]<rect[3]) {
					for(x=rect[0];x<=rect[2];x++)
					  if((Data[rect[1]*Width+x]&White)!=c) break;
				  if(x>rect[2]) rect[1]++;else break;
				}
				while(rect[1]<rect[3]) {
					for(x=rect[0];x<=rect[2];x++)
					  if((Data[rect[3]*Width+x]&White)!=c) break;
				  if(x>rect[2]) rect[3]--;else break;
				}
			}
      public void Erase(int x,int y,int x2,int y2,bool dox,bool doy) { Erase(x,y,x2,y2,dox?doy?0:1:doy?2:0);}
			public void Erase(int x,int y,int x2,int y2,int mode) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
				int width=x2-x+1,height=y2-y+1;
        int y0=y<1?0:y-1,y1=y2+1<Height?y2+1:y2;
        int x0=x<1?0:x-1,x1=x2+1<Width?x2+1:x2;
        int dx=2*(x2-x+1),dy=2*(y2-y+1);
        for(int iy=y;iy<=y2;iy++) {
          int cy=Data[iy*Width+x0],cy2=Data[iy*Width+x1];
          for(int ix=x;ix<=x2;ix++) {
					  int c;						
					  if(mode>=3) {
							int _x=ix-x,_y=iy-y,w1=width+1,h1=height+1,_x2=(_y+1)*w1,_y2=(_x+1)*h1,cx2;
							int xa,ya,xb,yb,xc,yc,xd,yd,ca,cb,cc,cd,ab;
							if((width-_x)*height>=width*(_y+1)) {
								xa=(h1*(_x+1)+_x2)/h1;ya=0;xb=0;yb=(w1*(_y+1)+_y2)/w1;ab=xa+yb<1?128:(_x+1+yb-_y)*255/(xa+yb);
							} else {
								xa=w1;ya=(w1*(_y+1-h1)+_y2)/w1;xb=(h1*(_x+1-w1)+_x2)/h1;yb=h1;ab=width-xb+height-ya<1?128:(_x+1-xb+height-_y)*255/(width-xb+height-ya);
							}
							if(xa<0) xa=0;else if(xa>w1) xa=w1;
							if(xb<0) xb=0;else if(xb>w1) xb=w1;
							if(ya<0) ya=0;else if(ya>h1) ya=h1;
							if(yb<0) yb=0;else if(yb>h1) yb=h1;
							ca=Data[(y+ya-1)*Width+x+xa-1];cb=Data[(y+yb-1)*Width+x+xb-1];
							c=Palette.ColorMix(cb,ca,ab,255);

							if((_x+1)*height<width*(_y+1)) {
								xc=0;yc=(w1*(_y+1)-_y2)/w1;xd=(h1*(_x+1+w1)-_x2)/h1;yd=h1;ab=xd+height-yc<1?128:(_x+1+_y-yc)*255/(xd+height-yc);
							} else {
								xc=(h1*(_x+1)-_x2)/h1;yc=0;xd=w1;yd=(w1*(_y+1+h1)-_y2)/w1;ab=width-xc+yd<1?128:(_x-xc+_y+1)*255/(width-xc+yd);
							}
							if(xc<0) xa=0;else if(xa>w1) xa=w1;
							if(xd<0) xd=0;else if(xd>w1) xd=w1;
							if(yc<0) yc=0;else if(yc>h1) yc=h1;
							if(yd<0) yd=0;else if(yd>h1) yd=h1;
							cc=Data[(y+yc-1)*Width+x+xc-1];cd=Data[(y+yd-1)*Width+x+xd-1];
							cx2=Palette.ColorMix(cc,cd,ab,255);
							if(mode!=3) c=mode==4?cx2:Palette.ColorMix(c,cx2,128,255);
						} else {
						  bool dox=mode<2,doy=mode!=1;
              int cx=Data[y0*Width+ix],cx2=Data[y1*Width+ix];
              cx=doy?Palette.ColorMix(cx,cx2,2*(iy-y)+1,dy):0;
              cx2=dox?Palette.ColorMix(cy,cy2,2*(ix-x)+1,dx):0;
							c=Palette.ColorMix(cx,cx2,1-(dox?0:1)+(doy?0:1),2);
						}
            Data[iy*Width+ix]=c;
          }
        }        
      }
			public void BW(int x,int y,int x2,int y2,int minmax,int blacklevel) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        for(int iy=y;iy<=y2;iy++) 
          for(int ix=x;ix<=x2;ix++) {
					  int c=Data[iy*Width+ix];
						int r=c&255,g=(c>>8)&255,b=(c>>16)&255;
						if(minmax<0) r=r<g?r<b?r:b:g<b?g:b;
						else if(minmax>0) r=r>g?r>b?r:b:g>b?g:b;
						else r=(r+g+b)/3;
						Data[iy*Width+ix]=r<blacklevel?0:White;
					}			  
			}
			public void Gray(int x,int y,int x2,int y2,int minmax) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        for(int iy=y;iy<=y2;iy++) 
          for(int ix=x;ix<=x2;ix++) {
					  int c=Data[iy*Width+ix];
						int r=c&255,g=(c>>8)&255,b=(c>>16)&255;
						if(minmax<0) r=r<g?r<b?r:b:g<b?g:b;
						else if(minmax>0) r=r>g?r>b?r:b:g>b?g:b;
						else r=(r+g+b)/3;
						Data[iy*Width+ix]=r|(r<<8)|(r<<16);
					}			  
			}
      public void MoveRectangle(int x,int y,int x2,int y2,int dx,int dy,int bgcolor,int trcolor,bool cs) {
        int w=x2-x+1,h=y2-y+1;
        bmap bm2=new bmap(w,h);
        bm2.Clear(bgcolor);
        bm2.CopyRectangle(this,x,y,x2,y2,0,0,-1);
        if(bgcolor!=-1) FillRectangle(x,y,x2,y2,bgcolor);
        if(cs) {
          if(x>dx&&y==dy) CopyRectangle(this,dx,y,x-1,y2,x2+dx-x+1,y,-1);
          if(x<dx&&y==dy) CopyRectangle(this,x2+1,y,x2+dx-x,y2,x,y,-1);
          if(dx==x&&y>dy) CopyRectangle(this,x,dy,x2,y-1,x,y2+dy-y+1,-1);
          if(dx==x&&y<dy) CopyRectangle(this,x,y2+1,x2,y2+dy-y,x,y,-1);
        }
        CopyRectangle(bm2,0,0,w-1,h-1,dx,dy,trcolor);
      }
      public void MoveRectangle(int x,int y,int x2,int y2,int dx,int dy,bmap back) {
        int a=x,b=y;
        IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        dx+=x-a;dy+=y-b;
        int dx2=dx+x2-x,dy2=dy+y2-y;
        a=dx;b=dy;
        IntersectRect(ref dx,ref dy,ref dx2,ref dy2,0,0,Width-1,Height-1);
        if(dx>=Width||dy>=Height||dx2<0||dy2<0) return;
        x+=dx-a;y+=dy-b;x2=x+dx2-dx;y2=y+dy2-dy;
        
        int w=x2-x+1,h=y2-y+1;
        bmap bm2=new bmap(w,h);
        bm2.CopyRectangle(this,x,y,x2,y2,0,0,-1);
        if(back!=null) CopyRectangle(back,x,y,x2,y2,x,y,-1);
        CopyRectangle(bm2,0,0,w-1,h-1,dx,dy,-1);
      }      
      
      public void CopyRectangle(bmap src,int x,int y,int x2,int y2,int dx,int dy,int trcolor) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(dx<0) {x-=dx;dx=0;};if(dy<0) {y-=dy;dy=0;}
        if(x<0) {dx-=x;x=0;} else if(x2>=src.Width) x2=src.Width-1;
        if(y<0) {dy-=y;y=0;} else if(y2>=src.Height) y2=src.Height-1;
        if(x2<0||y2<0||x>x2||y>y2||dx>=Width||dy>=Height) return;
        if(dx+x2-x>=Width) x2=x+Width-dx-1;
        if(dy+y2-y>=Height) y2=y+Height-dy-1;
        int n=x2-x+1,g=dy*Width+dx,h=y*src.Width+x;
        while(y<=y2) {
          for(int he=h+n;h<he;h++,g++) {
            int c=src.Data[h];
            if(c!=trcolor) Data[g]=c;
          }
          g+=Width-n;h+=src.Width-n;
          y++;
        }
      }
      public fillres DeleteRectangle(bmap src,bmap search,int sx,int sy,int w,int h,bool over,int color,int trcolor) {
        search.ClearByte();
        color&=White;
        int c00,c10,c01,c11,o00,o10,o01,o11;
        bool[] mask=null;
        fillres fr=new fillres();
        if(trcolor==-1) {
          o00=0;o10=w-1;o01=Width*(h-1);o11=o10+o01;
          c00=search.XY(sx,sy);c10=search.XY(sx+w-1,sy);c01=search.XY(sx,sy+h-1);c11=search.XY(sx+w-1,sy+h-1);
        } else {
          trcolor&=White;
          mask=new bool[w*h];
          bool f1,f2,f3,f4=f3=f2=f1=false;
          c00=c10=c01=c11=o00=o01=o10=o11=-1;
          for(int j=0;j<h;j++) for(int i=0;i<w;i++) mask[w*j+i]=search.XY(i,j)!=trcolor;
          for(int i=0;i<w*h;i++) {
            int a=i%w,b=i/w;
            if(!f1&&mask[b*w+a]) { c00=search.XY(a,b);o00=Width*b+a;f1=true;}
            a=w-a-1;b=h-b-1;
            if(!f2&&mask[b*w+a]) { c11=search.XY(a,b);o11=Width*b+a;f2=true;}
            a=i/h;b=h-i%h-1;
            if(!f3&&mask[b*w+a]) { c01=search.XY(a,b);o01=Width*b+a;f3=true;}
            a=w-a-1;b=h-b-1;
            if(!f4&&mask[b*w+a]) { c10=search.XY(a,b);o10=Width*b+a;f4=true;}
          }
          if(!(f1&&f2&&f3&&f4)) return fr;
        }
        c00&=White;c01&=White;c10&=White;c11&=White;
        ClearByte();        
        int[] data=src.Data,sdata=search.Data;
        for(int y=1;y<Height-h;y++) {
          for(int x=1,o=y*Width+1;x<Width-w;x++,o++) if(data[o+o00]==c00&&data[o+o10]==c10&&data[o+o01]==c01&&data[o+o11]==c11) {
            for(int j=0;j<h;j++)
              if(trcolor==-1) {
                for(int i=0,p=o+(j)*Width,q=(sy+j)*search.Width+sx;i<w;i++,p++,q++) if(data[p]!=sdata[q]) goto fail;
              } else {
                for(int i=0,p=o+(j)*Width,q=(sy+j)*search.Width+sx,r=j*w+i;i<w;i++,p++,q++,r++) if(mask[r]&&data[p]!=sdata[q]) goto fail;
              }
            if(fr.m==0) {fr.x0=x;fr.y0=y;fr.x1=x+w-1;fr.y1=y+h-1;}
            else R.Union(ref fr.x0,ref fr.y0,ref fr.x1,ref fr.y1,x,y,x+w-1,y+h-1);
            fr.m++;
            if(trcolor==-1) FillRectangle(x,y,x+w-1,y+h-1,color);
            else for(int j=0;j<h;j++)
              for(int i=0,p=o+(j)*Width,r=j*w+i;i<w;i++,p++,r++) if(mask[r]) Data[p]=color;                   
            if(!over) {x+=w-1;o+=w-1;}
           fail:;
          }
        }
        return fr;
      }
      public long FindRectangle(ref int x,ref int y,int x2,int y2,bool backward,int level) {
        R.Norm(ref x,ref y,ref x2,ref y2);        
        long min=long.MaxValue;
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) { x=y=-1;return min;}
        ClearByte();
        int w=x2-x+1,h=y2-y+1,xi=x+w,yi=y,xf=-1,yf=-1,xd=backward?-1:1;
        long limit2=1+level*w*h;
        for(int ye=backward?0:Height-1-h;yi!=ye;) {
          bool i=yi>=y-h&&yi<=y2;
          for(int xe=backward?0:Width-1-w;xi!=xe;xi+=xd) {
            if(i&&xi>=x-w&&xi<=x2) continue;
            long d=DiffRect(x,y,x2,y2,xi,yi,limit2);
            if(d<min) {
              xf=xi;yf=yi;
              if((min=d)==0||d<limit2) goto found;
              //if(d<limit2) limit2=d;
            }
          }
          if(backward) {xi=Width-w-1;yi--;} else {xi=1;yi++;}
        }
       found:
        x=xf;y=yf;
        return min;
      }
      public static int DiffPixel(int src,int dst) {
        byte rs=(byte)(src&255),gs=(byte)(src>>8),bs=(byte)(src>>16);
        byte rd=(byte)(dst&255),gd=(byte)(dst>>8),bd=(byte)(dst>>16);
        return (rd>rs?rd-rs:rs-rd)+(gd>gs?gd-gs:gs-gd)+(bd>bs?bd-bs:bs-bd);
      }
      public long DiffRect(int x,int y,int x2,int y2,int dx,int dy,long limit) {
        long diff=0;
        int w=x2-x+1,h=y2-y+1;
        int src=y*Width+x,dst=dy*Width+dx;
        bool exact=limit==1;
        for(int yi=0;yi<h;yi++,src+=Width-w,dst+=Width-w) {          
          for(int xi=0;xi<w;xi++,src++,dst++) {
            int cs=Data[src],cd=Data[dst];
            if(exact) {
              if(cs!=cd) return long.MaxValue;
            } else
              diff+=DiffPixel(Data[src],Data[dst]);
          }            
          if(diff>=limit) return long.MaxValue;          
        }
        return exact?0:diff;
      }
      public static bool IntersectRect(ref int x,ref int y,ref int x2,ref int y2,int ix,int iy,int ax,int ay) {
        int r;
        if(x>x2) {r=x;x=x2;x2=r;};
        if(y>y2) {r=y;y=y2;y2=r;};
        if(ix>ax) {r=ix;ix=ax;ax=r;};
        if(iy>ay) {r=iy;iy=ay;ay=r;};
        if(x>ax||x2<ix||y>ay||y2<iy) return false;
        if(x<ix) x=ix;if(x2>ax) x2=ax;
        if(y<iy) y=iy;if(y2>ay) y2=ay;
        return true;        
      }
            
      public void Save(string filename) {
        Bitmap bm=new Bitmap(Width-2,Height-2,PixelFormat.Format32bppRgb);
        ToBitmap(this,bm);
        bm.Save(filename);
        bm.Dispose();
      }
      public static bmap FromBitmap(bmap map,Bitmap bm) {
        if(map==null) map=new bmap();
        map.Alloc(bm.Width+2,bm.Height+2);
        map.Clear();
        Rectangle r=new Rectangle(0,0,bm.Width,bm.Height);
        bool alpha=bm.PixelFormat==PixelFormat.Format32bppArgb;
        BitmapData bd=bm.LockBits(r,ImageLockMode.ReadOnly,alpha?PixelFormat.Format32bppArgb:PixelFormat.Format32bppRgb);
        for(int y=0;y<bd.Height;y++)
          Marshal.Copy(new IntPtr(bd.Scan0.ToInt64()+bd.Stride*y),map.Data,(1+y)*map.Width+1,bd.Width);        
        map.ClearByte(alpha?White:-1);
        bm.UnlockBits(bd);
        return map;
      }
      public int[] CopyBitmap(Bitmap bm,int x,int y,int trcolor,bool trx,bool xor,bool diff,bool mix) {
        if(bm==null||x>=Width||y>=Height||x+bm.Width<=0||y+bm.Height<=0) return null;
        int[] sel=new int[] {x,y,x+bm.Width-1,y+bm.Height-1};
        if(!R.Intersect(sel,0,0,Width-1,Height-1)) return null;
        Rectangle r=new Rectangle(sel[0]-x,sel[1]-y,sel[2]-sel[0]+1,sel[3]-sel[1]+1);
        BitmapData bd=bm.LockBits(r,ImageLockMode.ReadOnly,PixelFormat.Format32bppRgb);
        int g=sel[1]*Width+sel[0],n=sel[2]-sel[0]+1,stride=bd.Stride;
        long h=bd.Scan0.ToInt64();
        bool tr=trcolor!=-1;
        trx&=tr;
        int[] buf=diff||xor||tr||mix?new int[n]:null,prev=trx?new int[n]:null,next=trx?new int[n]:null;
        trcolor&=White;
        if(next!=null) Marshal.Copy(new IntPtr(h),next,0,n);
        for(y=sel[1];y<=sel[3];y++) {
          if(buf==null) {
            Marshal.Copy(new IntPtr(h),Data,g,n);
          } else {
            if(prev!=null) Array.Copy(buf,prev,buf.Length);
            if(next!=null) {
              Array.Copy(next,buf,buf.Length);
              if(y<sel[3]) Marshal.Copy(new IntPtr(h+stride),next,0,n);
            } else
              Marshal.Copy(new IntPtr(h),buf,0,n);
            for(int i=0;i<n;i++) {
              int c=buf[i]&White;
              if(!tr||c!=trcolor) {
                int c2=diff?c==(Data[g+i]&White)?White:Black:xor?White^c^Data[g+i]:mix?Palette.ColorMix(Data[g+i],c,1,4):c;
                if(trx) {
                  int a=0,b=0,ab;
                  bool u=y>sel[1],d=y<sel[3];
                  if(u&&(prev[i]&White)==trcolor) a++;
                  if(d&&(next[i]&White)==trcolor) a++;
                  if(i>0) {
                    if((buf[i-1]&White)==trcolor) a++;
                    if(u&&(prev[i-1]&White)==trcolor) b++;
                    if(d&&(next[i-1]&White)==trcolor) b++;
                  }
                  if(i<n-1) {
                    if((buf[i+1]&White)==trcolor) a++;
                    if(u&&(prev[i+1]&White)==trcolor) b++;
                    if(d&&(next[i+1]&White)==trcolor) b++;
                  }
                  ab=(a>0?85:0)+(b>0?85:0);
                  c2=Palette.ColorMix(c,Data[g+i],ab,255);
                }
                Data[g+i]=c2;
              }
            }
          }
          g+=Width;h+=stride;
        }
        if(buf==null) AndOr(White,0,sel[0],sel[1],sel[2],sel[3]);
        bm.UnlockBits(bd);
        return sel;
      }
      public static void ToBitmap(bmap map,Bitmap bm) {
        Rectangle r=new Rectangle(0,0,bm.Width,bm.Height);                
        BitmapData bd=bm.LockBits(r,ImageLockMode.WriteOnly,PixelFormat.Format32bppRgb);
        for(int y=0;y<bd.Height;y++)
          Marshal.Copy(map.Data,(1+y)*map.Width+1,new IntPtr(bd.Scan0.ToInt64()+bd.Stride*y),bd.Width);
        bm.UnlockBits(bd);
        map.ClearByte();
      }      
      public static void ToBitmap(bmap map,Bitmap bm,int x0,int y0,int x1,int y1) {
        int e;
        if(x1<x0) {e=x0;x0=x1;x1=e;}
        if(y1<y0) {e=y0;y0=y1;y1=e;}
        if(x1<0||y1<0||x0>bm.Width-1||y0>bm.Height-1) return;
        if(y0<0) y0=0;if(y1>bm.Height-1) y1=bm.Height-1;
        if(x0<0) x0=0;if(x1>bm.Width-1) x1=bm.Width-1;
        Rectangle r=new Rectangle(x0,y0,x1-x0+1,y1-y0+1);
        BitmapData bd=bm.LockBits(r,ImageLockMode.WriteOnly,PixelFormat.Format32bppRgb);
        for(int y=y0;y<=y1;y++)
          Marshal.Copy(map.Data,(1+y)*map.Width+1+x0,new IntPtr(bd.Scan0.ToInt64()+bd.Stride*(y-y0)+0*x0),x1-x0+1);
        bm.UnlockBits(bd);
      }
      
      public void Transparent(int color) {
        if(color<0) return;
        for(int i=0;i<Data.Length;i++) {
          int c=Data[i]&White;
          if(c==color) Data[i]&=White;
          else Data[i]|=255<<24;          
        }
      }

      //public static void ToBitmap(bmap map,Bitmap bm,int sx,int sy,int zoom,int border) {} 
      public static void Color(int c,out byte r,out byte g,out byte b) {
        r=(byte)(c&255);
        g=(byte)((c>>8)&255);
        b=(byte)((c>>16)&255);
      }
      public void Clear() { Clear(0xffffff);}
      public void Clear(int color) {
        for(int i=0;i<Data.Length;i++) Data[i]=color;
      }
      public void AndOr(int and,int or) {
        for(int i=0;i<Data.Length;i++) Data[i]=or|(and&Data[i]);
      }
      public void AndOr(int and,int or,int x0,int y0,int x1,int y1) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int h=y0*Width+x0;
          for(int he=h+x1-x0;h<=he;h++)
            Data[h]=or|(and&Data[h]);
          y0++;
        }        
      }      
      public void ClearByte() {
        for(int i=0;i<Data.Length;i++)
          Data[i]&=0xffffff;
      }
      public void ClearByte(int color) {
        if(color<0) { ClearByte();return;}
        int b0=color&255,b1=(color>>8)&255,b2=(color>>16)&255;
        for(int i=0;i<Data.Length;i++) {
          int a=(Data[i]>>24)&255;
          Data[i]&=0xffffff;          
          if(a<255) {
            int x=Data[i],b=255-a;
            int c0=(b*b0+a*(x&255))/255;
            int c1=(b*b1+a*((x>>8)&255))/255;
            int c2=(b*b2+a*((x>>16)&255))/255;
            Data[i]=c0|(c1<<8)|(c2<<16);
          }
        }
      }
      public void Border(int color) {
        for(int x=0;x<Width;x++)
          Data[x]=Data[Data.Length-1-x]=color;
        int h=0,g=Width-1;
        for(int y=0;y<Height;y++) {
          Data[h]=Data[g]=color;
          h+=Width;g+=Width;
        }
      }
      int bitscan(int x) {
       unchecked {
        int r=0;
        ushort u;
        if(x==0) return -1;
        if(0!=(x&0xffff0000)) {r=16;u=(ushort)(x>>16);} else u=(ushort)x;
        if(0!=(u&0xff00)) {r+=8;u>>=8;}
        if(0!=(u&0xf0)) {r+=4;u>>=4;}
        if(0!=(u&0xc)) {r+=2;u>>=2;}
        return r+(u==3?1:u-1);
       }
      }
      
      public static int distance(int mode,int dx,int dy) {
        int d;      
        switch(mode) {
         case 6:d=Math.Abs(dx-dy);break; // \\
         case 5:d=Math.Abs(dx+dy);break; // //
         case 4:d=Math.Abs(dx);break;    // |
         case 3:d=Math.Abs(dy);break;    // -
         case 2:d=Math.Max(Math.Abs(dx),Math.Abs(dy));break; // []
         case 1:d=Math.Abs(dx)+Math.Abs(dy);break; // <>
         default:d=dx*dx+dy*dy;break; // O
        }
        return d;
      }
			public static int distance(int mode,int x,int y,int x0,int y0,int x1,int y1) {
			  x-=x0;y-=y0;
				int dx=x1-x0,dy=y1-y0;
				if(dx==0&&dy==0) return distance(mode,x,y);				
				int a=x*dx+y*dy,d=dx*dx+dy*dy;
				if(a<0) return distance(mode,x,y);
				if(a>d) return distance(mode,x-dx,y-dy);
				int nx=(int)((long)dx*a/d),ny=(int)((long)dy*a/d);
				return distance(mode,x-nx,y-ny);
			}
			public static int distance(int mode,int x,int y,PointPath dxy) {
			  if(dxy.Count<1) return 0;
				PathPoint pp=dxy[dxy.Count-1],pp2;

				int d=distance(mode,x-pp.x,y-pp.y);
			  if(dxy.Count<2) return d;
				pp.stop=!dxy.Closed;
				for(int i=0;i<dxy.Count;i++) { 
				  pp2=pp;pp=dxy[i];
					int d2=pp2.stop?distance(mode,x-pp.x,y-pp.y):distance(mode,x,y,pp2.x,pp2.y,pp.x,pp.y);
				  //int d2=distance(mode,x-dxy[i],y-dxy[i+1]);
					if(d2<d) d=d2;
				}
				return d;  
			}

      public fillres FloodFill(int[] pxy,int color1,int color2,bool x8,bool noblack,int mode,bool fill2black,PointPath gxy,bool zero,FillPattern pattern) {        
        if(pattern!=null&&(pattern.BMap==null||!pattern.Enabled)) pattern=null;
        int x=pxy[0],y=pxy[1];
        fillres res=new fillres() {x0=x,y0=y,x1=x,y1=y,m=0};
        if(x<1||x>=Width-1||y<1||y>=Height-1) return res;
        int xy=(y<<16)+x;
        int px=y*Width+x,px2;
        int clr=Data[px];
				int gx=gxy[0].x,gy=gxy[0].y;
				bool multg=gxy.Count>1;
        if(noblack&&(clr&0xffffff)==0) return res;        
        Border(fill2black?0:0x7fffffff);
        int[] fifo=new int[Width*Height];
        int n=0,m=0,max=distance(mode,x,y,gxy),min=zero?0:max,d;
        fifo[m++]=xy;
        Data[px]=-1;
        bool grad=color1!=color2&&(pattern==null||pattern.TrColor>=0);
        for(int i=2;i<pxy.Length;i+=2) {
          x=pxy[i];y=pxy[i+1];
          if(x<1||x>=Width-1||y<1||y>=Height-1) return res;          
          xy=(y<<16)+x;
          fifo[m++]=xy;
        }        
        while(n<m) {
          xy=fifo[n++];
          int x2=xy&65535,y2=(xy>>16),rd;
          if(!grad) d=1;          
          else {
					  d=multg?distance(mode,x2,y2,gxy):distance(mode,x2-gx,y2-gy);
            if(d>max) max=d;else if(d<min) min=d;
          }
          px=y2*Width+x2;
          rd=Data[(px2=px-Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65536;Data[px2]=-1;}
          rd=Data[(px2=px+Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65536;Data[px2]=-1;}
          rd=Data[(px2=px-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-1;Data[px2]=-1;}
          rd=Data[(px2=px+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+1;Data[px2]=-1;}
          if(x8) {
            rd=Data[(px2=px-Width-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65537;Data[px2]=-1;}
            rd=Data[(px2=px-Width+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65535;Data[px2]=-1;}
            rd=Data[(px2=px+Width-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65535;Data[px2]=-1;}
            rd=Data[(px2=px+Width+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65537;Data[px2]=-1;}
          }
        }
        n=0;
        bool sqr=mode<1||mode>6;        
        int[] cm=null;
        if(grad) {
          if(sqr) {min=isqrt(min);max=isqrt(max);}
          cm=new int[max-min+1];
          for(int i=0;i<cm.Length;i++) cm[i]=Palette.ColorMix(color1,color2,i,max-min);        
        }
        while(n<m) {
          xy=fifo[n++];
          int x2=xy&65535,y2=(xy>>16);
          if(x2<res.x0) res.x0=x2;else if(x2>res.x1) res.x1=x2;
          if(y2<res.y0) res.y0=y2;else if(y2>res.y1) res.y1=y2;
          px=y2*Width+x2;
          if(grad) {
            d=multg?distance(mode,x2,y2,gxy):distance(mode,x2-gx,y2-gy);
            if(sqr) d=isqrt(d);
            //Data[px]=Palette.ColorMix(color1,color2,d-min,max-min);
            Data[px]=cm[d-min];
          } else
            Data[px]=color1;
          if(pattern!=null) {
            int rc=pattern.Color(x2,y2);
            if(rc>=0) Data[px]=rc;
          }
        }
        res.m=m;
        return res;
      }      
      public fillres FloodFill1(int x,int y,bool x8,int[] rect,int incolor,int bcolor,int outcolor) {
			  if(!R.Intersect(rect,0,0,Width-1,Height-1)) return new fillres();
        if(incolor==-1&&bcolor==-1&&outcolor==-1) return new fillres();
        int sx0=0,sy0=0,sx1=Width-1,sy1=Height-1;
				if(rect!=null) {sx0=rect[0];sy0=rect[1];sx1=rect[2];sy1=rect[3];}
        int color=XY(x,y)&White;
        if((incolor<0||incolor==color)&&(bcolor<0||bcolor==color)&&outcolor<0) return new fillres();
        int w=sx1-sx0+1,h=sy1-sy0+1;
        int[] fifo=new int[w*h];
        int n=0,m=1;
        fifo[0]=(y<<16)|x;        
        fillres res=new fillres() {x0=x,y0=y,x1=x,y1=y,m=0};
        while(n<m) {
          int xy=fifo[n++],ry=xy>>16,rx=xy&65535,r=ry*Width+rx,r2;
          if(Data[r]==-1) continue;
          Data[r]=-1;
          int mi=0,ma=0;
          while(rx+mi>sx0&&Data[r2=r+mi-1]==color) {mi--;fifo[m++]=xy+mi;Data[r2]=-1;}
          while(rx+ma<sx1&&Data[r2=r+ma+1]==color) {ma++;fifo[m++]=xy+ma;Data[r2]=-1;}
          if(x8&&rx+mi>sx0) mi--;
          if(x8&&rx+ma<sx1) ma++;
          for(int i=mi;i<=ma;i++) {
            if(ry>sy0&&Data[r2=r-Width+i]==color) {fifo[m++]=xy-65536+i;Data[r2]=-2;}
            if(ry<sy1&&Data[r2=r+Width+i]==color) {fifo[m++]=xy+65536+i;Data[r2]=-2;}
          }
        }
        if(bcolor<0) bcolor=color;
        if(incolor<0) incolor=color;
        bool oc=outcolor>=0,mark=oc||bcolor>=0&&bcolor!=incolor;        
        if(mark) {bcolor|=(1<<24);incolor|=(1<<24);}
        w=Width;
        for(n=0;n<m;n++) {
          bool b=false;        
          int r=fifo[n],rx=r&65535,ry=(r>>16),r2;
          r=ry*Width+rx;
          if(mark) {
            if(rx>sx0&&0==(Data[r2=r-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(rx<sx1&&0==(Data[r2=r+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(ry>sy0&&0==(Data[r2=r-w]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(ry<sy1&&0==(Data[r2=r+w]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(x8) {
              if(ry>sy0) {
                if(rx>sx0&&0==(Data[r2=r-w-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
                if(rx<sx1&&0==(Data[r2=r-w+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
              }
              if(ry<sy1) {
                if(rx>sx0&&0==(Data[r2=r+w-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
                if(rx<sx1&&0==(Data[r2=r+w+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
              }
            }
          }
          Data[r]=b?bcolor:incolor;
          if(mark) fifo[n]=r;
        }
        if(mark) for(n=0;n<m;n++) {
          int r=fifo[n];
          Data[r]&=White;
        }
        return res;
      }
      public fillres Replace(int search,int replace,int x0,int y0,int x1,int y1) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px,clr=search&White;
        for(int y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(int x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(c!=clr) continue;
            Data[px]=replace;
            if(res.m==0) { 
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;              
            }
            res.m++;
          }
        }
        return res;
      }
      public fillres Replace(int x,int y,int color1,int color2,bool noblack,int mode,int gx,int gy,bool zero,int x0,int y0,int x1,int y1) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(x<1||x>=Width-1||y<1||y>=Height-1) return res;
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px=y*Width+x,d,min=0,max=0;
        int clr=Data[px]&White;
        if(noblack&&clr==0) return res;
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(c!=clr) continue;
            d=distance(mode,x-gx,y-gy);
            if(res.m==0) {
              min=zero?0:d;              
              max=d;
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(d>max) max=d;
              else if(d<min) min=d;
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;
            }
            res.m++;
          }
        }
        bool sqr=mode<1||mode>6;        
        if(sqr) {min=isqrt(min);max=isqrt(max);}
        int[] cm=new int[max-min+1];
        for(int i=0;i<cm.Length;i++) cm[i]=Palette.ColorMix(color1,color2,i,max-min);                
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(c!=clr) continue;
            d=distance(mode,x-gx,y-gy);
            if(sqr) d=isqrt(d);
            Data[px]=cm[d-min];
          }
        }        
        return res;  
      }
      public void Colorize(int cmode,int color1,int color2,int gmode,int gx,int gy,bool zero,int x0,int y0,int x1,int y1) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        int x,y,px,d,min=0,max=0;
        if(x0<=gx&&gx<=x1&&y0<=gy&&gy<=y1) zero=true;
        d=distance(gmode,x0-gx,y0-gy);
        max=d;min=zero?0:d;
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            d=distance(gmode,x-gx,y-gy);
            if(d>max) max=d;else if(!zero&&d<min) min=d;
          }
        }
        bool sqr=gmode<1||gmode>6;        
        if(sqr) {min=isqrt(min);max=isqrt(max);}
        int[] cm=new int[max-min+1];
        for(int i=0;i<cm.Length;i++) cm[i]=Palette.ColorMix(color1,color2,i,max-min);                
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            d=distance(gmode,x-gx,y-gy);
            if(sqr) d=isqrt(d);
            int c=cm[d-min],p=Data[px]&White;
            int p0=p&255,p1=(p>>8)&255,p2=(p>>16)&255,pmi,pma,pi;
            int c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255,cmi,cma,ci;
            if(c0<c1) {cmi=c0;cma=c1;} else {cmi=c1;cma=c0;}
            if(c2<cmi) cmi=c2;else if(c2>cma) cma=c2;
            if(p0<p1) {pmi=p0;pma=p1;} else {pmi=p1;pma=p0;}
            if(p2<pmi) pmi=p2;else if(p2>pma) pma=p2;
            ci=(7471*c0+38470*c1+19595*c2)>>16;
            pi=(7471*p0+38470*p1+19595*p2)>>16;
            ci=(c0+c1+c2)/3;
            pi=(p0+p1+p2)/3;
            switch(cmode) {
             default:
             case 4:
              if(pmi<pma&&cmi<cma) {
                p0=pi+(c0-ci)*(pma-pmi)/(cma-cmi);
                p1=pi+(c1-ci)*(pma-pmi)/(cma-cmi);
                p2=pi+(c2-ci)*(pma-pmi)/(cma-cmi);
                if(p0<0) p0=0;else if(p0>255) p0=255; 
                if(p1<0) p1=0;else if(p1>255) p1=255; 
                if(p2<0) p2=0;else if(p2>255) p2=255; 
              }             
              break;
             case 3:
              if(pi<ci) {
                p0=c0*pi/ci;
                p1=c1*pi/ci;
                p2=c2*pi/ci;
              } else if(pi>ci) {
                p0=255-(255-c0)*(255-pi)/(255-ci);
                p1=255-(255-c1)*(255-pi)/(255-ci);
                p2=255-(255-c2)*(255-pi)/(255-ci);
              } else {
                p0=c0;p1=c1;p2=c2;
              }
              break;
             case 2:
              p0=p0>=c0?255:255*p0/c0;
              p1=p1>=c1?255:255*p1/c1;
              p2=p2>=c2?255:255*p2/c2;
              if(p1<p0) p0=p1;
              if(p2<p0) p0=p2;
              if(pi>0) {
                if(pi<p0) pi=p0;
                p0=pi*c0/255;
                p1=pi*c1/255;
                p2=pi*c2/255;
              } else {
                p0=p&255;p1=(p>>8)&255;p2=(p>>16)&255;
              }                
              break;
             case 1:
              p0-=pmi*(255-c0)/255;
              p1-=pmi*(255-c1)/255;
              p2-=pmi*(255-c2)/255;
              break;
            }
            Data[px]=p0|(p1<<8)|(p2<<16);
          }
        }        
      }      
      
      // path gradient
      public int FloodFillGrad(int[] xy,int color1,int color2,bool border,bool d8,bool x8,bool noblack,bool fill2black) {
        int x=xy[0],y=xy[1];
        if(x<1||x>=Width-1||y<1||y>=Height-1) return 0;
        int px=y*Width+x,px2;
        int clr=Data[px];
        if(noblack&&(clr&0xffffff)==0) return 0;
        Border(fill2black?0:0x7fffffff);
        int[] fifo=new int[Width*Height];        
        int n=0,m=0,k=0,xyi=2;
        int d=-1,md=d;
        bool dual=d8!=x8&&!border;
       np:
        fifo[m++]=px;
        Data[px]=d;                
        if(xyi<xy.Length-1) {
         sp: 
          x=xy[xyi++];y=xy[xyi++];
          if(x<1||x>=Width-1||y<1||y>=Height-1) goto sp;
          px=y*Width+x;
          goto np;
        }
        k=m;
        d--;
        while(n<m) {
          px=fifo[n++];
          int d2=Data[px]-1;
          if(dual&&d2!=d) k=m;
          d=d2;
          bool fl=false,fr=false,ft=false,fb=false;
          int rd;
          rd=Data[(px2=px-Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;ft=true;}
          rd=Data[(px2=px+Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fb=true;}
          rd=Data[(px2=px-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fl=true;}
          rd=Data[(px2=px+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fr=true;}
          if(x8||d8) {
            if(!d8) d--;
            if(x8&&!d8) {
              if(!fl&&Data[px-1]<0) fl=true;
              if(!fr&&Data[px+1]<0) fr=true;
              if(!ft&&Data[px-Width]<0) ft=true;
              if(!fb&&Data[px+Width]<0) fb=true;
            }            
            rd=Data[(px2=px-Width-1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!ft&&!fl:ft||fl)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px-Width+1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!ft&&!fr:ft||fr)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px+Width-1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!fb&&!fl:fb||fl)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px+Width+1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!fb&&!fr:fb||fr)) {fifo[m++]=px2;Data[px2]=d;}
            if(!d8) d++;
          }
        }
        if(border) {
          n=0;
          d=-1;          
          unchecked { clr=(int)0x80000001;}         
          for(int i=0;i<m;i++) {
            px=fifo[i];
            bool go=Data[px-1]>=0||Data[px+1]>=0||Data[px+Width]>=0||Data[px-Width]>=0;
            if(!go&&x8&&(Data[px-Width-1]>=0||Data[px-Width+1]>=0||Data[px+Width-1]>=0||Data[px+Width+1]>=0)) go=true;
            if(go) {
              fifo[n++]=px;
              Data[px]=d;
            } else
              Data[px]=clr;
          }
          k=m=n;
          n=0;
          dual=d8!=x8;
          d--;
          while(n<m) {
            px=fifo[n++];
            int d2=Data[px]-1;
            if(dual&&d2!=d) k=m;
            d=d2;
            bool fl=false,fr=false,ft=false,fb=false;
            if(Data[(px2=px-Width)]==clr) {fifo[m++]=px2;Data[px2]=d;ft=true;};
            if(Data[(px2=px+Width)]==clr) {fifo[m++]=px2;Data[px2]=d;fb=true;};
            if(Data[(px2=px-1)]==clr) {fifo[m++]=px2;Data[px2]=d;fl=true;};
            if(Data[(px2=px+1)]==clr) {fifo[m++]=px2;Data[px2]=d;fr=true;};
            if(x8||d8) {
              if(!d8) d--;
              if(x8&&!d8) {
                if(!fl&&Data[px-1]<0) fl=true;
                if(!fr&&Data[px+1]<0) fr=true;
                if(!ft&&Data[px-Width]<0) ft=true;
                if(!fb&&Data[px+Width]<0) fb=true;
              }
              if(Data[(px2=px-Width-1)]==clr&&(x8?d8||!ft&&!fl:ft||fl)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px-Width+1)]==clr&&(x8?d8||!ft&&!fr:ft||fr)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px+Width-1)]==clr&&(x8?d8||!fb&&!fl:fb||fl)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px+Width+1)]==clr&&(x8?d8||!fb&&!fr:fb||fr)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};              
              if(!d8) d++;
            }            
          }
        }
        d=-d;
        for(n=0;n<m;n++) {
          px=fifo[n];
          int d2=-Data[px];
          Data[px]=Palette.ColorMix(color1,color2,d2-1,d-1);
        }
        return m;      
      }
      internal void Expand(bool x8,bool wonly,bmap src,int[] rect,int color,int incolor,int bcolor,int outcolor) {
			  if(!R.Intersect(rect,1,1,Width-1,Height-1)) return;
        if(src==null) src=Clone();
        src.Border(White);
        src.ClearByte();
        if(incolor==-1&&bcolor==-1&&outcolor==-1) return;
				int w=Width-2,h=Height-2;
				if(rect!=null) {w=rect[2]-rect[0]+1;h=rect[3]-rect[1]+1;}
				int i=rect!=null?rect[0]+Width*(rect[1]):Width+1;
        color&=White;
        for(int y=0;y<h;y++,i+=Width-w)
				  for(int e=i+w;i<e;i++) if(src.Data[i]==color) {
          if(incolor!=-1&&incolor!=color||bcolor!=-1&&bcolor!=color) {
            bool inner=src.Data[i-1]==color&&src.Data[i+1]==color&&src.Data[i-Width]==color&&src.Data[i+Width]==color;
            if(inner&&x8&&(src.Data[i-Width-1]!=color||src.Data[i-Width+1]!=color||src.Data[i+Width-1]!=color||src.Data[i+Width+1]!=color)) inner=false;
            if(inner&&incolor!=-1) Data[i]=incolor;
            if(!inner&&bcolor!=-1) Data[i]=bcolor;
          }
          if(outcolor!=-1) {
            if(wonly) {
              if(Data[i-1]==White) Data[i-1]=outcolor;
              if(Data[i+1]==White) Data[i+1]=outcolor;
              if(Data[i-Width]==White) Data[i-Width]=outcolor;
              if(Data[i+Width]==White) Data[i+Width]=outcolor;
							if(x8) {
								if(Data[i-Width-1]==White) Data[i-Width-1]=outcolor;
								if(Data[i-Width+1]==White) Data[i-Width+1]=outcolor;
								if(Data[i+Width-1]==White) Data[i+Width-1]=outcolor;
								if(Data[i+Width+1]==White) Data[i+Width+1]=outcolor;
							}
            } else if((incolor==outcolor&&bcolor==outcolor)||outcolor==color) {
              Data[i-1]=Data[i+1]=Data[i-Width]=Data[i+Width]=outcolor;
              if(x8) Data[i-Width-1]=Data[i-Width+1]=Data[i+Width-1]=Data[i+Width+1]=outcolor;
            } else {
              if(Data[i-1]!=color) Data[i-1]=outcolor;
              if(Data[i+1]!=color) Data[i+1]=outcolor;
              if(Data[i-Width]!=color) Data[i-Width]=outcolor;
              if(Data[i+Width]!=color) Data[i+Width]=outcolor;
							if(x8) {
								if(Data[i-Width-1]!=color) Data[i-Width-1]=outcolor;
								if(Data[i-Width+1]!=color) Data[i-Width+1]=outcolor;
								if(Data[i+Width-1]!=color) Data[i+Width-1]=outcolor;
								if(Data[i+Width+1]!=color) Data[i+Width+1]=outcolor;
							}
            }
          }
        }
      }
      internal void Impand(int[] rect,int color,int color2,byte mask,bool repeat) {
        if(color==color2) return;
			  if(!R.Intersect(rect,1,1,Width-1,Height-1)) return;
        bmap src=new bmap(this,rect[0],rect[1],rect[2],rect[3],1);
        ClearByte();
        mask&=15;
       repeat:
        for(int j=0;j<4;j++) {
          if(0==(mask&(1<<j))) continue;
          int n=0;
          src.CopyRectangle(this,rect[0],rect[1],rect[2],rect[3],1,1,-1);
          for(int y=1;y<src.Height-1;y++) {
            int h=y*src.Width+1,he=h+src.Width-2,xh=rect[0]-h;
            for(;h<he;h++) if(src.Data[h]==color) {
              bool go=false,l,r,u,d,lu,ld,ru,rd;
              l=src.Data[h-1]==color;r=src.Data[h+1]==color;u=src.Data[h-src.Width]==color;d=src.Data[h+src.Width]==color;
              lu=src.Data[h-src.Width-1]==color;ld=src.Data[h+src.Width-1]==color;
              ru=src.Data[h-src.Width+1]==color;rd=src.Data[h+src.Width+1]==color;
	            switch(j) {
	              case 0:if(!u&&d&&((ld&&l)||(rd&&r))&&!(l&&r&&!(ld||rd))&&!(lu&&!l)&&!(ru&&!r)) go=true;break;
	              case 1:if(!l&&r&&((ru&&u)||(rd&&d))&&!(u&&d&&!(ru||rd))&&!(lu&&!u)&&!(ld&&!d)) go=true;break;
	              case 2:if(!d&&u&&((lu&&l)||(ru&&r))&&!(l&&r&&!(lu||ru))&&!(ld&&!l)&&!(rd&&!r)) go=true;break;
	              case 3:if(!r&&l&&((lu&&u)||(ld&&d))&&!(u&&d&&!(lu||ld))&&!(ru&&!u)&&!(rd&&!d)) go=true;break;
	            }
              if(go) {
                n=1;
                Data[Width*(y+rect[1]-1)+h+xh]=color2;
              }
            }
          }
          if(n==0) mask&=(byte)(~(1<<j));
        }
        if(repeat&&mask!=0) {
          goto repeat;
        }
      }
      public void Mirror(bool vertical,bool horizontal) { 
        int x,y;
        if(vertical) {
          for(y=0;y<Height-y-1;y++) {
            int h=y*Width,g=(Height-y-1)*Width;
            for(x=0;x<Width;x++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g++;h++;
            }
          }
        } 
        if(horizontal) {
          for(x=0;x<Width-x-1;x++) {
            int h=x,g=(Width-x-1);
            for(y=0;y<Height;y++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g+=Width;h+=Width;
            }
          }
        }
      }
      public void Mirror(bool vertical,bool horizontal,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        if(x<0) x=0;if(x2>Width-1) x2=Width-1;
        if(y<0) y=0;if(y2>Height-1) y2=Height-1;
        if(vertical) {
          for(int z=y,z2=y2;z<z2;z++,z2--) {
            int h=z*Width+x,g=z2*Width+x;
            for(int i=x;i<=x2;i++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g++;h++;
            }
          }
        }         
        if(horizontal) {
          for(;x<x2;x++,x2--) {
            int h=y*Width+x,g=y*Width+x2;
            for(int i=y;i<=y2;i++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g+=Width;h+=Width;
            }
          }
        }         
      }
      public void Insert(bool vertical,bool horizontal,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        if(x<0) x=0;if(x2>Width-1) x2=Width-1;
        if(y<0) y=0;if(y2>Height-1) y2=Height-1;
        int h,g;
        if(vertical) {
          for(int a=Height-1;a>y;a--) {
            g=a*Width;h=(a>y2?a-y2+y-1:y)*Width;
            for(int b=0;b<Width;b++) Data[g++]=Data[h++];
          }
        }
        if(horizontal) {
          for(int a=Width-1;a>x;a--) {
            g=a;h=a>x2?a-x2+x-1:x;
            for(int b=0;b<Height;b++,g+=Width,h+=Width) Data[g]=Data[h];
          }
        }
      }
      public void Remove(bool vertical,bool horizontal,int x,int y,int x2,int y2,int mix,int miy,int max,int may) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>max||y>=may||x2<mix||y2<miy) return;
        if(x<mix) x=mix;if(x2>max) x2=max;
        if(y<miy) y=miy;if(y2>may) y2=may;
        int h,g;
        if(vertical) {
          for(int a=y;a<=may;a++) {
            g=a*Width;h=a+y2-y+1;if(h>may) h=may;h*=Width;
            g+=mix;h+=mix;
            for(int b=mix;b<=max;b++) Data[g++]=Data[h++];
          }
        }
        if(horizontal) {
          for(int a=x;a<max;a++) {
            g=a;h=a+x2-x+1;if(h>max) h=max;
            g+=miy*Width;h+=miy*Width;
            for(int b=miy;b<=may;b++,g+=Width,h+=Width) Data[g]=Data[h];
          }
        }
      }
      
      
      public bmap Rotate90(bool right) {
        bmap map2=new bmap(Height,Width);
        int d=Height;
        d=right?-d:d;
       unsafe {
        fixed(int* pd2=map2.Data,pd=Data) {        
        for(int y=0;y<Height;y++) {
          int* g2=pd2+(right?(Width-1)*Height+y:(Height-y-1)),h2=pd+y*Width;
          for(int x=0;x<Width;x++) {
            *g2=*h2++;
            g2+=d;
          }
        }
       }}
        return map2;
      }      
      public void Rotate90(bool right,int x,int y,int size) {
        if(size<2||x+size>Width||y+size>Height||x<0||y<0) return;        
        bmap map2=new bmap(size,size);
        int d=right?-size:size;
       unsafe {
        fixed(int *pd2=map2.Data,pd=Data) {
        int *pdx=pd+y*Width+x;
        for(int b=0;b<size;b++) {
          int* g2=pd2+(right?(size-1)*size+b:(size-b-1)),h2=pdx+b*Width;
          for(int a=0;a<size;a++) {
            *g2=*h2++;
            g2+=d;
          }
        }
        CopyRectangle(map2,0,0,size-1,size-1,x,y,-1);
       }}
      }
      public delegate int Filter1Delegate(object param,int c);
      public int Filter1(Filter1Delegate filter,object param,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return -1;
        if(x>x2||y>y2) return -1;
        int g=y*Width+x,n=0;
        for(;y<=y2;y++) {
          for(int ge=g+x2-x;g<=ge;g++) {
            int c2=Data[g]&White,c=filter(param,c2);
            if(c==-1) continue;
            c&=White;
            if(c!=c2) { Data[g]=c;n++;}
          }
          g+=Width-(x2-x+1);
        }
        return n;
      }
      public static int Filter1Replace(object param,int c) {
        int[] i2=param as int[];
        return c==i2[0]?i2[1]:-1;
      }
      public void Filter(FilterOp f,int param,bool bw,int x,int y,int x2,int y2,bmap undo) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x>x2||y>y2) return;
        int g=y*Width+x;
        bool bwi=bw&&(f==FilterOp.Invert||f==FilterOp.InvertIntensity);
        byte[] ba=null;
        if(f==FilterOp.Contrast) {
          ba=new byte[6];
          ba[0]=ba[1]=ba[2]=255;
          for(int yy=y,gg=g;yy<=y2;yy++) {
            for(int ge=gg+x2-x;gg<=ge;gg++) {
              int c=Data[gg];
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              if(c0<ba[0]) ba[0]=c0;else if(c0>ba[3]) ba[3]=c0;
              if(c1<ba[1]) ba[1]=c1;else if(c1>ba[4]) ba[4]=c1;
              if(c2<ba[2]) ba[2]=c2;else if(c2>ba[5]) ba[5]=c2;
            }
            gg+=Width-(x2-x+1);
          }
          if(ba[3]<=ba[0]) ba[3]=ba[0];
          if(ba[4]<=ba[1]) ba[4]=ba[1];
          if(ba[5]<=ba[2]) ba[5]=ba[2];
          if(!bw) {
            if(ba[1]<ba[0]) ba[0]=ba[1];
            if(ba[2]<ba[0]) ba[0]=ba[2];
            ba[1]=ba[2]=ba[0];
            if(ba[4]>ba[3]) ba[3]=ba[4];
            if(ba[5]>ba[3]) ba[3]=ba[5];
            ba[4]=ba[5]=ba[3];
          }
        }
        for(;y<=y2;y++) {
          for(int ge=g+x2-x;g<=ge;g++) {
            int c=Data[g]&White;
            if(f==FilterOp.Contrast) {
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              if(ba[0]!=ba[3]) c0=(byte)((c0-ba[0])*255/(ba[3]-ba[0]));
              if(ba[1]!=ba[4]) c1=(byte)((c1-ba[1])*255/(ba[4]-ba[1]));
              if(ba[2]!=ba[5]) c2=(byte)((c2-ba[2])*255/(ba[5]-ba[2]));
              Data[g]=c0|(c1<<8)|(c2<<16);
              continue;
            }
            if(f==FilterOp.Border) {
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              for(int i=0,n=bw?8:4;i<n;i++) {
                int d=undo.Data[g+(i<4?i<2?i==1?1:-1:i==2?-Width:Width:i<6?i==5?-Width+1:-Width-1:i==6?Width-1:Width+1)]&White;
                byte d0=(byte)(d&255),d1=(byte)((d>>8)&255),d2=(byte)((c>>16)&255);
                if(c0+c1+c2>d0+d1+d2||(c0+c1+c2==d0+d1+d2&&c>d)) continue;
                if(d0>c0+param||d1>c1+param||d2>c2+param) {
                  Data[g]=0;
                  break;
                }
              }
              continue;
            }
            if(c==0||c==White) {
              if(bwi) Data[g]=c==0?White:0; 
            } else if(f==FilterOp.InvertIntensity) Data[g]=Palette.InvertIntensity(c,0);
            else if(f==FilterOp.Saturate) Data[g]=Palette.Saturate(c,param);
            else if(f==FilterOp.Grayscale) Data[g]=Palette.Grayscale(c,param);
            else if(f==FilterOp.Levels) Data[g]=Palette.Levels(c,param);
            else Data[g]^=White;                        
          }
          g+=Width-(x2-x+1);
        }
      }
      public void RemoveDots(bool black,bool white,char mode,bmap src) {
        Border(-1);
        ClearByte();
        src.ClearByte();
        int h=Height-2,w=Width-2,i=Width+1;
        bool all=!black&&!white;
        bool x3=mode=='3',x8=mode=='8',x4=!x3&&!x8;
        int[] data=src.Data;
        for(int y=0;y<h;y++,i+=2) 
          for(int x=0;x<w;x++,i++) {            
            if(black&&data[i]==0||white&&data[i]==White||all) {
              int c=data[i],c2=c;
              bool dot=data[i-1]!=c&&data[i+1]!=c&&data[i+Width]!=c&&data[i-Width]!=c;
              if(x8)
                 if(data[i-Width-1]==c||data[i-Width+1]==c||data[i+Width-1]==c||data[i+Width+1]==c) dot=false;              
              c=dot?Palette.ColorAvg(data[i-1],data[i+1],data[i-Width],data[i+Width]):-1;
              if(!dot&&x3) {
                c=c2;
                bool l=data[i-1]!=c,r=data[i+1]!=c,u=data[i-Width]!=c,d=data[i+Width]!=c;
                if(l&&r&&(d||u)) c=Palette.ColorAvg(data[i-1],data[i+1],data[i+(d?Width:-Width)]);
                else if(d&&u&&(l||r)) c=Palette.ColorAvg(data[i-Width],data[i+Width],data[i+(r?1:-1)]);
              }
              if(c!=-1) Data[i]=c;
            }
          }
      }
      public void RemoveDust(int max,int color1,int color2,bool x8,int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(max<1||color1==color2) return;
        ClearByte();
        int[] q=new int[max+4];
        for(int yi=y;yi<=y2;yi++)
          for(int xi=x,i=yi*Width+x,h,xy;xi<=x2;xi++,i++) if(Data[i]==color1) {
            int n=0,m=1,nx,ny;
            q[n]=(xi&0xffff)|(yi<<16);Data[i]=color2;
            while(n<m&&m<=max) {
              xy=q[n++];nx=xy&0xffff;ny=xy>>16;
              h=Width*ny+nx;
              if(nx>x&&Data[h-1]==color1) {q[m++]=xy-1;Data[h-1]=color2;}
              if(nx<x2&&Data[h+1]==color1) {q[m++]=xy+1;Data[h+1]=color2;}
              if(ny>y&&Data[h-Width]==color1) {q[m++]=xy-0x10000;Data[h-Width]=color2;}
              if(ny<y2&&Data[h+Width]==color1) {q[m++]=xy+0x10000;Data[h+Width]=color2;}
              if(x8) {
                if(ny>y) {
                  if(nx>x&&Data[h-Width-1]==color1) {q[m++]=xy-0x10000-1;Data[h-Width-1]=color2;}
                  if(nx<x2&&Data[h-Width+1]==color1) {q[m++]=xy-0x10000+1;Data[h-Width+1]=color2;}
                }
                if(ny<y2) {
                  if(nx>x&&Data[h+Width-1]==color1) {q[m++]=xy+0x10000-1;Data[h+Width-1]=color2;}
                  if(nx<x2&&Data[h+Width+1]==color1) {q[m++]=xy+0x10000+1;Data[h+Width+1]=color2;}
                }
              }
            }
            bool go=m<max;
            if(!go) for(n=0;n<m;n++) {
              xy=q[n];nx=xy&0xffff;ny=xy>>16;
              h=Width*ny+nx;
              Data[h]=color1;
            }
          }
      }

      public void Bright(bool dark,bool bw,int level,int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(level<1||level>255) return;
				int i=y*Width+x,dx=x2-x+1;
				while(y<=y2) {
				  for(int ie=i+dx;i<ie;i++) {
						int c=Data[i];
            if(bw&&(c&White)==(dark?White:0)) continue;
						int b0=c&255,b1=(c>>8)&255,b2=(c>>16)&255;
						if(dark) {b0=b0*level/255;b1=b1*level/255;b2=b2*level/255;}
						else {b0=255-((255-b0)*level/255);b1=255-((255-b1)*level/255);b2=255-((255-b2)*level/255);}
						c=b0|(b1<<8)|(b2<<16);
						Data[i]=c;
					}
				  i+=Width-dx;
					y++;
				}
      }
      public void NoWhite(bool white,bool black) {
        if(!white&&!black) return;
        for(int i=0;i<Data.Length;i++) {
          int x=Data[i];
          if(white&&(x&White)==White) Data[i]=0xfefefe;
          else if(black&&(x&White)==Black) Data[i]=0x010101;
        }        
      }
      public void Contour(bool white) {
        bool[] ba=new bool[Data.Length];
        int n=Data.Length-Width-1;
        Border(Black);
        for(int i=Width+1;i<n;i++) {
          int ci=Palette.RGBSum(Data[i]);
          ba[i]=ci<Palette.RGBSum(Data[i-1])||ci<Palette.RGBSum(Data[i+1])||ci<Palette.RGBSum(Data[i-Width])||ci<Palette.RGBSum(Data[i+Width]);          
        }
        for(int i=Width+1;i<n;i++) {
          if(ba[i]) Data[i]=Black;else if(white) Data[i]=White;
        }
      }
      public static int Blur(int c,int c0,int c1,int c2,int c3,int d0,int d1,int d2,int d3) {
        int r,g,b;
        r=(32*(c&255)+5*((c0&255)+(c1&255)+(c2&255)+(c3&255))+3*((d0&255)+(d1&255)+(d2&255)+(d3&255)))/64;
        g=((32*(c&0xff00)+5*((c0&0xff00)+(c1&0xff00)+(c2&0xff00)+(c3&0xff00))+3*((d0&0xff00)+(d1&0xff00)+(d2&0xff00)+(d3&0xff00)))/64)&0xff00;
        b=((32*(c&0xff0000)+5*((c0&0xff0000)+(c1&0xff0000)+(c2&0xff0000)+(c3&0xff0000))+3*((d0&0xff0000)+(d1&0xff0000)+(d2&0xff0000)+(d3&0xff0000)))/64)&0xff0000;
        return r|g|b|(c&(255<<24));
      }
      public void Filter(int x0,int y0,int x1,int y1,bool closed,int mode) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        if(x0>x1||y0>y1) return;
        int[] line=new int[2*Width];
        int g,w=x1-x0+1,x,idx;
        bool even=false;        
        for(int y=y0;y<=y1;y++) {
          g=even?Width:0;
          for(x=0,idx=y*Width+x0;x<w;x++,idx++) {
            int c=Data[idx],c0=Data[idx-1],c1=Data[idx+1],c2=Data[idx-Width],c3=Data[idx+Width];
            int d0=Data[idx-Width-1],d1=Data[idx-Width+1],d2=Data[idx+Width-1],d3=Data[idx+Width+1];
            if(closed) {
              if(x==0) c0=d0=d2=c;
              if(x==w-1) c1=d1=d3=c;
              if(y==y0) c2=d0=d1=c;
              if(y==y1) c3=d2=d3=c;
            }
            line[g++]=Blur(c,c0,c1,c2,c3,d0,d1,d2,d3);
          }
          g=even?0:Width;
          if(y>y0) for(x=0,idx=(y-1)*Width+x0;x<w;x++,idx++) Data[idx]=line[g+x];
          g=even?0:Width;
          even^=true;
        }
        g=even?0:Width;
        idx=y1*Width+x0;
        for(x=0;x<w;x++,idx++) Data[idx]=line[g+x];
      }
      public void RGB2CMY(bool inv) {
        if(Data!=null) for(int i=0;i<Data.Length;i++) Data[i]=Palette.RGB2CMY(Data[i],inv);
      }
      public void RGB2CMY(int x0,int y0,int x1,int y1,bool inv) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int idx=y0*Width+x0;
          for(int x=x0;x<=x1;x++,idx++)
            Data[idx]=Palette.RGB2CMY(Data[idx],inv);
          y0++;
        }
      }
      public void RGBShift(int mode) {
        if(Data!=null) for(int i=0;i<Data.Length;i++) Data[i]=Palette.RGBShift(mode,Data[i]);
      }
      public void RGBShift(int mode,int x0,int y0,int x1,int y1) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int idx=y0*Width+x0;
          for(int x=x0;x<=x1;x++,idx++)
            Data[idx]=Palette.RGBShift(mode,Data[idx]);          
          y0++;
        }
      }
      public void Line(int x0,int y0,int x1,int y1,int color,bool whiteonly) {
        int r;
        if((x0<x1?x0>=Width||x1<0:x1>=Width||x0<0)||(y0<y1?y0>=Height||y1<0:y1>=Height||y0<0)) return;
        int dx=x1-x0,dy=y1-y0;
        if(dx<0) dx=-dx;if(dy<0) dy=-dy;
        int d=dx>dy?dx:dy;
        if(d==0) {XY(x0,y0,color,whiteonly);return;}
        dx=x1-x0;dy=y1-y0;
        for(int i=0;i<=d;i++) {
          int x=(d+2*(d*x0+i*dx))/d/2,y=(d+2*(d*y0+i*dy))/d/2;
          if(x>=0&&y>=0&&x<Width&&y<Height) {
            if(!whiteonly||(Data[y*Width+x]&0xffffff)==White)
              Data[y*Width+x]=color;
          }
        }
           
      }
/*      public int FillSide(int x,int y,int x0,int y0,int x1,int y1) {
        if(y0<y&&y1<y||y0>y&&y1>y||y0==y1) return 0;
        int x2=x0+(x1-x0)*(y-y0)/(y1-y0);
        return x2<x?y==y0?y1>y0?1:0:y==y1?y0>y1?1:0:1:0;
      }*/
      public void FillPath(List<int> path,int dx,int dy,int color) {
        int[] p=new int[path.Count];
        for(int i=0;i<p.Length;i+=2) {p[i]=path[i]+dx;p[i+1]=path[i+1]+dy;}
        int ix=p[0],iy=p[1],ax=p[0],ay=p[1];
        for(int i=0;i<p.Length;i+=2) {
          if(p[i]<ix) ix=p[i];else if(p[i]>ax) ax=p[i];
          if(p[i+1]<iy) iy=p[i+1];else if(p[i+1]>ay) ay=p[i+1];
        }
        if(ix>=Width||iy>=Height||ax<0||ay<0) return;
        if(ix<0) ix=0;if(iy<0) iy=0;
        if(ax>=Width) ax=Width-1;if(ay>=Height) ay=Height-1;
        int[] xa=new int[p.Length];
        bool[] ha=new bool[p.Length];
        for(int y=iy;y<=ay;y++) {
          int x1=p[p.Length-2],y1=p[p.Length-1],x2,y2;
          for(int i=0;i<p.Length;i+=2) {
            x2=x1;y2=y1;
            x1=p[i];y1=p[i+1];
            ha[i]=y1<y&&y2<y||y1>y&&y2>y||y1==y2;
            if(ha[i]) continue;
            int fx=x2-x1,fy=y2-y1;
            if(fx<0) fx=-fx;if(fy<0) fy=-fy;            
            int d=fx>fy?fx:fy,e=y2<y1?y1-y:y-y1;
            xa[i]=1+2*x1+2*(x2-x1)*e/fy;
          }        
          for(int x=ix;x<=ax;x++) {
            int n=0;
            x1=p[p.Length-2];y1=p[p.Length-1];
            for(int i=0;i<p.Length;i+=2) {
              x2=x1;y2=y1;
              x1=p[i];y1=p[i+1];
              if(ha[i]) continue;
              int r=xa[i]<=2*x?y==y1?y2>y1?1:0:y==y2?y1>y2?1:0:1:0;
              //int r=FillSide(x,y,x1,y1,x2,y2);
              n+=r;
            }
            if(0!=(n&1))
              Data[Width*y+x]=color;
          }
        }
      }
      public void BrushLine(int x0,int y0,int x1,int y1,int color,bmap brush,bool whiteonly) {
        if(brush==null) { Line(x0,y0,x1,y1,color,whiteonly);return;}
        int r;
        int bx=brush.Width/2,by=brush.Height/2;
        if((x0<x1?x0>=Width+brush.Width||x1<-brush.Width:x1>=Width+brush.Width||x0<-brush.Width)||(y0<y1?y0>=Height+brush.Height||y1<-brush.Height:y1>=Height+brush.Height||y0<-brush.Height)) return;
        int dx=x1-x0,dy=y1-y0;
        if(dx<0) dx=-dx;if(dy<0) dy=-dy;
        int d=dx>dy?dx:dy;
        if(d==0) {Brush(x0,y0,color,brush,whiteonly);return;}
        dx=x1-x0;dy=y1-y0;
        for(int i=0;i<=d;i++) {
          //int x=x0+i*dx/d,y=y0+i*dy/d;
          int x=(d+2*(d*x0+i*dx))/d/2,y=(d+2*(d*y0+i*dy))/d/2;          
          Brush(x,y,color,brush,whiteonly);
        }
      }
      public bmap Extend(int x0,int y0,int x1,int y1,int color,bool border) {
        R.Norm(ref x0,ref y0,ref x1,ref y1);
        if(x0>0) x0=0;if(y0>0) y0=0;
        if(x1<Width-1) x1=Width-1;if(y1<Height-1) y1=Height-1;
        if(x0==0&&y0==0&&x1==Width-1&&y1==Height-1) return null;        
        int w=x1-x0+1,h=y1-y0+1;
        if(w>16384||h>16384||w*h>64*1048576) return null;
        bmap dst=new bmap(w,h);
        dst.Clear(color);
        if(border) dst.CopyRectangle(this,1,1,Width-2,Height-2,1-x0,1-y0,-1);
        else dst.CopyRectangle(this,0,0,Width,Height,-x0,-y0,-1);
        return dst;        
      }
      public void Morph(bmap source,int[] pts) {
        int s1=sabs(pts[2]-pts[0],pts[3]-pts[1]),s2=sabs(pts[8]-pts[2],pts[9]-pts[3]);
        int s3=sabs(pts[6]-pts[4],pts[7]-pts[5]),s4=sabs(pts[0]-pts[6],pts[1]-pts[7]);
        int s5=sabs(pts[4]-pts[0],pts[5]-pts[1]),s6=sabs(pts[6]-pts[2],pts[7]-pts[3]);
        int d1=sabs(pts[10]-pts[8],pts[11]-pts[9]),d2=sabs(pts[12]-pts[10],pts[13]-pts[11]);
        int d3=sabs(pts[14]-pts[12],pts[15]-pts[13]),d4=sabs(pts[8]-pts[14],pts[9]-pts[15]);
        int d5=sabs(pts[12]-pts[8],pts[13]-pts[9]),d6=sabs(pts[14]-pts[10],pts[15]-pts[11]);                
        if(d3>d1) d1=d3;if(d4>d2) d2=d4;if(d6>d5) d5=d6;if(d3>d1) d1=d3;if(d5>d1) d1=d5;
        if(s3>s1) s1=s3;if(s4>s2) s2=s4;if(s6>s5) s5=s6;if(s3>s1) s1=s3;if(s5>s1) s1=s5;
        if(s1>d1) d1=s1;
        int n1=32,n=(d1+n1)&~(n1-1),n2=n/n1,n22=n2/2;
        int[] count=new int[Data.Length];
        for(int y0=0,y1=n;y1>=0;y0++,y1--)
          for(int x0=0,x1=n;x1>=0;x0++,x1--) {
            int dxa=(x1*pts[8]+x0*pts[10])/n1,dxb=(x1*pts[14]+x0*pts[12])/n1,dx=((y1*dxa+y0*dxb)/n+n22)/n2;
            int dya=(x1*pts[9]+x0*pts[11])/n1,dyb=(x1*pts[15]+x0*pts[13])/n1,dy=((y1*dya+y0*dyb)/n+n22)/n2;
            if(dx<0||dy<0||dx>=Width||dy>=Height) continue;
            int sxa=(x1*pts[0]+x0*pts[2])/n1,sxb=(x1*pts[6]+x0*pts[4])/n1,sx=(y1*sxa+y0*sxb)/n;
            int sya=(x1*pts[1]+x0*pts[3])/n1,syb=(x1*pts[7]+x0*pts[5])/n1,sy=(y1*sya+y0*syb)/n;
            dx=dy*Width+dx;
            int c=count[dx],color=source.Color(n2,sx,sy);
            if(color<0) continue;
            if(c>0) color=Palette.ColorMix(color,Data[dx],1,c);
            count[dx]=c+1;
            Data[dx]=color;
          }
      }
      public int Color(int div,int x,int y) {
        if(x<0||y<0) return -1;
        int px=x/div,py=y/div,cx=x-div*px,cy=y-div*py;
        if(px>=Width-1||py>=Height-1) return -1;
        int i=py*Width+px;
        int c0=Data[i],c1=Data[i+1],c2=Data[i+Width],c3=Data[i+Width+1];
        int dx=div-cx,dy=div-cy;
        int e0=dx*dy,e1=cx*dy,e2=dx*cy,e3=cx*cy;
        div=div*div;
        int r=(e0*(c0&255)+e1*(c1&255)+e2*(c2&255)+e3*(c3&255))/div;
        int g=(e0*((c0>>8)&255)+e1*((c1>>8)&255)+e2*((c2>>8)&255)+e3*((c3>>8)&255))/div;
        int b=(e0*((c0>>16)&255)+e1*((c1>>16)&255)+e2*((c2>>16)&255)+e3*((c3>>16)&255))/div;
        return (r&255)|(g<<8)|(b<<16);
      }
    }
				public struct PathPoint {
		  public int x,y;
			public bool stop;
			public PathPoint(int X,int Y,bool Stop) { x=X;y=Y;stop=Stop;}
			public PathPoint(int X,int Y) { x=X;y=Y;stop=false;}
			public PointPath List() { PointPath l=new PointPath();l.Add(this);return l;}
		  public override string ToString() { return ""+x+","+y+(stop?",O":"")+"";}
	  }
    public class FillPattern {
      public bmap BMap;
      public int X,Y,TrColor;
      public bool MX,MY;
      public bool Enabled;

      public FillPattern(int trcolor) { TrColor=trcolor;}

      public int Color(int x,int y) {
         int rx,ry,rc;
         x-=X;y-=Y;
         if(MX) { rx=bmap.modp(x,2*BMap.Width);if(rx>=BMap.Width) rx=2*BMap.Width-1-rx;} else rx=bmap.modp(x,BMap.Width);
         if(MY) { ry=bmap.modp(y,2*BMap.Height);if(ry>=BMap.Height) ry=2*BMap.Height-1-ry;} else ry=bmap.modp(y,BMap.Height);
         rc=BMap.Data[BMap.Width*ry+rx]&bmap.White;
         return rc==TrColor?-1:rc;
      }
    }
		public class PointPath {
		  public PathPoint[] pt=new PathPoint[16];
			public int Count;
			public bool Closed;
			public void Add(int x,int y) { Add(new PathPoint(x,y));}
			public void Add(PathPoint pp) {
			  if(Count==pt.Length) Array.Resize(ref pt,Count*2);
				pt[Count++]=pp;
			}
			public void SetStop() {if(Count>0) {			  
			  PathPoint pp=pt[Count-1];
				pp.stop=true;
			  pt[Count-1]=pp;
			  } else Closed=true;
			}
			public PathPoint this[int index] { get {return pt[index];} set {pt[index]=value;}}
			public void Clear() {Count=0;Closed=false;}
      public int X { get {return Count<1?int.MaxValue:pt[0].x;}}
      public int Y { get {return Count<1?int.MaxValue:pt[0].y;}}

		}

    public static class R {
      public static int[] Copy(int[] rect) { return rect.Clone() as int[];}
      public static int Width(int[] rect) { return Math.Abs(rect[2]-rect[0])+1;}
      public static int Height(int[] rect) { return Math.Abs(rect[3]-rect[1])+1;}
      public static bool IsPoint(int[] rect) { return rect[0]==rect[2]&&rect[1]==rect[3];}
      public static bool Intersected(int[] rect,int x,int y,int x2,int y2) {
        return !(x>rect[2]||x2<rect[0]||y>rect[3]||y2<rect[1]);
      }
      public static void Union(int[] rect,int x,int y,int x2,int y2) {
        if(x<rect[0]) rect[0]=x;if(x2>rect[2]) rect[2]=x2;
        if(y<rect[1]) rect[1]=y;if(y2>rect[3]) rect[3]=y2;
      }
      public static bool Union(ref int l,ref int t,ref int r,ref int b,int x,int y,int x2,int y2) {
        if(x<l) l=x;if(x2>r) r=x2;
        if(y<t) t=y;if(y2>b) b=y2;
        return true;
      }      
      public static bool Intersect(int[] rect,int x,int y,int x2,int y2) {
        if(x>rect[2]||x2<rect[0]||y>rect[3]||y2<rect[1]) return false;
        if(x>rect[0]) rect[0]=x;if(x2<rect[2]) rect[2]=x2;
        if(y>rect[1]) rect[1]=y;if(y2<rect[3]) rect[3]=y2;
        return true;
      }
      public static void Norm(int[] rect) {
        int r;
        if(rect[0]>rect[2]) {r=rect[0];rect[0]=rect[2];rect[2]=r;}
        if(rect[1]>rect[3]) {r=rect[1];rect[1]=rect[3];rect[3]=r;}
      }
      public static void Norm(ref int x,ref int y,ref int x2,ref int y2) {
        int r;
        if(x>x2) {r=x;x=x2;x2=r;}
        if(y>y2) {r=y;y=y2;y2=r;}
      }      
			public static bool Inside(int[] rect,int x,int y) {			  
			  return rect[0]<=x&&x<=rect[2]&&rect[1]<=y&&y<=rect[3];
			}
			public static bool Inside(int[] rect,int x,int y,int x2,int y2) {			  
			  return rect[0]>=x&&rect[2]<=x2&&rect[1]>=y&&rect[3]<=y2;
			}
			public static void Shift(int[] rect,int dx,int dy) {
			  rect[0]+=dx;rect[1]+=dy;
				rect[2]+=dx;rect[3]+=dy;
			}

    }
}