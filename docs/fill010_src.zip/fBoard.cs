﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace grcol {
	public partial class fBoard : Form {
	  fMain Main;
		internal bool Updates;
		internal List<string> Brushes=new List<string>();
		internal List<string> Shapes=new List<string>();

		void Brush(string name,string code) {
		  Brushes.Add(name);Brushes.Add(code);
		}
		void Shape(string name,string code) {
		  Shapes.Add(name);Shapes.Add(code);
		}
    public fBoard(fMain main) {
			InitializeComponent();
			Main=main;
			cbRepeatMode.SelectedIndex=0;
			cbFill.SelectedIndex=0;
			
			Brush("Dot",null);
			Brush("Box 2x2","11.11");
			Brush("Plus 3x3","010.111.010");
			Brush("Circle 4.4","0110.1111.1111.0110,1111.1111.1111.1111");
			Brush("Circle 5x5","01110.11111.11111.11111.01110,00100.01110.11111.01110.00100");
			Brush("Vertical |","11.11.11.11.11.11.11.11");
			Brush("Horizontal --","11111111.11111111");
			Brush("Double dot :","111.111.111.000.000.000.111.111.111");
			Brush("Raise /","00000011.00000111.00001110.00011100.00111000.01110000.11100000.11000000");
			Brush("Fall \\","11000000.11100000.01110000.00111000.00011100.00001110.00000111.00000011");
			Brush("Diamond 7x7","0001000.0011100.0111110.1111111.0111110.0011100.0001000");
			Brush("Octa 10x10","0001111000.0011111100.0111111110.1111111111.1111111111.1111111111.1111111111.0111111110.0011111100.0001111000");
			cbBrush.Items.Clear();
			for(int i=0;i<Brushes.Count;i+=2)
			  cbBrush.Items.Add(Brushes[i]);
			cbBrush.SelectedIndex=0;

			Shape("Rectangle","rectangle,rounded");
			Shape("Diamond","diamond,diamond2");
			Shape("Triangle","triangle,triangle90");
			Shape("Arrow","arrow,arrow2");
			Shape("Hexagon","hexagon");
			Shape("Octa","octa");
			Shape("Circle","circle,circle2");
			Shape("Star 8/16","star8,star16");
			Shape("Star 5","star");
			cbShape.Items.Clear();
			for(int i=0;i<Shapes.Count;i+=2)
			  cbShape.Items.Add(Shapes[i]);
			cbShape.SelectedIndex=0;

			
			Updates=true;
		}

		public RepeatOp RepeatMode {get { return (RepeatOp)(1+cbRepeatMode.SelectedIndex);}}

		protected override void OnClosing(CancelEventArgs e) {
		  e.Cancel=true;
			Hide();
		}

		private void Update(object sender, EventArgs e) {
		  if(sender is Button) { Cmd(sender,e);return;}
		  if(Updates) Main.UpdateBoard();
		}

		private void Cmd(object sender, EventArgs e) {
		  Control btn=sender as Control;
		  string cmd=""+btn.Tag;
			switch(cmd) {
			 case "levels":Main.ProcessCommand("levels "+levelsCount.Text);break;
			 case "bw":Main.ProcessCommand("bw "+BWLevel.Text+(BWMax.Checked?" max":BWMin.Checked?" min":""));break;
       case "remove_dots":Main.ProcessCommand("remove_dots "+(chRemDotWhite.Checked?" wh":"")+(chRemDotBlack.Checked?" bl":"")+(rRemDot3.Checked?" 3":rRemDot8.Checked?" 8":" 4"));break;
       case "remove_dust":Main.ProcessCommand("remove_dust "+dustLevel.Text+" "+(blackDust.Checked?" bl":"")+(whiteDust.Checked?" wh":""));break;
			 case "border":
        if(GDI.CtrlKey) {
          int x;
          if(int.TryParse(borderLevel.Text,out x)) borderLevel.Text=""+(x+1);
          Main.Undo(false);
        }
        Main.ProcessCommand("border "+borderLevel.Text+(X8.Checked?" x8":""));
        if(GDI.ShiftKey) { 
          int x;
          if(int.TryParse(borderLevel.Text,out x)&&x>0) borderLevel.Text=""+(x-1);
        }
        break;
			 case "invert":Main.ProcessCommand("invert "+(cbInvertIntensity.Checked?" intensity":"")+(cbInvertBW.Checked?"bw":""));break;
			 case "contrast":Main.ProcessCommand("contrast "+(cbContrast.Checked?" rgb":""));break;
       case "dark":
       case "bright":Main.ProcessCommand(cmd+(chBrightBW.Checked?" bw":""));break;
			 case "expand":
			  Main.ProcessCommand("expand"+(X8.Checked?" x8":"")+(ExpandWOnly.Checked?" wonly":"")+(ExpandWhite.Checked?" white":""));
				break;
			 case "impand":
			  Main.ProcessCommand("impand "+(chImpandBlack.Checked?0:Main.Color1)+" "+Main.Color2+(ExpandWhite.Checked?" repeat":""));
				break;
			 default:Main.ProcessCommand(cmd);break;
			}

		}

    protected override bool ProcessCmdKey(ref Message msg,Keys keyData) {
      switch(keyData) {
  		 case Keys.F1:Main.ProcessCommand("help");return true;
			 case Keys.Escape:
       case Keys.Space:
			 case Keys.F10:Main.ProcessCommand("board");return true;
			 case Keys.F11:Main.Fullscreen();return true;
       case Keys.A|Keys.Control:Main.SelectAll();return true;
       case Keys.D1|Keys.Control:tabControl1.SelectTab(0);return true;
       case Keys.D2|Keys.Control:tabControl1.SelectTab(1);return true;
       case Keys.D3|Keys.Control:tabControl1.SelectTab(2);return true;
       case Keys.D4|Keys.Control:tabControl1.SelectTab(3);return true;
       case Keys.Z|Keys.Control:Main.Undo();break;
       case Keys.Y|Keys.Control:Main.Redo();break;
			}
			return false;
		}

		private void cbBrush_SelectedIndexChanged(object sender, EventArgs e) {
		  if(!Updates) return;  
		  int i=2*cbBrush.SelectedIndex+1;
			if(Brushes.Count>i) Main.ProcessCommand("brush "+Brushes[i]);
		   
		}

		private void cbShape_SelectedIndexChanged(object sender, EventArgs e) {
		  if(!Updates) return;  
		  int i=2*cbShape.SelectedIndex+1;
			if(Brushes.Count<=i) return;
			string shape=Shapes[i];
			if(shape.IndexOf(',')>=0) {
        string[] sa=shape.Split(',');
        i=0;
        if(GDI.ShiftKey) i=2;
        if(GDI.CtrlKey) i++;
        shape=sa[i<sa.Length?i:sa.Length-1];
			}
			Main.ProcessCommand("shape "+shape);
		}

    private void pasteDiff_CheckedChanged(object sender, EventArgs e) {
      if(Main.MovePaste) {
        Main.MoveDiff=pasteDiff.Checked;
        Main.MoveXor=pasteXOR.Checked;
        Main.UpdatePaste();
      }
    }

    private void SnapChanged(object sender, EventArgs e) {
      string txt=Snap.Text;      
      int snap=0;
      if(chSnap.Checked&&txt!=""&&!int.TryParse(txt,out snap)) Snap.Text="0";      
      Main.snap=snap>1?snap:0;

    }
  }
}
