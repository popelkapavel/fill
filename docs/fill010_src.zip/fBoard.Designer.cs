﻿namespace grcol
{
	partial class fBoard
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      this.ExpandB = new System.Windows.Forms.Button();
      this.X8 = new System.Windows.Forms.CheckBox();
      this.ExpandWhite = new System.Windows.Forms.CheckBox();
      this.ExpandWOnly = new System.Windows.Forms.CheckBox();
      this.UndoB = new System.Windows.Forms.Button();
      this.RedoB = new System.Windows.Forms.Button();
      this.ScreenB = new System.Windows.Forms.Button();
      this.ExpandDiffB = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.lFill = new System.Windows.Forms.Label();
      this.Fill2Black = new System.Windows.Forms.CheckBox();
      this.FillD8 = new System.Windows.Forms.CheckBox();
      this.label3 = new System.Windows.Forms.Label();
      this.toolTip = new System.Windows.Forms.ToolTip(this.components);
      this.FillNoBlack = new System.Windows.Forms.CheckBox();
      this.DrawWOnly = new System.Windows.Forms.CheckBox();
      this.bGray = new System.Windows.Forms.Button();
      this.Invert = new System.Windows.Forms.Button();
      this.cbInvertBW = new System.Windows.Forms.CheckBox();
      this.cbInvertIntensity = new System.Windows.Forms.CheckBox();
      this.rgb2cmyB = new System.Windows.Forms.Button();
      this.rgbshiftB = new System.Windows.Forms.Button();
      this.levelsB = new System.Windows.Forms.Button();
      this.contour = new System.Windows.Forms.Button();
      this.BW = new System.Windows.Forms.Button();
      this.cbContrast = new System.Windows.Forms.CheckBox();
      this.bBorder = new System.Windows.Forms.Button();
      this.bRemoveDots = new System.Windows.Forms.Button();
      this.chRemDotWhite = new System.Windows.Forms.CheckBox();
      this.chRemDotBlack = new System.Windows.Forms.CheckBox();
      this.rRemDot3 = new System.Windows.Forms.RadioButton();
      this.rRemDot4 = new System.Windows.Forms.RadioButton();
      this.rRemDot8 = new System.Windows.Forms.RadioButton();
      this.NormColorB = new System.Windows.Forms.Button();
      this.chBrightBW = new System.Windows.Forms.CheckBox();
      this.button1 = new System.Windows.Forms.Button();
      this.Snap = new System.Windows.Forms.TextBox();
      this.chSnap = new System.Windows.Forms.CheckBox();
      this.ImpandB = new System.Windows.Forms.Button();
      this.chImpandBlack = new System.Windows.Forms.CheckBox();
      this.bRemoveDust = new System.Windows.Forms.Button();
      this.dustLevel = new System.Windows.Forms.TextBox();
      this.blackDust = new System.Windows.Forms.CheckBox();
      this.whiteDust = new System.Windows.Forms.CheckBox();
      this.cbFill = new System.Windows.Forms.ComboBox();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tp1 = new System.Windows.Forms.TabPage();
      this.tp3 = new System.Windows.Forms.TabPage();
      this.cbRepeatMode = new System.Windows.Forms.ComboBox();
      this.RepeatCenter = new System.Windows.Forms.CheckBox();
      this.RepeatCount = new System.Windows.Forms.TextBox();
      this.lRepeat = new System.Windows.Forms.Label();
      this.RepeatOn = new System.Windows.Forms.CheckBox();
      this.RepeatX = new System.Windows.Forms.TextBox();
      this.RepeatY = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cbBrush = new System.Windows.Forms.ComboBox();
      this.cbShape = new System.Windows.Forms.ComboBox();
      this.lShape = new System.Windows.Forms.Label();
      this.ShapeAdjust = new System.Windows.Forms.CheckBox();
      this.ShapeMirrorY = new System.Windows.Forms.CheckBox();
      this.ShapeMirrorX = new System.Windows.Forms.CheckBox();
      this.DrawFilled = new System.Windows.Forms.CheckBox();
      this.DrawOrto = new System.Windows.Forms.CheckBox();
      this.DrawBlack = new System.Windows.Forms.CheckBox();
      this.DrawCenter = new System.Windows.Forms.CheckBox();
      this.lDraw = new System.Windows.Forms.Label();
      this.tp2 = new System.Windows.Forms.TabPage();
      this.pasteExtend = new System.Windows.Forms.CheckBox();
      this.pasteRepeat = new System.Windows.Forms.CheckBox();
      this.pasteTRX = new System.Windows.Forms.CheckBox();
      this.pasteTrans = new System.Windows.Forms.CheckBox();
      this.pasteDiff = new System.Windows.Forms.CheckBox();
      this.pasteXOR = new System.Windows.Forms.CheckBox();
      this.pasteQuad = new System.Windows.Forms.CheckBox();
      this.tp4 = new System.Windows.Forms.TabPage();
      this.panel1 = new System.Windows.Forms.Panel();
      this.borderLevel = new System.Windows.Forms.TextBox();
      this.darkB = new System.Windows.Forms.Button();
      this.brightB = new System.Windows.Forms.Button();
      this.redoB2 = new System.Windows.Forms.Button();
      this.undoB2 = new System.Windows.Forms.Button();
      this.levelsCount = new System.Windows.Forms.TextBox();
      this.BWPanel = new System.Windows.Forms.Panel();
      this.BWMax = new System.Windows.Forms.RadioButton();
      this.BWMin = new System.Windows.Forms.RadioButton();
      this.BWAvg = new System.Windows.Forms.RadioButton();
      this.BWLevel = new System.Windows.Forms.TextBox();
      this.pasteMix = new System.Windows.Forms.CheckBox();
      this.tabControl1.SuspendLayout();
      this.tp1.SuspendLayout();
      this.tp3.SuspendLayout();
      this.tp2.SuspendLayout();
      this.tp4.SuspendLayout();
      this.panel1.SuspendLayout();
      this.BWPanel.SuspendLayout();
      this.SuspendLayout();
      // 
      // ExpandB
      // 
      this.ExpandB.Location = new System.Drawing.Point(140, 15);
      this.ExpandB.Name = "ExpandB";
      this.ExpandB.Size = new System.Drawing.Size(55, 23);
      this.ExpandB.TabIndex = 10;
      this.ExpandB.Tag = "expand";
      this.ExpandB.Text = "Expand";
      this.toolTip.SetToolTip(this.ExpandB, "Expand black color by 1 pixel.\r\nUses X8 switch.\r\n\r\n");
      this.ExpandB.UseVisualStyleBackColor = true;
      this.ExpandB.Click += new System.EventHandler(this.Cmd);
      // 
      // X8
      // 
      this.X8.AutoSize = true;
      this.X8.Location = new System.Drawing.Point(47, 100);
      this.X8.Name = "X8";
      this.X8.Size = new System.Drawing.Size(39, 17);
      this.X8.TabIndex = 11;
      this.X8.Text = "X8";
      this.X8.UseVisualStyleBackColor = true;
      // 
      // ExpandWhite
      // 
      this.ExpandWhite.AutoSize = true;
      this.ExpandWhite.Location = new System.Drawing.Point(80, 18);
      this.ExpandWhite.Name = "ExpandWhite";
      this.ExpandWhite.Size = new System.Drawing.Size(54, 17);
      this.ExpandWhite.TabIndex = 13;
      this.ExpandWhite.Text = "White";
      this.toolTip.SetToolTip(this.ExpandWhite, "Convert white pixels around nonwhite pixels to black.\r\n");
      this.ExpandWhite.UseVisualStyleBackColor = true;
      // 
      // ExpandWOnly
      // 
      this.ExpandWOnly.AutoSize = true;
      this.ExpandWOnly.Location = new System.Drawing.Point(16, 18);
      this.ExpandWOnly.Name = "ExpandWOnly";
      this.ExpandWOnly.Size = new System.Drawing.Size(58, 17);
      this.ExpandWOnly.TabIndex = 14;
      this.ExpandWOnly.Text = "WOnly";
      this.toolTip.SetToolTip(this.ExpandWOnly, "Expand only to white pixels.");
      this.ExpandWOnly.UseVisualStyleBackColor = true;
      // 
      // UndoB
      // 
      this.UndoB.Location = new System.Drawing.Point(302, 100);
      this.UndoB.Name = "UndoB";
      this.UndoB.Size = new System.Drawing.Size(53, 23);
      this.UndoB.TabIndex = 15;
      this.UndoB.Tag = "undo";
      this.UndoB.Text = "Undo";
      this.UndoB.UseVisualStyleBackColor = true;
      this.UndoB.Click += new System.EventHandler(this.Cmd);
      // 
      // RedoB
      // 
      this.RedoB.Location = new System.Drawing.Point(361, 100);
      this.RedoB.Name = "RedoB";
      this.RedoB.Size = new System.Drawing.Size(53, 23);
      this.RedoB.TabIndex = 16;
      this.RedoB.Tag = "redo";
      this.RedoB.Text = "Redo";
      this.RedoB.UseVisualStyleBackColor = true;
      this.RedoB.Click += new System.EventHandler(this.Cmd);
      // 
      // ScreenB
      // 
      this.ScreenB.Location = new System.Drawing.Point(234, 100);
      this.ScreenB.Name = "ScreenB";
      this.ScreenB.Size = new System.Drawing.Size(53, 23);
      this.ScreenB.TabIndex = 18;
      this.ScreenB.Tag = "screen 1000";
      this.ScreenB.Text = "Screen";
      this.toolTip.SetToolTip(this.ScreenB, "Take screenshoot");
      this.ScreenB.UseVisualStyleBackColor = true;
      this.ScreenB.Click += new System.EventHandler(this.Cmd);
      // 
      // ExpandDiffB
      // 
      this.ExpandDiffB.Location = new System.Drawing.Point(234, 14);
      this.ExpandDiffB.Name = "ExpandDiffB";
      this.ExpandDiffB.Size = new System.Drawing.Size(55, 23);
      this.ExpandDiffB.TabIndex = 19;
      this.ExpandDiffB.Tag = "expand diff";
      this.ExpandDiffB.Text = "Diff";
      this.toolTip.SetToolTip(this.ExpandDiffB, "Convert inner black pixels to white pixels.\r\nUse X8 switch.");
      this.ExpandDiffB.UseVisualStyleBackColor = true;
      this.ExpandDiffB.Click += new System.EventHandler(this.Cmd);
      // 
      // label2
      // 
      this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label2.Location = new System.Drawing.Point(13, 40);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(400, 2);
      this.label2.TabIndex = 27;
      // 
      // lFill
      // 
      this.lFill.AutoSize = true;
      this.lFill.Location = new System.Drawing.Point(44, 54);
      this.lFill.Name = "lFill";
      this.lFill.Size = new System.Drawing.Size(34, 13);
      this.lFill.TabIndex = 28;
      this.lFill.Text = "Fill (F)";
      // 
      // Fill2Black
      // 
      this.Fill2Black.AutoSize = true;
      this.Fill2Black.Checked = true;
      this.Fill2Black.CheckState = System.Windows.Forms.CheckState.Checked;
      this.Fill2Black.Location = new System.Drawing.Point(207, 54);
      this.Fill2Black.Name = "Fill2Black";
      this.Fill2Black.Size = new System.Drawing.Size(62, 17);
      this.Fill2Black.TabIndex = 29;
      this.Fill2Black.Text = "2 Black";
      this.toolTip.SetToolTip(this.Fill2Black, "Fill to black color.\r\nOtherwise fill color under cursor.");
      this.Fill2Black.UseVisualStyleBackColor = true;
      // 
      // FillD8
      // 
      this.FillD8.AutoSize = true;
      this.FillD8.Location = new System.Drawing.Point(167, 54);
      this.FillD8.Name = "FillD8";
      this.FillD8.Size = new System.Drawing.Size(40, 17);
      this.FillD8.TabIndex = 30;
      this.FillD8.Text = "D8";
      this.toolTip.SetToolTip(this.FillD8, "Switch between fill 4 or 8 pixel in one step");
      this.FillD8.UseVisualStyleBackColor = true;
      // 
      // label3
      // 
      this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label3.Location = new System.Drawing.Point(16, 85);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(400, 2);
      this.label3.TabIndex = 38;
      // 
      // toolTip
      // 
      this.toolTip.AutomaticDelay = 1000;
      // 
      // FillNoBlack
      // 
      this.FillNoBlack.AutoSize = true;
      this.FillNoBlack.Checked = true;
      this.FillNoBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.FillNoBlack.Location = new System.Drawing.Point(268, 53);
      this.FillNoBlack.Name = "FillNoBlack";
      this.FillNoBlack.Size = new System.Drawing.Size(70, 17);
      this.FillNoBlack.TabIndex = 54;
      this.FillNoBlack.Text = "No Black";
      this.toolTip.SetToolTip(this.FillNoBlack, "Fill to black color.\r\nOtherwise fill color under cursor.");
      this.FillNoBlack.UseVisualStyleBackColor = true;
      // 
      // DrawWOnly
      // 
      this.DrawWOnly.AutoSize = true;
      this.DrawWOnly.Location = new System.Drawing.Point(339, 63);
      this.DrawWOnly.Name = "DrawWOnly";
      this.DrawWOnly.Size = new System.Drawing.Size(58, 17);
      this.DrawWOnly.TabIndex = 59;
      this.DrawWOnly.Text = "WOnly";
      this.toolTip.SetToolTip(this.DrawWOnly, "Draw only on white.");
      this.DrawWOnly.UseVisualStyleBackColor = true;
      // 
      // bGray
      // 
      this.bGray.Location = new System.Drawing.Point(240, 21);
      this.bGray.Name = "bGray";
      this.bGray.Size = new System.Drawing.Size(48, 23);
      this.bGray.TabIndex = 67;
      this.bGray.Tag = "gray";
      this.bGray.Text = "Gray";
      this.toolTip.SetToolTip(this.bGray, "Convert to grayscale");
      this.bGray.UseVisualStyleBackColor = true;
      this.bGray.Click += new System.EventHandler(this.Cmd);
      // 
      // Invert
      // 
      this.Invert.Location = new System.Drawing.Point(215, 45);
      this.Invert.Name = "Invert";
      this.Invert.Size = new System.Drawing.Size(48, 23);
      this.Invert.TabIndex = 66;
      this.Invert.Tag = "invert";
      this.Invert.Text = "Invert";
      this.toolTip.SetToolTip(this.Invert, "Invert color or intensity");
      this.Invert.UseVisualStyleBackColor = true;
      this.Invert.Click += new System.EventHandler(this.Cmd);
      // 
      // cbInvertBW
      // 
      this.cbInvertBW.AutoSize = true;
      this.cbInvertBW.Location = new System.Drawing.Point(200, 49);
      this.cbInvertBW.Name = "cbInvertBW";
      this.cbInvertBW.Size = new System.Drawing.Size(15, 14);
      this.cbInvertBW.TabIndex = 65;
      this.toolTip.SetToolTip(this.cbInvertBW, "Invert black & white");
      this.cbInvertBW.UseVisualStyleBackColor = true;
      // 
      // cbInvertIntensity
      // 
      this.cbInvertIntensity.AutoSize = true;
      this.cbInvertIntensity.Location = new System.Drawing.Point(185, 49);
      this.cbInvertIntensity.Name = "cbInvertIntensity";
      this.cbInvertIntensity.Size = new System.Drawing.Size(15, 14);
      this.cbInvertIntensity.TabIndex = 64;
      this.toolTip.SetToolTip(this.cbInvertIntensity, "Invert intensity");
      this.cbInvertIntensity.UseVisualStyleBackColor = true;
      // 
      // rgb2cmyB
      // 
      this.rgb2cmyB.Location = new System.Drawing.Point(94, 46);
      this.rgb2cmyB.Name = "rgb2cmyB";
      this.rgb2cmyB.Size = new System.Drawing.Size(89, 23);
      this.rgb2cmyB.TabIndex = 56;
      this.rgb2cmyB.Tag = "rgb cmy";
      this.rgb2cmyB.Text = "RGB<=>CMY";
      this.toolTip.SetToolTip(this.rgb2cmyB, "Change RGB to complement CMY colors");
      this.rgb2cmyB.UseVisualStyleBackColor = true;
      this.rgb2cmyB.Click += new System.EventHandler(this.Cmd);
      // 
      // rgbshiftB
      // 
      this.rgbshiftB.Location = new System.Drawing.Point(28, 46);
      this.rgbshiftB.Name = "rgbshiftB";
      this.rgbshiftB.Size = new System.Drawing.Size(64, 23);
      this.rgbshiftB.TabIndex = 57;
      this.rgbshiftB.Tag = "rgb";
      this.rgbshiftB.Text = "RGB >>";
      this.toolTip.SetToolTip(this.rgbshiftB, "Switch RGB color parts");
      this.rgbshiftB.UseVisualStyleBackColor = true;
      this.rgbshiftB.Click += new System.EventHandler(this.Cmd);
      // 
      // levelsB
      // 
      this.levelsB.Location = new System.Drawing.Point(293, 46);
      this.levelsB.Name = "levelsB";
      this.levelsB.Size = new System.Drawing.Size(53, 23);
      this.levelsB.TabIndex = 58;
      this.levelsB.Tag = "levels";
      this.levelsB.Text = "Levels";
      this.toolTip.SetToolTip(this.levelsB, "Modify color intensity to number of levels.");
      this.levelsB.UseVisualStyleBackColor = true;
      this.levelsB.Click += new System.EventHandler(this.Cmd);
      // 
      // contour
      // 
      this.contour.Location = new System.Drawing.Point(352, 46);
      this.contour.Name = "contour";
      this.contour.Size = new System.Drawing.Size(53, 23);
      this.contour.TabIndex = 60;
      this.contour.Tag = "contour";
      this.contour.Text = "Contour";
      this.toolTip.SetToolTip(this.contour, "Make black contour between color levels");
      this.contour.UseVisualStyleBackColor = true;
      this.contour.Click += new System.EventHandler(this.Cmd);
      // 
      // BW
      // 
      this.BW.Location = new System.Drawing.Point(197, 21);
      this.BW.Name = "BW";
      this.BW.Size = new System.Drawing.Size(37, 23);
      this.BW.TabIndex = 62;
      this.BW.Tag = "bw";
      this.BW.Text = "BW";
      this.toolTip.SetToolTip(this.BW, "Convert to black & white image.\r\nEverything under level is black.\r\nMin,avg max se" +
        "ts value to compare with level.");
      this.BW.UseVisualStyleBackColor = true;
      this.BW.Click += new System.EventHandler(this.Cmd);
      // 
      // cbContrast
      // 
      this.cbContrast.AutoSize = true;
      this.cbContrast.Location = new System.Drawing.Point(165, 127);
      this.cbContrast.Name = "cbContrast";
      this.cbContrast.Size = new System.Drawing.Size(15, 14);
      this.cbContrast.TabIndex = 73;
      this.toolTip.SetToolTip(this.cbContrast, "RGB contrast");
      this.cbContrast.UseVisualStyleBackColor = true;
      // 
      // bBorder
      // 
      this.bBorder.Location = new System.Drawing.Point(352, 21);
      this.bBorder.Name = "bBorder";
      this.bBorder.Size = new System.Drawing.Size(48, 23);
      this.bBorder.TabIndex = 74;
      this.bBorder.Tag = "border";
      this.bBorder.Text = "Border";
      this.toolTip.SetToolTip(this.bBorder, "Convert dark gradient pixels to black");
      this.bBorder.UseVisualStyleBackColor = true;
      this.bBorder.Click += new System.EventHandler(this.Cmd);
      // 
      // bRemoveDots
      // 
      this.bRemoveDots.Location = new System.Drawing.Point(352, 75);
      this.bRemoveDots.Name = "bRemoveDots";
      this.bRemoveDots.Size = new System.Drawing.Size(81, 23);
      this.bRemoveDots.TabIndex = 76;
      this.bRemoveDots.Tag = "remove_dots";
      this.bRemoveDots.Text = "Remove dots";
      this.toolTip.SetToolTip(this.bRemoveDots, "Replace pixel dots with avereage color");
      this.bRemoveDots.UseVisualStyleBackColor = true;
      this.bRemoveDots.Click += new System.EventHandler(this.Cmd);
      // 
      // chRemDotWhite
      // 
      this.chRemDotWhite.AutoSize = true;
      this.chRemDotWhite.Location = new System.Drawing.Point(331, 80);
      this.chRemDotWhite.Name = "chRemDotWhite";
      this.chRemDotWhite.Size = new System.Drawing.Size(15, 14);
      this.chRemDotWhite.TabIndex = 77;
      this.toolTip.SetToolTip(this.chRemDotWhite, "White");
      this.chRemDotWhite.UseVisualStyleBackColor = true;
      // 
      // chRemDotBlack
      // 
      this.chRemDotBlack.AutoSize = true;
      this.chRemDotBlack.Checked = true;
      this.chRemDotBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chRemDotBlack.Location = new System.Drawing.Point(313, 80);
      this.chRemDotBlack.Name = "chRemDotBlack";
      this.chRemDotBlack.Size = new System.Drawing.Size(15, 14);
      this.chRemDotBlack.TabIndex = 78;
      this.toolTip.SetToolTip(this.chRemDotBlack, "Black");
      this.chRemDotBlack.UseVisualStyleBackColor = true;
      // 
      // rRemDot3
      // 
      this.rRemDot3.AutoSize = true;
      this.rRemDot3.Location = new System.Drawing.Point(4, 3);
      this.rRemDot3.Name = "rRemDot3";
      this.rRemDot3.Size = new System.Drawing.Size(31, 17);
      this.rRemDot3.TabIndex = 79;
      this.rRemDot3.Text = "3";
      this.toolTip.SetToolTip(this.rRemDot3, "3 points");
      this.rRemDot3.UseVisualStyleBackColor = true;
      // 
      // rRemDot4
      // 
      this.rRemDot4.AutoSize = true;
      this.rRemDot4.Checked = true;
      this.rRemDot4.Location = new System.Drawing.Point(38, 3);
      this.rRemDot4.Name = "rRemDot4";
      this.rRemDot4.Size = new System.Drawing.Size(31, 17);
      this.rRemDot4.TabIndex = 80;
      this.rRemDot4.TabStop = true;
      this.rRemDot4.Text = "4";
      this.toolTip.SetToolTip(this.rRemDot4, "4 points");
      this.rRemDot4.UseVisualStyleBackColor = true;
      // 
      // rRemDot8
      // 
      this.rRemDot8.AutoSize = true;
      this.rRemDot8.Location = new System.Drawing.Point(72, 3);
      this.rRemDot8.Name = "rRemDot8";
      this.rRemDot8.Size = new System.Drawing.Size(31, 17);
      this.rRemDot8.TabIndex = 81;
      this.rRemDot8.Text = "8";
      this.toolTip.SetToolTip(this.rRemDot8, "8 points");
      this.rRemDot8.UseVisualStyleBackColor = true;
      // 
      // NormColorB
      // 
      this.NormColorB.Location = new System.Drawing.Point(181, 122);
      this.NormColorB.Name = "NormColorB";
      this.NormColorB.Size = new System.Drawing.Size(61, 23);
      this.NormColorB.TabIndex = 72;
      this.NormColorB.Tag = "contrast";
      this.NormColorB.Text = "Contrast";
      this.toolTip.SetToolTip(this.NormColorB, "Extent colors to full range");
      this.NormColorB.UseVisualStyleBackColor = true;
      this.NormColorB.Click += new System.EventHandler(this.Cmd);
      // 
      // chBrightBW
      // 
      this.chBrightBW.AutoSize = true;
      this.chBrightBW.Location = new System.Drawing.Point(75, 127);
      this.chBrightBW.Name = "chBrightBW";
      this.chBrightBW.Size = new System.Drawing.Size(15, 14);
      this.chBrightBW.TabIndex = 79;
      this.toolTip.SetToolTip(this.chBrightBW, "Leave black and white");
      this.chBrightBW.UseVisualStyleBackColor = true;
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(28, 75);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(61, 23);
      this.button1.TabIndex = 80;
      this.button1.Tag = "replace";
      this.button1.Text = "Replace";
      this.toolTip.SetToolTip(this.button1, "Replace fore color with back color");
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new System.EventHandler(this.Cmd);
      // 
      // Snap
      // 
      this.Snap.Location = new System.Drawing.Point(235, 126);
      this.Snap.Name = "Snap";
      this.Snap.Size = new System.Drawing.Size(27, 20);
      this.Snap.TabIndex = 70;
      this.Snap.Text = "24";
      this.toolTip.SetToolTip(this.Snap, "Snap size");
      this.Snap.TextChanged += new System.EventHandler(this.SnapChanged);
      // 
      // chSnap
      // 
      this.chSnap.AutoSize = true;
      this.chSnap.Location = new System.Drawing.Point(178, 128);
      this.chSnap.Name = "chSnap";
      this.chSnap.Size = new System.Drawing.Size(51, 17);
      this.chSnap.TabIndex = 72;
      this.chSnap.Text = "Snap";
      this.toolTip.SetToolTip(this.chSnap, "Snap to grid");
      this.chSnap.UseVisualStyleBackColor = true;
      this.chSnap.CheckedChanged += new System.EventHandler(this.SnapChanged);
      // 
      // ImpandB
      // 
      this.ImpandB.Location = new System.Drawing.Point(361, 15);
      this.ImpandB.Name = "ImpandB";
      this.ImpandB.Size = new System.Drawing.Size(55, 23);
      this.ImpandB.TabIndex = 55;
      this.ImpandB.Tag = "impand";
      this.ImpandB.Text = "Impand";
      this.toolTip.SetToolTip(this.ImpandB, "Convert inner black pixels to white pixels.\r\nUse X8 switch.");
      this.ImpandB.UseVisualStyleBackColor = true;
      this.ImpandB.Click += new System.EventHandler(this.Cmd);
      // 
      // chImpandBlack
      // 
      this.chImpandBlack.AutoSize = true;
      this.chImpandBlack.Location = new System.Drawing.Point(303, 19);
      this.chImpandBlack.Name = "chImpandBlack";
      this.chImpandBlack.Size = new System.Drawing.Size(53, 17);
      this.chImpandBlack.TabIndex = 56;
      this.chImpandBlack.Text = "Black";
      this.toolTip.SetToolTip(this.chImpandBlack, "Impand black color");
      this.chImpandBlack.UseVisualStyleBackColor = true;
      // 
      // bRemoveDust
      // 
      this.bRemoveDust.Location = new System.Drawing.Point(352, 104);
      this.bRemoveDust.Name = "bRemoveDust";
      this.bRemoveDust.Size = new System.Drawing.Size(81, 23);
      this.bRemoveDust.TabIndex = 81;
      this.bRemoveDust.Tag = "remove_dust";
      this.bRemoveDust.Text = "Remove dust";
      this.toolTip.SetToolTip(this.bRemoveDust, "Replace pixel dots with avereage color");
      this.bRemoveDust.UseVisualStyleBackColor = true;
      this.bRemoveDust.Click += new System.EventHandler(this.Cmd);
      // 
      // dustLevel
      // 
      this.dustLevel.Location = new System.Drawing.Point(285, 104);
      this.dustLevel.Name = "dustLevel";
      this.dustLevel.Size = new System.Drawing.Size(22, 20);
      this.dustLevel.TabIndex = 82;
      this.dustLevel.Tag = "";
      this.dustLevel.Text = "16";
      this.toolTip.SetToolTip(this.dustLevel, "Maximum dust size");
      // 
      // blackDust
      // 
      this.blackDust.AutoSize = true;
      this.blackDust.Checked = true;
      this.blackDust.CheckState = System.Windows.Forms.CheckState.Checked;
      this.blackDust.Location = new System.Drawing.Point(313, 109);
      this.blackDust.Name = "blackDust";
      this.blackDust.Size = new System.Drawing.Size(15, 14);
      this.blackDust.TabIndex = 83;
      this.toolTip.SetToolTip(this.blackDust, "Black dust");
      this.blackDust.UseVisualStyleBackColor = true;
      // 
      // whiteDust
      // 
      this.whiteDust.AutoSize = true;
      this.whiteDust.Location = new System.Drawing.Point(332, 109);
      this.whiteDust.Name = "whiteDust";
      this.whiteDust.Size = new System.Drawing.Size(15, 14);
      this.whiteDust.TabIndex = 84;
      this.toolTip.SetToolTip(this.whiteDust, "White dust");
      this.whiteDust.UseVisualStyleBackColor = true;
      // 
      // cbFill
      // 
      this.cbFill.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbFill.FormattingEnabled = true;
      this.cbFill.Items.AddRange(new object[] {
            "Circle ()",
            "Diamond <+>",
            "Square [x]",
            "Horizont =",
            "Vertical ||",
            "Raise //",
            "Fall \\\\"});
      this.cbFill.Location = new System.Drawing.Point(81, 54);
      this.cbFill.Name = "cbFill";
      this.cbFill.Size = new System.Drawing.Size(79, 21);
      this.cbFill.TabIndex = 50;
      // 
      // tabControl1
      // 
      this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.tabControl1.Controls.Add(this.tp1);
      this.tabControl1.Controls.Add(this.tp3);
      this.tabControl1.Controls.Add(this.tp2);
      this.tabControl1.Controls.Add(this.tp4);
      this.tabControl1.Location = new System.Drawing.Point(0, 0);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(453, 196);
      this.tabControl1.TabIndex = 57;
      // 
      // tp1
      // 
      this.tp1.BackColor = System.Drawing.SystemColors.Control;
      this.tp1.Controls.Add(this.chImpandBlack);
      this.tp1.Controls.Add(this.ImpandB);
      this.tp1.Controls.Add(this.ScreenB);
      this.tp1.Controls.Add(this.RedoB);
      this.tp1.Controls.Add(this.FillNoBlack);
      this.tp1.Controls.Add(this.UndoB);
      this.tp1.Controls.Add(this.X8);
      this.tp1.Controls.Add(this.cbFill);
      this.tp1.Controls.Add(this.ExpandB);
      this.tp1.Controls.Add(this.ExpandWhite);
      this.tp1.Controls.Add(this.ExpandWOnly);
      this.tp1.Controls.Add(this.ExpandDiffB);
      this.tp1.Controls.Add(this.label2);
      this.tp1.Controls.Add(this.label3);
      this.tp1.Controls.Add(this.lFill);
      this.tp1.Controls.Add(this.Fill2Black);
      this.tp1.Controls.Add(this.FillD8);
      this.tp1.Location = new System.Drawing.Point(4, 22);
      this.tp1.Name = "tp1";
      this.tp1.Padding = new System.Windows.Forms.Padding(3);
      this.tp1.Size = new System.Drawing.Size(445, 170);
      this.tp1.TabIndex = 0;
      this.tp1.Text = "Main";
      // 
      // tp3
      // 
      this.tp3.BackColor = System.Drawing.SystemColors.Control;
      this.tp3.Controls.Add(this.chSnap);
      this.tp3.Controls.Add(this.Snap);
      this.tp3.Controls.Add(this.cbRepeatMode);
      this.tp3.Controls.Add(this.RepeatCenter);
      this.tp3.Controls.Add(this.RepeatCount);
      this.tp3.Controls.Add(this.lRepeat);
      this.tp3.Controls.Add(this.RepeatOn);
      this.tp3.Controls.Add(this.RepeatX);
      this.tp3.Controls.Add(this.RepeatY);
      this.tp3.Controls.Add(this.label1);
      this.tp3.Controls.Add(this.cbBrush);
      this.tp3.Controls.Add(this.cbShape);
      this.tp3.Controls.Add(this.DrawWOnly);
      this.tp3.Controls.Add(this.lShape);
      this.tp3.Controls.Add(this.ShapeAdjust);
      this.tp3.Controls.Add(this.ShapeMirrorY);
      this.tp3.Controls.Add(this.ShapeMirrorX);
      this.tp3.Controls.Add(this.DrawFilled);
      this.tp3.Controls.Add(this.DrawOrto);
      this.tp3.Controls.Add(this.DrawBlack);
      this.tp3.Controls.Add(this.DrawCenter);
      this.tp3.Controls.Add(this.lDraw);
      this.tp3.Location = new System.Drawing.Point(4, 22);
      this.tp3.Name = "tp3";
      this.tp3.Size = new System.Drawing.Size(445, 170);
      this.tp3.TabIndex = 2;
      this.tp3.Text = "Draw";
      // 
      // cbRepeatMode
      // 
      this.cbRepeatMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbRepeatMode.FormattingEnabled = true;
      this.cbRepeatMode.Items.AddRange(new object[] {
            "X",
            "Y",
            "XY",
            "Mirror8",
            "Rotate",
            "Rotate+Mirror",
            "Selection"});
      this.cbRepeatMode.Location = new System.Drawing.Point(118, 19);
      this.cbRepeatMode.Name = "cbRepeatMode";
      this.cbRepeatMode.Size = new System.Drawing.Size(88, 21);
      this.cbRepeatMode.TabIndex = 65;
      // 
      // RepeatCenter
      // 
      this.RepeatCenter.AutoSize = true;
      this.RepeatCenter.Location = new System.Drawing.Point(244, 21);
      this.RepeatCenter.Name = "RepeatCenter";
      this.RepeatCenter.Size = new System.Drawing.Size(57, 17);
      this.RepeatCenter.TabIndex = 62;
      this.RepeatCenter.Text = "Center";
      this.RepeatCenter.UseVisualStyleBackColor = true;
      // 
      // RepeatCount
      // 
      this.RepeatCount.Location = new System.Drawing.Point(212, 19);
      this.RepeatCount.Name = "RepeatCount";
      this.RepeatCount.Size = new System.Drawing.Size(26, 20);
      this.RepeatCount.TabIndex = 63;
      this.RepeatCount.Text = "6";
      // 
      // lRepeat
      // 
      this.lRepeat.AutoSize = true;
      this.lRepeat.Location = new System.Drawing.Point(23, 22);
      this.lRepeat.Name = "lRepeat";
      this.lRepeat.Size = new System.Drawing.Size(71, 13);
      this.lRepeat.TabIndex = 64;
      this.lRepeat.Text = "Repeater (W)";
      // 
      // RepeatOn
      // 
      this.RepeatOn.AutoSize = true;
      this.RepeatOn.Location = new System.Drawing.Point(100, 25);
      this.RepeatOn.Name = "RepeatOn";
      this.RepeatOn.Size = new System.Drawing.Size(15, 14);
      this.RepeatOn.TabIndex = 66;
      this.RepeatOn.UseVisualStyleBackColor = true;
      // 
      // RepeatX
      // 
      this.RepeatX.Location = new System.Drawing.Point(307, 19);
      this.RepeatX.Name = "RepeatX";
      this.RepeatX.Size = new System.Drawing.Size(40, 20);
      this.RepeatX.TabIndex = 67;
      this.RepeatX.Text = "0";
      // 
      // RepeatY
      // 
      this.RepeatY.Location = new System.Drawing.Point(353, 20);
      this.RepeatY.Name = "RepeatY";
      this.RepeatY.Size = new System.Drawing.Size(40, 20);
      this.RepeatY.TabIndex = 68;
      this.RepeatY.Text = "0";
      // 
      // label1
      // 
      this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label1.Location = new System.Drawing.Point(11, 43);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(400, 2);
      this.label1.TabIndex = 69;
      // 
      // cbBrush
      // 
      this.cbBrush.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbBrush.FormattingEnabled = true;
      this.cbBrush.Location = new System.Drawing.Point(53, 61);
      this.cbBrush.Name = "cbBrush";
      this.cbBrush.Size = new System.Drawing.Size(81, 21);
      this.cbBrush.TabIndex = 61;
      // 
      // cbShape
      // 
      this.cbShape.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbShape.FormattingEnabled = true;
      this.cbShape.Items.AddRange(new object[] {
            "Rectangle",
            "Circle",
            "Start",
            "Octagon",
            "Triangle",
            "Arrow",
            ""});
      this.cbShape.Location = new System.Drawing.Point(64, 87);
      this.cbShape.Name = "cbShape";
      this.cbShape.Size = new System.Drawing.Size(88, 21);
      this.cbShape.TabIndex = 60;
      // 
      // lShape
      // 
      this.lShape.AutoSize = true;
      this.lShape.Location = new System.Drawing.Point(21, 91);
      this.lShape.Name = "lShape";
      this.lShape.Size = new System.Drawing.Size(38, 13);
      this.lShape.TabIndex = 58;
      this.lShape.Text = "Shape";
      // 
      // ShapeAdjust
      // 
      this.ShapeAdjust.AutoSize = true;
      this.ShapeAdjust.Location = new System.Drawing.Point(226, 91);
      this.ShapeAdjust.Name = "ShapeAdjust";
      this.ShapeAdjust.Size = new System.Drawing.Size(55, 17);
      this.ShapeAdjust.TabIndex = 57;
      this.ShapeAdjust.Text = "Adjust";
      this.ShapeAdjust.UseVisualStyleBackColor = true;
      // 
      // ShapeMirrorY
      // 
      this.ShapeMirrorY.AutoSize = true;
      this.ShapeMirrorY.Location = new System.Drawing.Point(194, 91);
      this.ShapeMirrorY.Name = "ShapeMirrorY";
      this.ShapeMirrorY.Size = new System.Drawing.Size(35, 17);
      this.ShapeMirrorY.TabIndex = 56;
      this.ShapeMirrorY.Text = "|Y";
      this.ShapeMirrorY.UseVisualStyleBackColor = true;
      // 
      // ShapeMirrorX
      // 
      this.ShapeMirrorX.AutoSize = true;
      this.ShapeMirrorX.Location = new System.Drawing.Point(158, 91);
      this.ShapeMirrorX.Name = "ShapeMirrorX";
      this.ShapeMirrorX.Size = new System.Drawing.Size(35, 17);
      this.ShapeMirrorX.TabIndex = 55;
      this.ShapeMirrorX.Text = "|X";
      this.ShapeMirrorX.UseVisualStyleBackColor = true;
      // 
      // DrawFilled
      // 
      this.DrawFilled.AutoSize = true;
      this.DrawFilled.Location = new System.Drawing.Point(287, 63);
      this.DrawFilled.Name = "DrawFilled";
      this.DrawFilled.Size = new System.Drawing.Size(50, 17);
      this.DrawFilled.TabIndex = 54;
      this.DrawFilled.Text = "Filled";
      this.DrawFilled.UseVisualStyleBackColor = true;
      // 
      // DrawOrto
      // 
      this.DrawOrto.AutoSize = true;
      this.DrawOrto.Location = new System.Drawing.Point(247, 63);
      this.DrawOrto.Name = "DrawOrto";
      this.DrawOrto.Size = new System.Drawing.Size(46, 17);
      this.DrawOrto.TabIndex = 53;
      this.DrawOrto.Text = "Orto";
      this.DrawOrto.UseVisualStyleBackColor = true;
      // 
      // DrawBlack
      // 
      this.DrawBlack.AutoSize = true;
      this.DrawBlack.Checked = true;
      this.DrawBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.DrawBlack.Location = new System.Drawing.Point(140, 63);
      this.DrawBlack.Name = "DrawBlack";
      this.DrawBlack.Size = new System.Drawing.Size(53, 17);
      this.DrawBlack.TabIndex = 52;
      this.DrawBlack.Text = "Black";
      this.DrawBlack.UseVisualStyleBackColor = true;
      // 
      // DrawCenter
      // 
      this.DrawCenter.AutoSize = true;
      this.DrawCenter.Location = new System.Drawing.Point(193, 63);
      this.DrawCenter.Name = "DrawCenter";
      this.DrawCenter.Size = new System.Drawing.Size(57, 17);
      this.DrawCenter.TabIndex = 51;
      this.DrawCenter.Text = "Center";
      this.DrawCenter.UseVisualStyleBackColor = true;
      // 
      // lDraw
      // 
      this.lDraw.AutoSize = true;
      this.lDraw.Location = new System.Drawing.Point(21, 64);
      this.lDraw.Name = "lDraw";
      this.lDraw.Size = new System.Drawing.Size(32, 13);
      this.lDraw.TabIndex = 50;
      this.lDraw.Text = "Draw";
      // 
      // tp2
      // 
      this.tp2.BackColor = System.Drawing.SystemColors.Control;
      this.tp2.Controls.Add(this.pasteMix);
      this.tp2.Controls.Add(this.pasteExtend);
      this.tp2.Controls.Add(this.pasteRepeat);
      this.tp2.Controls.Add(this.pasteTRX);
      this.tp2.Controls.Add(this.pasteTrans);
      this.tp2.Controls.Add(this.pasteDiff);
      this.tp2.Controls.Add(this.pasteXOR);
      this.tp2.Controls.Add(this.pasteQuad);
      this.tp2.Location = new System.Drawing.Point(4, 22);
      this.tp2.Name = "tp2";
      this.tp2.Padding = new System.Windows.Forms.Padding(3);
      this.tp2.Size = new System.Drawing.Size(445, 170);
      this.tp2.TabIndex = 1;
      this.tp2.Text = "Paste";
      // 
      // pasteExtend
      // 
      this.pasteExtend.AutoSize = true;
      this.pasteExtend.Location = new System.Drawing.Point(283, 77);
      this.pasteExtend.Name = "pasteExtend";
      this.pasteExtend.Size = new System.Drawing.Size(59, 17);
      this.pasteExtend.TabIndex = 58;
      this.pasteExtend.Text = "Extend";
      this.pasteExtend.UseVisualStyleBackColor = true;
      // 
      // pasteRepeat
      // 
      this.pasteRepeat.AutoSize = true;
      this.pasteRepeat.Location = new System.Drawing.Point(9, 77);
      this.pasteRepeat.Name = "pasteRepeat";
      this.pasteRepeat.Size = new System.Drawing.Size(61, 17);
      this.pasteRepeat.TabIndex = 57;
      this.pasteRepeat.Text = "Repeat";
      this.pasteRepeat.UseVisualStyleBackColor = true;
      // 
      // pasteTRX
      // 
      this.pasteTRX.AutoSize = true;
      this.pasteTRX.Location = new System.Drawing.Point(98, 29);
      this.pasteTRX.Name = "pasteTRX";
      this.pasteTRX.Size = new System.Drawing.Size(53, 17);
      this.pasteTRX.TabIndex = 56;
      this.pasteTRX.Text = "Fuzzy";
      this.toolTip.SetToolTip(this.pasteTRX, "Border of transparent color is mixed");
      this.pasteTRX.UseVisualStyleBackColor = true;
      // 
      // pasteTrans
      // 
      this.pasteTrans.AutoSize = true;
      this.pasteTrans.Location = new System.Drawing.Point(9, 29);
      this.pasteTrans.Name = "pasteTrans";
      this.pasteTrans.Size = new System.Drawing.Size(83, 17);
      this.pasteTrans.TabIndex = 55;
      this.pasteTrans.Text = "Transparent";
      this.toolTip.SetToolTip(this.pasteTrans, "Use second color as transparent");
      this.pasteTrans.UseVisualStyleBackColor = true;
      // 
      // pasteDiff
      // 
      this.pasteDiff.AutoSize = true;
      this.pasteDiff.Location = new System.Drawing.Point(63, 6);
      this.pasteDiff.Name = "pasteDiff";
      this.pasteDiff.Size = new System.Drawing.Size(42, 17);
      this.pasteDiff.TabIndex = 54;
      this.pasteDiff.Text = "Diff";
      this.pasteDiff.UseVisualStyleBackColor = true;
      this.pasteDiff.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // pasteXOR
      // 
      this.pasteXOR.AutoSize = true;
      this.pasteXOR.Location = new System.Drawing.Point(8, 6);
      this.pasteXOR.Name = "pasteXOR";
      this.pasteXOR.Size = new System.Drawing.Size(49, 17);
      this.pasteXOR.TabIndex = 53;
      this.pasteXOR.Text = "XOR";
      this.pasteXOR.UseVisualStyleBackColor = true;
      this.pasteXOR.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // pasteQuad
      // 
      this.pasteQuad.AutoSize = true;
      this.pasteQuad.Location = new System.Drawing.Point(76, 77);
      this.pasteQuad.Name = "pasteQuad";
      this.pasteQuad.Size = new System.Drawing.Size(52, 17);
      this.pasteQuad.TabIndex = 52;
      this.pasteQuad.Text = "Quad";
      this.pasteQuad.UseVisualStyleBackColor = true;
      // 
      // tp4
      // 
      this.tp4.BackColor = System.Drawing.SystemColors.Control;
      this.tp4.Controls.Add(this.whiteDust);
      this.tp4.Controls.Add(this.blackDust);
      this.tp4.Controls.Add(this.dustLevel);
      this.tp4.Controls.Add(this.bRemoveDust);
      this.tp4.Controls.Add(this.button1);
      this.tp4.Controls.Add(this.chBrightBW);
      this.tp4.Controls.Add(this.panel1);
      this.tp4.Controls.Add(this.chRemDotBlack);
      this.tp4.Controls.Add(this.chRemDotWhite);
      this.tp4.Controls.Add(this.bRemoveDots);
      this.tp4.Controls.Add(this.borderLevel);
      this.tp4.Controls.Add(this.bBorder);
      this.tp4.Controls.Add(this.cbContrast);
      this.tp4.Controls.Add(this.NormColorB);
      this.tp4.Controls.Add(this.darkB);
      this.tp4.Controls.Add(this.brightB);
      this.tp4.Controls.Add(this.redoB2);
      this.tp4.Controls.Add(this.undoB2);
      this.tp4.Controls.Add(this.bGray);
      this.tp4.Controls.Add(this.Invert);
      this.tp4.Controls.Add(this.cbInvertBW);
      this.tp4.Controls.Add(this.cbInvertIntensity);
      this.tp4.Controls.Add(this.rgb2cmyB);
      this.tp4.Controls.Add(this.rgbshiftB);
      this.tp4.Controls.Add(this.levelsB);
      this.tp4.Controls.Add(this.levelsCount);
      this.tp4.Controls.Add(this.contour);
      this.tp4.Controls.Add(this.BWPanel);
      this.tp4.Controls.Add(this.BW);
      this.tp4.Controls.Add(this.BWLevel);
      this.tp4.Location = new System.Drawing.Point(4, 22);
      this.tp4.Name = "tp4";
      this.tp4.Size = new System.Drawing.Size(445, 170);
      this.tp4.TabIndex = 3;
      this.tp4.Text = "Color";
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.rRemDot3);
      this.panel1.Controls.Add(this.rRemDot8);
      this.panel1.Controls.Add(this.rRemDot4);
      this.panel1.Location = new System.Drawing.Point(190, 75);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(117, 23);
      this.panel1.TabIndex = 64;
      // 
      // borderLevel
      // 
      this.borderLevel.Location = new System.Drawing.Point(326, 21);
      this.borderLevel.Name = "borderLevel";
      this.borderLevel.Size = new System.Drawing.Size(22, 20);
      this.borderLevel.TabIndex = 75;
      this.borderLevel.Tag = "";
      this.borderLevel.Text = "24";
      // 
      // darkB
      // 
      this.darkB.Location = new System.Drawing.Point(90, 122);
      this.darkB.Name = "darkB";
      this.darkB.Size = new System.Drawing.Size(53, 23);
      this.darkB.TabIndex = 71;
      this.darkB.Tag = "dark";
      this.darkB.Text = "Dark";
      this.darkB.UseVisualStyleBackColor = true;
      this.darkB.Click += new System.EventHandler(this.Cmd);
      // 
      // brightB
      // 
      this.brightB.Location = new System.Drawing.Point(20, 122);
      this.brightB.Name = "brightB";
      this.brightB.Size = new System.Drawing.Size(53, 23);
      this.brightB.TabIndex = 70;
      this.brightB.Tag = "bright";
      this.brightB.Text = "Bright";
      this.brightB.UseVisualStyleBackColor = true;
      this.brightB.Click += new System.EventHandler(this.Cmd);
      // 
      // redoB2
      // 
      this.redoB2.Location = new System.Drawing.Point(380, 138);
      this.redoB2.Name = "redoB2";
      this.redoB2.Size = new System.Drawing.Size(53, 23);
      this.redoB2.TabIndex = 69;
      this.redoB2.Tag = "redo";
      this.redoB2.Text = "Redo";
      this.redoB2.UseVisualStyleBackColor = true;
      this.redoB2.Click += new System.EventHandler(this.Cmd);
      // 
      // undoB2
      // 
      this.undoB2.Location = new System.Drawing.Point(321, 138);
      this.undoB2.Name = "undoB2";
      this.undoB2.Size = new System.Drawing.Size(53, 23);
      this.undoB2.TabIndex = 68;
      this.undoB2.Tag = "undo";
      this.undoB2.Text = "Undo";
      this.undoB2.UseVisualStyleBackColor = true;
      this.undoB2.Click += new System.EventHandler(this.Cmd);
      // 
      // levelsCount
      // 
      this.levelsCount.Location = new System.Drawing.Point(269, 48);
      this.levelsCount.Name = "levelsCount";
      this.levelsCount.Size = new System.Drawing.Size(22, 20);
      this.levelsCount.TabIndex = 59;
      this.levelsCount.Tag = "";
      this.levelsCount.Text = "16";
      // 
      // BWPanel
      // 
      this.BWPanel.Controls.Add(this.BWMax);
      this.BWPanel.Controls.Add(this.BWMin);
      this.BWPanel.Controls.Add(this.BWAvg);
      this.BWPanel.Location = new System.Drawing.Point(28, 21);
      this.BWPanel.Name = "BWPanel";
      this.BWPanel.Size = new System.Drawing.Size(136, 23);
      this.BWPanel.TabIndex = 63;
      // 
      // BWMax
      // 
      this.BWMax.AutoSize = true;
      this.BWMax.Location = new System.Drawing.Point(89, 3);
      this.BWMax.Name = "BWMax";
      this.BWMax.Size = new System.Drawing.Size(44, 17);
      this.BWMax.TabIndex = 35;
      this.BWMax.Text = "max";
      this.BWMax.UseVisualStyleBackColor = true;
      // 
      // BWMin
      // 
      this.BWMin.AutoSize = true;
      this.BWMin.Location = new System.Drawing.Point(3, 3);
      this.BWMin.Name = "BWMin";
      this.BWMin.Size = new System.Drawing.Size(41, 17);
      this.BWMin.TabIndex = 33;
      this.BWMin.Text = "min";
      this.BWMin.UseVisualStyleBackColor = true;
      // 
      // BWAvg
      // 
      this.BWAvg.AutoSize = true;
      this.BWAvg.Checked = true;
      this.BWAvg.Location = new System.Drawing.Point(45, 3);
      this.BWAvg.Name = "BWAvg";
      this.BWAvg.Size = new System.Drawing.Size(43, 17);
      this.BWAvg.TabIndex = 34;
      this.BWAvg.TabStop = true;
      this.BWAvg.Text = "avg";
      this.BWAvg.UseVisualStyleBackColor = true;
      // 
      // BWLevel
      // 
      this.BWLevel.Location = new System.Drawing.Point(165, 23);
      this.BWLevel.Name = "BWLevel";
      this.BWLevel.Size = new System.Drawing.Size(31, 20);
      this.BWLevel.TabIndex = 61;
      this.BWLevel.Tag = "";
      this.BWLevel.Text = "128";
      // 
      // pasteMix
      // 
      this.pasteMix.AutoSize = true;
      this.pasteMix.Location = new System.Drawing.Point(9, 52);
      this.pasteMix.Name = "pasteMix";
      this.pasteMix.Size = new System.Drawing.Size(42, 17);
      this.pasteMix.TabIndex = 59;
      this.pasteMix.Text = "Mix";
      this.toolTip.SetToolTip(this.pasteMix, "Mix current and paste color 1:3");
      this.pasteMix.UseVisualStyleBackColor = true;
      // 
      // fBoard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(452, 195);
      this.Controls.Add(this.tabControl1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "fBoard";
      this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
      this.Text = "Board";
      this.tabControl1.ResumeLayout(false);
      this.tp1.ResumeLayout(false);
      this.tp1.PerformLayout();
      this.tp3.ResumeLayout(false);
      this.tp3.PerformLayout();
      this.tp2.ResumeLayout(false);
      this.tp2.PerformLayout();
      this.tp4.ResumeLayout(false);
      this.tp4.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.BWPanel.ResumeLayout(false);
      this.BWPanel.PerformLayout();
      this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button ExpandB;
		internal System.Windows.Forms.CheckBox X8;
		internal System.Windows.Forms.CheckBox ExpandWhite;
		internal System.Windows.Forms.CheckBox ExpandWOnly;
		private System.Windows.Forms.Button UndoB;
		private System.Windows.Forms.Button RedoB;
		private System.Windows.Forms.Button ScreenB;
		private System.Windows.Forms.Button ExpandDiffB;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lFill;
		internal System.Windows.Forms.CheckBox Fill2Black;
		internal System.Windows.Forms.CheckBox FillD8;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ToolTip toolTip;
		internal System.Windows.Forms.ComboBox cbFill;
    internal System.Windows.Forms.CheckBox FillNoBlack;
    private System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tp1;
    private System.Windows.Forms.TabPage tp3;
    private System.Windows.Forms.ComboBox cbRepeatMode;
    internal System.Windows.Forms.CheckBox RepeatCenter;
    internal System.Windows.Forms.TextBox RepeatCount;
    private System.Windows.Forms.Label lRepeat;
    internal System.Windows.Forms.CheckBox RepeatOn;
    internal System.Windows.Forms.TextBox RepeatX;
    internal System.Windows.Forms.TextBox RepeatY;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cbBrush;
    private System.Windows.Forms.ComboBox cbShape;
    internal System.Windows.Forms.CheckBox DrawWOnly;
    private System.Windows.Forms.Label lShape;
    internal System.Windows.Forms.CheckBox ShapeAdjust;
    internal System.Windows.Forms.CheckBox ShapeMirrorY;
    internal System.Windows.Forms.CheckBox ShapeMirrorX;
    internal System.Windows.Forms.CheckBox DrawFilled;
    internal System.Windows.Forms.CheckBox DrawOrto;
    internal System.Windows.Forms.CheckBox DrawBlack;
    internal System.Windows.Forms.CheckBox DrawCenter;
    private System.Windows.Forms.Label lDraw;
    private System.Windows.Forms.TabPage tp2;
    private System.Windows.Forms.TabPage tp4;
    private System.Windows.Forms.Button bGray;
    private System.Windows.Forms.Button Invert;
    internal System.Windows.Forms.CheckBox cbInvertBW;
    internal System.Windows.Forms.CheckBox cbInvertIntensity;
    private System.Windows.Forms.Button rgb2cmyB;
    private System.Windows.Forms.Button rgbshiftB;
    private System.Windows.Forms.Button levelsB;
    internal System.Windows.Forms.TextBox levelsCount;
    private System.Windows.Forms.Button contour;
    private System.Windows.Forms.Panel BWPanel;
    private System.Windows.Forms.RadioButton BWMax;
    private System.Windows.Forms.RadioButton BWMin;
    private System.Windows.Forms.RadioButton BWAvg;
    private System.Windows.Forms.Button BW;
    internal System.Windows.Forms.TextBox BWLevel;
    private System.Windows.Forms.Button redoB2;
    private System.Windows.Forms.Button undoB2;
    private System.Windows.Forms.Button darkB;
    private System.Windows.Forms.Button brightB;
    internal System.Windows.Forms.CheckBox pasteQuad;
    internal System.Windows.Forms.CheckBox pasteDiff;
    internal System.Windows.Forms.CheckBox pasteXOR;
    internal System.Windows.Forms.CheckBox pasteTrans;
    internal System.Windows.Forms.CheckBox pasteTRX;
    internal System.Windows.Forms.CheckBox pasteRepeat;
    private System.Windows.Forms.Button NormColorB;
    internal System.Windows.Forms.CheckBox cbContrast;
    private System.Windows.Forms.Button bBorder;
    internal System.Windows.Forms.TextBox borderLevel;
    internal System.Windows.Forms.CheckBox chRemDotWhite;
    private System.Windows.Forms.Button bRemoveDots;
    internal System.Windows.Forms.CheckBox chRemDotBlack;
    private System.Windows.Forms.RadioButton rRemDot8;
    private System.Windows.Forms.RadioButton rRemDot4;
    private System.Windows.Forms.RadioButton rRemDot3;
    private System.Windows.Forms.Panel panel1;
    internal System.Windows.Forms.CheckBox chBrightBW;
    private System.Windows.Forms.Button button1;
    internal System.Windows.Forms.TextBox Snap;
    internal System.Windows.Forms.CheckBox chSnap;
    internal System.Windows.Forms.CheckBox pasteExtend;
    private System.Windows.Forms.Button ImpandB;
    internal System.Windows.Forms.CheckBox chImpandBlack;
    internal System.Windows.Forms.TextBox dustLevel;
    private System.Windows.Forms.Button bRemoveDust;
    internal System.Windows.Forms.CheckBox whiteDust;
    internal System.Windows.Forms.CheckBox blackDust;
    internal System.Windows.Forms.CheckBox pasteMix;
  }
}