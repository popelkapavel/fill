﻿namespace grcol
{
	partial class fBoard
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      this.ExpandB = new System.Windows.Forms.Button();
      this.X8 = new System.Windows.Forms.CheckBox();
      this.ExpandWhite = new System.Windows.Forms.CheckBox();
      this.ExpandWOnly = new System.Windows.Forms.CheckBox();
      this.UndoB = new System.Windows.Forms.Button();
      this.RedoB = new System.Windows.Forms.Button();
      this.ScreenB = new System.Windows.Forms.Button();
      this.ExpandDiffB = new System.Windows.Forms.Button();
      this.label2 = new System.Windows.Forms.Label();
      this.lFill = new System.Windows.Forms.Label();
      this.Fill2Black = new System.Windows.Forms.CheckBox();
      this.FillD8 = new System.Windows.Forms.CheckBox();
      this.label3 = new System.Windows.Forms.Label();
      this.toolTip = new System.Windows.Forms.ToolTip(this.components);
      this.FillNoBlack = new System.Windows.Forms.CheckBox();
      this.DrawWOnly = new System.Windows.Forms.CheckBox();
      this.bGray = new System.Windows.Forms.Button();
      this.Invert = new System.Windows.Forms.Button();
      this.cbInvertBW = new System.Windows.Forms.CheckBox();
      this.cbInvertIntensity = new System.Windows.Forms.CheckBox();
      this.rgb2cmyB = new System.Windows.Forms.Button();
      this.rgbshiftB = new System.Windows.Forms.Button();
      this.levelsB = new System.Windows.Forms.Button();
      this.contour = new System.Windows.Forms.Button();
      this.BW = new System.Windows.Forms.Button();
      this.cbContrast = new System.Windows.Forms.CheckBox();
      this.bBorder = new System.Windows.Forms.Button();
      this.bRemoveDots = new System.Windows.Forms.Button();
      this.chRemDotWhite = new System.Windows.Forms.CheckBox();
      this.chRemDotBlack = new System.Windows.Forms.CheckBox();
      this.rRemDot3 = new System.Windows.Forms.RadioButton();
      this.rRemDot4 = new System.Windows.Forms.RadioButton();
      this.rRemDot8 = new System.Windows.Forms.RadioButton();
      this.NormColorB = new System.Windows.Forms.Button();
      this.chBrightBW = new System.Windows.Forms.CheckBox();
      this.bCReplace = new System.Windows.Forms.Button();
      this.Snap = new System.Windows.Forms.TextBox();
      this.chSnap = new System.Windows.Forms.CheckBox();
      this.ImpandB = new System.Windows.Forms.Button();
      this.chImpandBlack = new System.Windows.Forms.CheckBox();
      this.bRemoveDust = new System.Windows.Forms.Button();
      this.dustLevel = new System.Windows.Forms.TextBox();
      this.blackDust = new System.Windows.Forms.CheckBox();
      this.whiteDust = new System.Windows.Forms.CheckBox();
      this.pasteTRX = new System.Windows.Forms.CheckBox();
      this.pasteTrans = new System.Windows.Forms.CheckBox();
      this.pasteMix = new System.Windows.Forms.CheckBox();
      this.bText = new System.Windows.Forms.Button();
      this.FntDialog = new System.Windows.Forms.Button();
      this.chTBWAuto = new System.Windows.Forms.CheckBox();
      this.chLColorFont = new System.Windows.Forms.CheckBox();
      this.BOutline = new System.Windows.Forms.Button();
      this.bCRemove = new System.Windows.Forms.Button();
      this.pasteFiles = new System.Windows.Forms.CheckBox();
      this.tsDiamond = new System.Windows.Forms.RadioButton();
      this.tsCircle = new System.Windows.Forms.RadioButton();
      this.tsBox = new System.Windows.Forms.RadioButton();
      this.bNew = new System.Windows.Forms.Button();
      this.bSaveIcon = new System.Windows.Forms.Button();
      this.tIconHeight = new System.Windows.Forms.TextBox();
      this.tIconWidth = new System.Windows.Forms.TextBox();
      this.rIconExact = new System.Windows.Forms.RadioButton();
      this.rIconHeight = new System.Windows.Forms.RadioButton();
      this.rIconWidth = new System.Windows.Forms.RadioButton();
      this.rIconAspect = new System.Windows.Forms.RadioButton();
      this.rIcon1to1 = new System.Windows.Forms.RadioButton();
      this.chIconCursor = new System.Windows.Forms.CheckBox();
      this.rIconTrWhite = new System.Windows.Forms.RadioButton();
      this.rIconTrNone = new System.Windows.Forms.RadioButton();
      this.rIconTrColor2 = new System.Windows.Forms.RadioButton();
      this.rbFilterColor2 = new System.Windows.Forms.RadioButton();
      this.rbFilterWhite = new System.Windows.Forms.RadioButton();
      this.rbFilterOff = new System.Windows.Forms.RadioButton();
      this.rbFilterNotColor2 = new System.Windows.Forms.RadioButton();
      this.rbFilterAndNotBlack = new System.Windows.Forms.RadioButton();
      this.cbFill = new System.Windows.Forms.ComboBox();
      this.tabControl1 = new System.Windows.Forms.TabControl();
      this.tp6 = new System.Windows.Forms.TabPage();
      this.bModeRadial = new System.Windows.Forms.Button();
      this.bModeBorder = new System.Windows.Forms.Button();
      this.bABlack = new System.Windows.Forms.Button();
      this.bCDark2 = new System.Windows.Forms.Button();
      this.bCLight2 = new System.Windows.Forms.Button();
      this.bCDark1 = new System.Windows.Forms.Button();
      this.bCLight1 = new System.Windows.Forms.Button();
      this.bColorGr8 = new System.Windows.Forms.Button();
      this.bModeLinear = new System.Windows.Forms.Button();
      this.bColorGr6 = new System.Windows.Forms.Button();
      this.bColorGr5 = new System.Windows.Forms.Button();
      this.bColorGr4 = new System.Windows.Forms.Button();
      this.bSwap = new System.Windows.Forms.Button();
      this.bColor2 = new System.Windows.Forms.Button();
      this.bColor = new System.Windows.Forms.Button();
      this.bClear = new System.Windows.Forms.Button();
      this.bModeSelect = new System.Windows.Forms.Button();
      this.bModeFill = new System.Windows.Forms.Button();
      this.bModeCircle = new System.Windows.Forms.Button();
      this.bBlue = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.bColorGr1 = new System.Windows.Forms.Button();
      this.bColorGr3 = new System.Windows.Forms.Button();
      this.bColorGr2 = new System.Windows.Forms.Button();
      this.bGY = new System.Windows.Forms.Button();
      this.bGreen = new System.Windows.Forms.Button();
      this.bRed = new System.Windows.Forms.Button();
      this.bColorGr7 = new System.Windows.Forms.Button();
      this.bYellow = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.bCyan = new System.Windows.Forms.Button();
      this.bWhite = new System.Windows.Forms.Button();
      this.tp1 = new System.Windows.Forms.TabPage();
      this.tp3 = new System.Windows.Forms.TabPage();
      this.tbDash = new System.Windows.Forms.TextBox();
      this.lDash = new System.Windows.Forms.Label();
      this.chRadiusFlat = new System.Windows.Forms.CheckBox();
      this.lRadius = new System.Windows.Forms.Label();
      this.dArrrowRadius = new System.Windows.Forms.TextBox();
      this.dArrowWidth = new System.Windows.Forms.TextBox();
      this.dArrowLen = new System.Windows.Forms.TextBox();
      this.lArrow = new System.Windows.Forms.Label();
      this.cbRepeatMode = new System.Windows.Forms.ComboBox();
      this.RepeatCenter = new System.Windows.Forms.CheckBox();
      this.RepeatCount = new System.Windows.Forms.TextBox();
      this.lRepeat = new System.Windows.Forms.Label();
      this.RepeatOn = new System.Windows.Forms.CheckBox();
      this.RepeatX = new System.Windows.Forms.TextBox();
      this.RepeatY = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cbBrush = new System.Windows.Forms.ComboBox();
      this.cbShape = new System.Windows.Forms.ComboBox();
      this.lShape = new System.Windows.Forms.Label();
      this.ShapeAdjust = new System.Windows.Forms.CheckBox();
      this.ShapeMirrorY = new System.Windows.Forms.CheckBox();
      this.ShapeMirrorX = new System.Windows.Forms.CheckBox();
      this.DrawFilled = new System.Windows.Forms.CheckBox();
      this.DrawOrto = new System.Windows.Forms.CheckBox();
      this.DrawBlack = new System.Windows.Forms.CheckBox();
      this.DrawCenter = new System.Windows.Forms.CheckBox();
      this.lDraw = new System.Windows.Forms.Label();
      this.tp2 = new System.Windows.Forms.TabPage();
      this.rbPasteFilter = new System.Windows.Forms.Panel();
      this.gPasteDiff = new System.Windows.Forms.Panel();
      this.rbDiffBW = new System.Windows.Forms.RadioButton();
      this.rbDiffDiff = new System.Windows.Forms.RadioButton();
      this.rbDiffRed = new System.Windows.Forms.RadioButton();
      this.rbDiffXor = new System.Windows.Forms.RadioButton();
      this.rbDiffOff = new System.Windows.Forms.RadioButton();
      this.rbDiffMax = new System.Windows.Forms.RadioButton();
      this.rbDiffMin = new System.Windows.Forms.RadioButton();
      this.rbDiffAvg = new System.Windows.Forms.RadioButton();
      this.lMixLevel = new System.Windows.Forms.Label();
      this.MixLevel = new System.Windows.Forms.TextBox();
      this.pasteExtend = new System.Windows.Forms.CheckBox();
      this.pasteRepeat = new System.Windows.Forms.CheckBox();
      this.pasteQuad = new System.Windows.Forms.CheckBox();
      this.tp4 = new System.Windows.Forms.TabPage();
      this.panel1 = new System.Windows.Forms.Panel();
      this.borderLevel = new System.Windows.Forms.TextBox();
      this.darkB = new System.Windows.Forms.Button();
      this.brightB = new System.Windows.Forms.Button();
      this.redoB2 = new System.Windows.Forms.Button();
      this.undoB2 = new System.Windows.Forms.Button();
      this.levelsCount = new System.Windows.Forms.TextBox();
      this.BWPanel = new System.Windows.Forms.Panel();
      this.BWMax = new System.Windows.Forms.RadioButton();
      this.BWMin = new System.Windows.Forms.RadioButton();
      this.BWAvg = new System.Windows.Forms.RadioButton();
      this.BWLevel = new System.Windows.Forms.TextBox();
      this.tp5 = new System.Windows.Forms.TabPage();
      this.lPadding = new System.Windows.Forms.Label();
      this.tPadding = new System.Windows.Forms.NumericUpDown();
      this.panel3 = new System.Windows.Forms.Panel();
      this.tbTlDash2 = new System.Windows.Forms.NumericUpDown();
      this.ltDash = new System.Windows.Forms.Label();
      this.tbTLWidth2 = new System.Windows.Forms.NumericUpDown();
      this.chTOpaq = new System.Windows.Forms.CheckBox();
      this.chTPasteLine = new System.Windows.Forms.CheckBox();
      this.chTLHeader = new System.Windows.Forms.CheckBox();
      this.chTLFlat = new System.Windows.Forms.CheckBox();
      this.tbTLRound = new System.Windows.Forms.TextBox();
      this.ltlRound = new System.Windows.Forms.Label();
      this.ltlWidth = new System.Windows.Forms.Label();
      this.blColor = new System.Windows.Forms.Button();
      this.btColor = new System.Windows.Forms.Button();
      this.FontStrike = new System.Windows.Forms.CheckBox();
      this.FontUnder = new System.Windows.Forms.CheckBox();
      this.TextAlign = new System.Windows.Forms.Panel();
      this.taRight = new System.Windows.Forms.RadioButton();
      this.taCenter = new System.Windows.Forms.RadioButton();
      this.taLeft = new System.Windows.Forms.RadioButton();
      this.FontItalic = new System.Windows.Forms.CheckBox();
      this.FontBold = new System.Windows.Forms.CheckBox();
      this.FontFamily = new System.Windows.Forms.TextBox();
      this.lFamily = new System.Windows.Forms.Label();
      this.lFontSize = new System.Windows.Forms.Label();
      this.FontSize = new System.Windows.Forms.TextBox();
      this.tbText = new System.Windows.Forms.TextBox();
      this.tp7 = new System.Windows.Forms.TabPage();
      this.gIconTransp = new System.Windows.Forms.Panel();
      this.gIconSize = new System.Windows.Forms.Panel();
      this.label4 = new System.Windows.Forms.Label();
      this.lIcon = new System.Windows.Forms.Label();
      this.tNewHeight = new System.Windows.Forms.TextBox();
      this.tNewWidth = new System.Windows.Forms.TextBox();
      this.lNew = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.bPrint = new System.Windows.Forms.Button();
      this.gPrintMulti = new System.Windows.Forms.Panel();
      this.rPrint1x1 = new System.Windows.Forms.RadioButton();
      this.rPrint2x2 = new System.Windows.Forms.RadioButton();
      this.rPrint2x1 = new System.Windows.Forms.RadioButton();
      this.rPrint3x2 = new System.Windows.Forms.RadioButton();
      this.rPrint3x1 = new System.Windows.Forms.RadioButton();
      this.gOrientation = new System.Windows.Forms.Panel();
      this.rPortrait = new System.Windows.Forms.RadioButton();
      this.rLandscape = new System.Windows.Forms.RadioButton();
      this.bDrawFree = new System.Windows.Forms.Button();
      this.bDrawLine = new System.Windows.Forms.Button();
      this.bDrawRect = new System.Windows.Forms.Button();
      this.bDrawPolar = new System.Windows.Forms.Button();
      this.bDrawEdge = new System.Windows.Forms.Button();
      this.bDrawMorph = new System.Windows.Forms.Button();
      this.bDrawReplace = new System.Windows.Forms.Button();
      this.tabControl1.SuspendLayout();
      this.tp6.SuspendLayout();
      this.tp1.SuspendLayout();
      this.tp3.SuspendLayout();
      this.tp2.SuspendLayout();
      this.rbPasteFilter.SuspendLayout();
      this.gPasteDiff.SuspendLayout();
      this.tp4.SuspendLayout();
      this.panel1.SuspendLayout();
      this.BWPanel.SuspendLayout();
      this.tp5.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tPadding)).BeginInit();
      this.panel3.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tbTlDash2)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tbTLWidth2)).BeginInit();
      this.TextAlign.SuspendLayout();
      this.tp7.SuspendLayout();
      this.gIconTransp.SuspendLayout();
      this.gIconSize.SuspendLayout();
      this.gPrintMulti.SuspendLayout();
      this.gOrientation.SuspendLayout();
      this.SuspendLayout();
      // 
      // ExpandB
      // 
      this.ExpandB.Location = new System.Drawing.Point(132, 15);
      this.ExpandB.Name = "ExpandB";
      this.ExpandB.Size = new System.Drawing.Size(55, 23);
      this.ExpandB.TabIndex = 10;
      this.ExpandB.Tag = "expand";
      this.ExpandB.Text = "Expand";
      this.toolTip.SetToolTip(this.ExpandB, "Expand black color by 1 pixel.\r\nUses X8 switch.\r\n\r\n");
      this.ExpandB.UseVisualStyleBackColor = true;
      this.ExpandB.Click += new System.EventHandler(this.Cmd);
      // 
      // X8
      // 
      this.X8.AutoSize = true;
      this.X8.Location = new System.Drawing.Point(47, 137);
      this.X8.Name = "X8";
      this.X8.Size = new System.Drawing.Size(39, 17);
      this.X8.TabIndex = 11;
      this.X8.Text = "X8";
      this.X8.UseVisualStyleBackColor = true;
      // 
      // ExpandWhite
      // 
      this.ExpandWhite.AutoSize = true;
      this.ExpandWhite.Location = new System.Drawing.Point(80, 18);
      this.ExpandWhite.Name = "ExpandWhite";
      this.ExpandWhite.Size = new System.Drawing.Size(54, 17);
      this.ExpandWhite.TabIndex = 13;
      this.ExpandWhite.Text = "White";
      this.toolTip.SetToolTip(this.ExpandWhite, "Convert white pixels around nonwhite pixels to black.\r\n");
      this.ExpandWhite.UseVisualStyleBackColor = true;
      // 
      // ExpandWOnly
      // 
      this.ExpandWOnly.AutoSize = true;
      this.ExpandWOnly.Location = new System.Drawing.Point(16, 18);
      this.ExpandWOnly.Name = "ExpandWOnly";
      this.ExpandWOnly.Size = new System.Drawing.Size(58, 17);
      this.ExpandWOnly.TabIndex = 14;
      this.ExpandWOnly.Text = "WOnly";
      this.toolTip.SetToolTip(this.ExpandWOnly, "Expand only to white pixels.");
      this.ExpandWOnly.UseVisualStyleBackColor = true;
      // 
      // UndoB
      // 
      this.UndoB.Location = new System.Drawing.Point(302, 137);
      this.UndoB.Name = "UndoB";
      this.UndoB.Size = new System.Drawing.Size(53, 23);
      this.UndoB.TabIndex = 15;
      this.UndoB.Tag = "undo";
      this.UndoB.Text = "Undo";
      this.UndoB.UseVisualStyleBackColor = true;
      this.UndoB.Click += new System.EventHandler(this.Cmd);
      // 
      // RedoB
      // 
      this.RedoB.Location = new System.Drawing.Point(361, 137);
      this.RedoB.Name = "RedoB";
      this.RedoB.Size = new System.Drawing.Size(53, 23);
      this.RedoB.TabIndex = 16;
      this.RedoB.Tag = "redo";
      this.RedoB.Text = "Redo";
      this.RedoB.UseVisualStyleBackColor = true;
      this.RedoB.Click += new System.EventHandler(this.Cmd);
      // 
      // ScreenB
      // 
      this.ScreenB.Location = new System.Drawing.Point(234, 137);
      this.ScreenB.Name = "ScreenB";
      this.ScreenB.Size = new System.Drawing.Size(53, 23);
      this.ScreenB.TabIndex = 18;
      this.ScreenB.Tag = "screen 1000";
      this.ScreenB.Text = "Screen";
      this.toolTip.SetToolTip(this.ScreenB, "Take screenshoot");
      this.ScreenB.UseVisualStyleBackColor = true;
      this.ScreenB.Click += new System.EventHandler(this.Cmd);
      // 
      // ExpandDiffB
      // 
      this.ExpandDiffB.Location = new System.Drawing.Point(216, 14);
      this.ExpandDiffB.Name = "ExpandDiffB";
      this.ExpandDiffB.Size = new System.Drawing.Size(55, 23);
      this.ExpandDiffB.TabIndex = 19;
      this.ExpandDiffB.Tag = "expand diff";
      this.ExpandDiffB.Text = "Diff";
      this.toolTip.SetToolTip(this.ExpandDiffB, "Convert inner black pixels to white pixels.\r\nUse X8 switch.");
      this.ExpandDiffB.UseVisualStyleBackColor = true;
      this.ExpandDiffB.Click += new System.EventHandler(this.Cmd);
      // 
      // label2
      // 
      this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label2.Location = new System.Drawing.Point(13, 71);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(400, 2);
      this.label2.TabIndex = 27;
      // 
      // lFill
      // 
      this.lFill.AutoSize = true;
      this.lFill.Location = new System.Drawing.Point(25, 91);
      this.lFill.Name = "lFill";
      this.lFill.Size = new System.Drawing.Size(34, 13);
      this.lFill.TabIndex = 28;
      this.lFill.Text = "Fill (F)";
      // 
      // Fill2Black
      // 
      this.Fill2Black.AutoSize = true;
      this.Fill2Black.Checked = true;
      this.Fill2Black.CheckState = System.Windows.Forms.CheckState.Checked;
      this.Fill2Black.Location = new System.Drawing.Point(216, 91);
      this.Fill2Black.Name = "Fill2Black";
      this.Fill2Black.Size = new System.Drawing.Size(62, 17);
      this.Fill2Black.TabIndex = 29;
      this.Fill2Black.Text = "2 Black";
      this.toolTip.SetToolTip(this.Fill2Black, "Fill to black color.\r\nOtherwise fill color under cursor.");
      this.Fill2Black.UseVisualStyleBackColor = true;
      // 
      // FillD8
      // 
      this.FillD8.AutoSize = true;
      this.FillD8.Location = new System.Drawing.Point(176, 91);
      this.FillD8.Name = "FillD8";
      this.FillD8.Size = new System.Drawing.Size(40, 17);
      this.FillD8.TabIndex = 30;
      this.FillD8.Text = "D8";
      this.toolTip.SetToolTip(this.FillD8, "Switch between fill 4 or 8 pixel in one step");
      this.FillD8.UseVisualStyleBackColor = true;
      // 
      // label3
      // 
      this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label3.Location = new System.Drawing.Point(16, 122);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(400, 2);
      this.label3.TabIndex = 38;
      // 
      // toolTip
      // 
      this.toolTip.AutomaticDelay = 1000;
      // 
      // FillNoBlack
      // 
      this.FillNoBlack.AutoSize = true;
      this.FillNoBlack.Checked = true;
      this.FillNoBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.FillNoBlack.Location = new System.Drawing.Point(277, 90);
      this.FillNoBlack.Name = "FillNoBlack";
      this.FillNoBlack.Size = new System.Drawing.Size(70, 17);
      this.FillNoBlack.TabIndex = 54;
      this.FillNoBlack.Text = "No Black";
      this.toolTip.SetToolTip(this.FillNoBlack, "Fill to black color.\r\nOtherwise fill color under cursor.");
      this.FillNoBlack.UseVisualStyleBackColor = true;
      // 
      // DrawWOnly
      // 
      this.DrawWOnly.AutoSize = true;
      this.DrawWOnly.Location = new System.Drawing.Point(339, 63);
      this.DrawWOnly.Name = "DrawWOnly";
      this.DrawWOnly.Size = new System.Drawing.Size(58, 17);
      this.DrawWOnly.TabIndex = 59;
      this.DrawWOnly.Text = "WOnly";
      this.toolTip.SetToolTip(this.DrawWOnly, "Draw only on white.");
      this.DrawWOnly.UseVisualStyleBackColor = true;
      // 
      // bGray
      // 
      this.bGray.Location = new System.Drawing.Point(240, 21);
      this.bGray.Name = "bGray";
      this.bGray.Size = new System.Drawing.Size(48, 23);
      this.bGray.TabIndex = 67;
      this.bGray.Tag = "gray";
      this.bGray.Text = "Gray";
      this.toolTip.SetToolTip(this.bGray, "Convert to grayscale");
      this.bGray.UseVisualStyleBackColor = true;
      this.bGray.Click += new System.EventHandler(this.Cmd);
      // 
      // Invert
      // 
      this.Invert.Location = new System.Drawing.Point(215, 45);
      this.Invert.Name = "Invert";
      this.Invert.Size = new System.Drawing.Size(48, 23);
      this.Invert.TabIndex = 66;
      this.Invert.Tag = "invert";
      this.Invert.Text = "Invert";
      this.toolTip.SetToolTip(this.Invert, "Invert color or intensity");
      this.Invert.UseVisualStyleBackColor = true;
      this.Invert.Click += new System.EventHandler(this.Cmd);
      // 
      // cbInvertBW
      // 
      this.cbInvertBW.AutoSize = true;
      this.cbInvertBW.Location = new System.Drawing.Point(200, 49);
      this.cbInvertBW.Name = "cbInvertBW";
      this.cbInvertBW.Size = new System.Drawing.Size(15, 14);
      this.cbInvertBW.TabIndex = 65;
      this.toolTip.SetToolTip(this.cbInvertBW, "Invert black & white");
      this.cbInvertBW.UseVisualStyleBackColor = true;
      // 
      // cbInvertIntensity
      // 
      this.cbInvertIntensity.AutoSize = true;
      this.cbInvertIntensity.Location = new System.Drawing.Point(185, 49);
      this.cbInvertIntensity.Name = "cbInvertIntensity";
      this.cbInvertIntensity.Size = new System.Drawing.Size(15, 14);
      this.cbInvertIntensity.TabIndex = 64;
      this.toolTip.SetToolTip(this.cbInvertIntensity, "Invert intensity");
      this.cbInvertIntensity.UseVisualStyleBackColor = true;
      // 
      // rgb2cmyB
      // 
      this.rgb2cmyB.Location = new System.Drawing.Point(94, 46);
      this.rgb2cmyB.Name = "rgb2cmyB";
      this.rgb2cmyB.Size = new System.Drawing.Size(89, 23);
      this.rgb2cmyB.TabIndex = 56;
      this.rgb2cmyB.Tag = "rgb cmy";
      this.rgb2cmyB.Text = "RGB<=>CMY";
      this.toolTip.SetToolTip(this.rgb2cmyB, "Change RGB to complement CMY colors");
      this.rgb2cmyB.UseVisualStyleBackColor = true;
      this.rgb2cmyB.Click += new System.EventHandler(this.Cmd);
      // 
      // rgbshiftB
      // 
      this.rgbshiftB.Location = new System.Drawing.Point(28, 46);
      this.rgbshiftB.Name = "rgbshiftB";
      this.rgbshiftB.Size = new System.Drawing.Size(64, 23);
      this.rgbshiftB.TabIndex = 57;
      this.rgbshiftB.Tag = "rgb";
      this.rgbshiftB.Text = "RGB >>";
      this.toolTip.SetToolTip(this.rgbshiftB, "Switch RGB color parts");
      this.rgbshiftB.UseVisualStyleBackColor = true;
      this.rgbshiftB.Click += new System.EventHandler(this.Cmd);
      // 
      // levelsB
      // 
      this.levelsB.Location = new System.Drawing.Point(293, 46);
      this.levelsB.Name = "levelsB";
      this.levelsB.Size = new System.Drawing.Size(53, 23);
      this.levelsB.TabIndex = 58;
      this.levelsB.Tag = "levels";
      this.levelsB.Text = "Levels";
      this.toolTip.SetToolTip(this.levelsB, "Modify color intensity to number of levels.");
      this.levelsB.UseVisualStyleBackColor = true;
      this.levelsB.Click += new System.EventHandler(this.Cmd);
      // 
      // contour
      // 
      this.contour.Location = new System.Drawing.Point(352, 46);
      this.contour.Name = "contour";
      this.contour.Size = new System.Drawing.Size(53, 23);
      this.contour.TabIndex = 60;
      this.contour.Tag = "contour";
      this.contour.Text = "Contour";
      this.toolTip.SetToolTip(this.contour, "Make black contour between color levels");
      this.contour.UseVisualStyleBackColor = true;
      this.contour.Click += new System.EventHandler(this.Cmd);
      // 
      // BW
      // 
      this.BW.Location = new System.Drawing.Point(197, 21);
      this.BW.Name = "BW";
      this.BW.Size = new System.Drawing.Size(37, 23);
      this.BW.TabIndex = 62;
      this.BW.Tag = "bw";
      this.BW.Text = "BW";
      this.toolTip.SetToolTip(this.BW, "Convert to black & white image.\r\nEverything under level is black.\r\nMin,avg max se" +
        "ts value to compare with level.");
      this.BW.UseVisualStyleBackColor = true;
      this.BW.Click += new System.EventHandler(this.Cmd);
      // 
      // cbContrast
      // 
      this.cbContrast.AutoSize = true;
      this.cbContrast.Location = new System.Drawing.Point(165, 127);
      this.cbContrast.Name = "cbContrast";
      this.cbContrast.Size = new System.Drawing.Size(15, 14);
      this.cbContrast.TabIndex = 73;
      this.toolTip.SetToolTip(this.cbContrast, "RGB contrast");
      this.cbContrast.UseVisualStyleBackColor = true;
      // 
      // bBorder
      // 
      this.bBorder.Location = new System.Drawing.Point(352, 21);
      this.bBorder.Name = "bBorder";
      this.bBorder.Size = new System.Drawing.Size(48, 23);
      this.bBorder.TabIndex = 74;
      this.bBorder.Tag = "border";
      this.bBorder.Text = "Border";
      this.toolTip.SetToolTip(this.bBorder, "Convert dark gradient pixels to black");
      this.bBorder.UseVisualStyleBackColor = true;
      this.bBorder.Click += new System.EventHandler(this.Cmd);
      // 
      // bRemoveDots
      // 
      this.bRemoveDots.Location = new System.Drawing.Point(352, 75);
      this.bRemoveDots.Name = "bRemoveDots";
      this.bRemoveDots.Size = new System.Drawing.Size(81, 23);
      this.bRemoveDots.TabIndex = 76;
      this.bRemoveDots.Tag = "remove_dots";
      this.bRemoveDots.Text = "Remove dots";
      this.toolTip.SetToolTip(this.bRemoveDots, "Replace pixel dots with avereage color");
      this.bRemoveDots.UseVisualStyleBackColor = true;
      this.bRemoveDots.Click += new System.EventHandler(this.Cmd);
      // 
      // chRemDotWhite
      // 
      this.chRemDotWhite.AutoSize = true;
      this.chRemDotWhite.Location = new System.Drawing.Point(331, 80);
      this.chRemDotWhite.Name = "chRemDotWhite";
      this.chRemDotWhite.Size = new System.Drawing.Size(15, 14);
      this.chRemDotWhite.TabIndex = 77;
      this.toolTip.SetToolTip(this.chRemDotWhite, "White");
      this.chRemDotWhite.UseVisualStyleBackColor = true;
      // 
      // chRemDotBlack
      // 
      this.chRemDotBlack.AutoSize = true;
      this.chRemDotBlack.Checked = true;
      this.chRemDotBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chRemDotBlack.Location = new System.Drawing.Point(313, 80);
      this.chRemDotBlack.Name = "chRemDotBlack";
      this.chRemDotBlack.Size = new System.Drawing.Size(15, 14);
      this.chRemDotBlack.TabIndex = 78;
      this.toolTip.SetToolTip(this.chRemDotBlack, "Black");
      this.chRemDotBlack.UseVisualStyleBackColor = true;
      // 
      // rRemDot3
      // 
      this.rRemDot3.AutoSize = true;
      this.rRemDot3.Location = new System.Drawing.Point(4, 3);
      this.rRemDot3.Name = "rRemDot3";
      this.rRemDot3.Size = new System.Drawing.Size(31, 17);
      this.rRemDot3.TabIndex = 79;
      this.rRemDot3.Text = "3";
      this.toolTip.SetToolTip(this.rRemDot3, "3 points");
      this.rRemDot3.UseVisualStyleBackColor = true;
      // 
      // rRemDot4
      // 
      this.rRemDot4.AutoSize = true;
      this.rRemDot4.Checked = true;
      this.rRemDot4.Location = new System.Drawing.Point(38, 3);
      this.rRemDot4.Name = "rRemDot4";
      this.rRemDot4.Size = new System.Drawing.Size(31, 17);
      this.rRemDot4.TabIndex = 80;
      this.rRemDot4.TabStop = true;
      this.rRemDot4.Text = "4";
      this.toolTip.SetToolTip(this.rRemDot4, "4 points");
      this.rRemDot4.UseVisualStyleBackColor = true;
      // 
      // rRemDot8
      // 
      this.rRemDot8.AutoSize = true;
      this.rRemDot8.Location = new System.Drawing.Point(72, 3);
      this.rRemDot8.Name = "rRemDot8";
      this.rRemDot8.Size = new System.Drawing.Size(31, 17);
      this.rRemDot8.TabIndex = 81;
      this.rRemDot8.Text = "8";
      this.toolTip.SetToolTip(this.rRemDot8, "8 points");
      this.rRemDot8.UseVisualStyleBackColor = true;
      // 
      // NormColorB
      // 
      this.NormColorB.Location = new System.Drawing.Point(181, 122);
      this.NormColorB.Name = "NormColorB";
      this.NormColorB.Size = new System.Drawing.Size(61, 23);
      this.NormColorB.TabIndex = 72;
      this.NormColorB.Tag = "contrast";
      this.NormColorB.Text = "Contrast";
      this.toolTip.SetToolTip(this.NormColorB, "Extent colors to full range");
      this.NormColorB.UseVisualStyleBackColor = true;
      this.NormColorB.Click += new System.EventHandler(this.Cmd);
      // 
      // chBrightBW
      // 
      this.chBrightBW.AutoSize = true;
      this.chBrightBW.Location = new System.Drawing.Point(75, 127);
      this.chBrightBW.Name = "chBrightBW";
      this.chBrightBW.Size = new System.Drawing.Size(15, 14);
      this.chBrightBW.TabIndex = 79;
      this.toolTip.SetToolTip(this.chBrightBW, "Leave black and white");
      this.chBrightBW.UseVisualStyleBackColor = true;
      // 
      // bCReplace
      // 
      this.bCReplace.Location = new System.Drawing.Point(28, 75);
      this.bCReplace.Name = "bCReplace";
      this.bCReplace.Size = new System.Drawing.Size(56, 23);
      this.bCReplace.TabIndex = 80;
      this.bCReplace.Tag = "replace";
      this.bCReplace.Text = "Replace";
      this.toolTip.SetToolTip(this.bCReplace, "Replace fore color with back color");
      this.bCReplace.UseVisualStyleBackColor = true;
      this.bCReplace.Click += new System.EventHandler(this.Cmd);
      // 
      // Snap
      // 
      this.Snap.Location = new System.Drawing.Point(88, 129);
      this.Snap.Name = "Snap";
      this.Snap.Size = new System.Drawing.Size(27, 20);
      this.Snap.TabIndex = 70;
      this.Snap.Text = "24";
      this.toolTip.SetToolTip(this.Snap, "Snap size");
      this.Snap.TextChanged += new System.EventHandler(this.SnapChanged);
      // 
      // chSnap
      // 
      this.chSnap.AutoSize = true;
      this.chSnap.Location = new System.Drawing.Point(31, 131);
      this.chSnap.Name = "chSnap";
      this.chSnap.Size = new System.Drawing.Size(51, 17);
      this.chSnap.TabIndex = 72;
      this.chSnap.Text = "Snap";
      this.toolTip.SetToolTip(this.chSnap, "Snap to grid");
      this.chSnap.UseVisualStyleBackColor = true;
      this.chSnap.CheckedChanged += new System.EventHandler(this.SnapChanged);
      // 
      // ImpandB
      // 
      this.ImpandB.Location = new System.Drawing.Point(216, 43);
      this.ImpandB.Name = "ImpandB";
      this.ImpandB.Size = new System.Drawing.Size(55, 23);
      this.ImpandB.TabIndex = 55;
      this.ImpandB.Tag = "impand";
      this.ImpandB.Text = "Impand";
      this.toolTip.SetToolTip(this.ImpandB, "Convert outer black/fore pixels to back pixels.\r\nUse X8 switch.");
      this.ImpandB.UseVisualStyleBackColor = true;
      this.ImpandB.Click += new System.EventHandler(this.Cmd);
      // 
      // chImpandBlack
      // 
      this.chImpandBlack.AutoSize = true;
      this.chImpandBlack.Checked = true;
      this.chImpandBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chImpandBlack.Location = new System.Drawing.Point(81, 47);
      this.chImpandBlack.Name = "chImpandBlack";
      this.chImpandBlack.Size = new System.Drawing.Size(53, 17);
      this.chImpandBlack.TabIndex = 56;
      this.chImpandBlack.Text = "Black";
      this.toolTip.SetToolTip(this.chImpandBlack, "Impand black color");
      this.chImpandBlack.UseVisualStyleBackColor = true;
      // 
      // bRemoveDust
      // 
      this.bRemoveDust.Location = new System.Drawing.Point(352, 104);
      this.bRemoveDust.Name = "bRemoveDust";
      this.bRemoveDust.Size = new System.Drawing.Size(81, 23);
      this.bRemoveDust.TabIndex = 81;
      this.bRemoveDust.Tag = "remove_dust";
      this.bRemoveDust.Text = "Remove dust";
      this.toolTip.SetToolTip(this.bRemoveDust, "Replace pixel dots with avereage color");
      this.bRemoveDust.UseVisualStyleBackColor = true;
      this.bRemoveDust.Click += new System.EventHandler(this.Cmd);
      // 
      // dustLevel
      // 
      this.dustLevel.Location = new System.Drawing.Point(285, 104);
      this.dustLevel.Name = "dustLevel";
      this.dustLevel.Size = new System.Drawing.Size(22, 20);
      this.dustLevel.TabIndex = 82;
      this.dustLevel.Tag = "";
      this.dustLevel.Text = "16";
      this.toolTip.SetToolTip(this.dustLevel, "Maximum dust size");
      // 
      // blackDust
      // 
      this.blackDust.AutoSize = true;
      this.blackDust.Checked = true;
      this.blackDust.CheckState = System.Windows.Forms.CheckState.Checked;
      this.blackDust.Location = new System.Drawing.Point(313, 109);
      this.blackDust.Name = "blackDust";
      this.blackDust.Size = new System.Drawing.Size(15, 14);
      this.blackDust.TabIndex = 83;
      this.toolTip.SetToolTip(this.blackDust, "Black dust");
      this.blackDust.UseVisualStyleBackColor = true;
      // 
      // whiteDust
      // 
      this.whiteDust.AutoSize = true;
      this.whiteDust.Location = new System.Drawing.Point(332, 109);
      this.whiteDust.Name = "whiteDust";
      this.whiteDust.Size = new System.Drawing.Size(15, 14);
      this.whiteDust.TabIndex = 84;
      this.toolTip.SetToolTip(this.whiteDust, "White dust");
      this.whiteDust.UseVisualStyleBackColor = true;
      // 
      // pasteTRX
      // 
      this.pasteTRX.AutoSize = true;
      this.pasteTRX.Location = new System.Drawing.Point(96, 61);
      this.pasteTRX.Name = "pasteTRX";
      this.pasteTRX.Size = new System.Drawing.Size(53, 17);
      this.pasteTRX.TabIndex = 56;
      this.pasteTRX.Text = "Fuzzy";
      this.toolTip.SetToolTip(this.pasteTRX, "Border of transparent color is mixed");
      this.pasteTRX.UseVisualStyleBackColor = true;
      // 
      // pasteTrans
      // 
      this.pasteTrans.AutoSize = true;
      this.pasteTrans.Location = new System.Drawing.Point(7, 61);
      this.pasteTrans.Name = "pasteTrans";
      this.pasteTrans.Size = new System.Drawing.Size(83, 17);
      this.pasteTrans.TabIndex = 55;
      this.pasteTrans.Text = "Transparent";
      this.toolTip.SetToolTip(this.pasteTrans, "Use second color as transparent");
      this.pasteTrans.UseVisualStyleBackColor = true;
      // 
      // pasteMix
      // 
      this.pasteMix.AutoSize = true;
      this.pasteMix.Location = new System.Drawing.Point(7, 84);
      this.pasteMix.Name = "pasteMix";
      this.pasteMix.Size = new System.Drawing.Size(42, 17);
      this.pasteMix.TabIndex = 59;
      this.pasteMix.Text = "Mix";
      this.toolTip.SetToolTip(this.pasteMix, "Mix current and paste color 1:3");
      this.pasteMix.UseVisualStyleBackColor = true;
      // 
      // bText
      // 
      this.bText.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bText.Location = new System.Drawing.Point(394, 3);
      this.bText.Name = "bText";
      this.bText.Size = new System.Drawing.Size(48, 23);
      this.bText.TabIndex = 75;
      this.bText.Tag = "text";
      this.bText.Text = "Draw";
      this.toolTip.SetToolTip(this.bText, "Draw text");
      this.bText.UseVisualStyleBackColor = true;
      this.bText.Click += new System.EventHandler(this.Cmd);
      // 
      // FntDialog
      // 
      this.FntDialog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FntDialog.Location = new System.Drawing.Point(254, 4);
      this.FntDialog.Name = "FntDialog";
      this.FntDialog.Size = new System.Drawing.Size(36, 23);
      this.FntDialog.TabIndex = 83;
      this.FntDialog.Tag = "font dialog";
      this.FntDialog.Text = "...";
      this.toolTip.SetToolTip(this.FntDialog, "Convert dark gradient pixels to black");
      this.FntDialog.UseVisualStyleBackColor = true;
      this.FntDialog.Click += new System.EventHandler(this.Cmd);
      // 
      // chTBWAuto
      // 
      this.chTBWAuto.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chTBWAuto.AutoSize = true;
      this.chTBWAuto.Checked = true;
      this.chTBWAuto.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chTBWAuto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chTBWAuto.Location = new System.Drawing.Point(338, 7);
      this.chTBWAuto.Name = "chTBWAuto";
      this.chTBWAuto.Size = new System.Drawing.Size(46, 17);
      this.chTBWAuto.TabIndex = 96;
      this.chTBWAuto.Text = "B|W";
      this.toolTip.SetToolTip(this.chTBWAuto, "Automatic black or white");
      this.chTBWAuto.UseVisualStyleBackColor = true;
      // 
      // chLColorFont
      // 
      this.chLColorFont.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chLColorFont.AutoSize = true;
      this.chLColorFont.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chLColorFont.Location = new System.Drawing.Point(287, 149);
      this.chLColorFont.Name = "chLColorFont";
      this.chLColorFont.Size = new System.Drawing.Size(15, 14);
      this.chLColorFont.TabIndex = 97;
      this.toolTip.SetToolTip(this.chLColorFont, "As font color");
      this.chLColorFont.UseVisualStyleBackColor = true;
      // 
      // BOutline
      // 
      this.BOutline.Location = new System.Drawing.Point(132, 41);
      this.BOutline.Name = "BOutline";
      this.BOutline.Size = new System.Drawing.Size(55, 23);
      this.BOutline.TabIndex = 57;
      this.BOutline.Tag = "outline";
      this.BOutline.Text = "Outline";
      this.toolTip.SetToolTip(this.BOutline, "Expand black color by 1 pixel.\r\nUses X8 switch.\r\n\r\n");
      this.BOutline.UseVisualStyleBackColor = true;
      this.BOutline.Click += new System.EventHandler(this.Cmd);
      // 
      // bCRemove
      // 
      this.bCRemove.Location = new System.Drawing.Point(277, 43);
      this.bCRemove.Name = "bCRemove";
      this.bCRemove.Size = new System.Drawing.Size(61, 23);
      this.bCRemove.TabIndex = 86;
      this.bCRemove.Tag = "remove";
      this.bCRemove.Text = "Remove";
      this.toolTip.SetToolTip(this.bCRemove, "Remove fore color ");
      this.bCRemove.UseVisualStyleBackColor = true;
      this.bCRemove.Click += new System.EventHandler(this.Cmd);
      // 
      // pasteFiles
      // 
      this.pasteFiles.AutoSize = true;
      this.pasteFiles.Checked = true;
      this.pasteFiles.CheckState = System.Windows.Forms.CheckState.Checked;
      this.pasteFiles.Location = new System.Drawing.Point(281, 61);
      this.pasteFiles.Name = "pasteFiles";
      this.pasteFiles.Size = new System.Drawing.Size(47, 17);
      this.pasteFiles.TabIndex = 54;
      this.pasteFiles.Text = "Files";
      this.toolTip.SetToolTip(this.pasteFiles, "Paste file names and urls from text in clipboard");
      this.pasteFiles.UseVisualStyleBackColor = true;
      // 
      // tsDiamond
      // 
      this.tsDiamond.AutoSize = true;
      this.tsDiamond.Location = new System.Drawing.Point(108, 3);
      this.tsDiamond.Name = "tsDiamond";
      this.tsDiamond.Size = new System.Drawing.Size(82, 17);
      this.tsDiamond.TabIndex = 35;
      this.tsDiamond.Text = "<> Diamond";
      this.toolTip.SetToolTip(this.tsDiamond, "Diamond shape");
      this.tsDiamond.UseVisualStyleBackColor = true;
      // 
      // tsCircle
      // 
      this.tsCircle.AutoSize = true;
      this.tsCircle.Location = new System.Drawing.Point(52, 3);
      this.tsCircle.Name = "tsCircle";
      this.tsCircle.Size = new System.Drawing.Size(61, 17);
      this.tsCircle.TabIndex = 34;
      this.tsCircle.Text = "O circle";
      this.toolTip.SetToolTip(this.tsCircle, "Text in circle");
      this.tsCircle.UseVisualStyleBackColor = true;
      // 
      // tsBox
      // 
      this.tsBox.AutoSize = true;
      this.tsBox.Checked = true;
      this.tsBox.Location = new System.Drawing.Point(3, 3);
      this.tsBox.Name = "tsBox";
      this.tsBox.Size = new System.Drawing.Size(52, 17);
      this.tsBox.TabIndex = 33;
      this.tsBox.TabStop = true;
      this.tsBox.Text = "[] Box";
      this.toolTip.SetToolTip(this.tsBox, "Text in rounded rectangle");
      this.tsBox.UseVisualStyleBackColor = true;
      // 
      // bNew
      // 
      this.bNew.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bNew.Location = new System.Drawing.Point(157, 6);
      this.bNew.Name = "bNew";
      this.bNew.Size = new System.Drawing.Size(48, 23);
      this.bNew.TabIndex = 79;
      this.bNew.Tag = "new";
      this.bNew.Text = "&New";
      this.toolTip.SetToolTip(this.bNew, "Draw text");
      this.bNew.UseVisualStyleBackColor = true;
      this.bNew.Click += new System.EventHandler(this.Cmd);
      // 
      // bSaveIcon
      // 
      this.bSaveIcon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bSaveIcon.Location = new System.Drawing.Point(116, 112);
      this.bSaveIcon.Name = "bSaveIcon";
      this.bSaveIcon.Size = new System.Drawing.Size(48, 23);
      this.bSaveIcon.TabIndex = 83;
      this.bSaveIcon.Tag = "saveicon";
      this.bSaveIcon.Text = "&Save";
      this.toolTip.SetToolTip(this.bSaveIcon, "Save icon");
      this.bSaveIcon.UseVisualStyleBackColor = true;
      this.bSaveIcon.Click += new System.EventHandler(this.Cmd);
      // 
      // tIconHeight
      // 
      this.tIconHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tIconHeight.Location = new System.Drawing.Point(73, 114);
      this.tIconHeight.Name = "tIconHeight";
      this.tIconHeight.Size = new System.Drawing.Size(33, 20);
      this.tIconHeight.TabIndex = 82;
      this.tIconHeight.Text = "32";
      this.toolTip.SetToolTip(this.tIconHeight, "Height");
      // 
      // tIconWidth
      // 
      this.tIconWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tIconWidth.Location = new System.Drawing.Point(35, 114);
      this.tIconWidth.Name = "tIconWidth";
      this.tIconWidth.Size = new System.Drawing.Size(35, 20);
      this.tIconWidth.TabIndex = 81;
      this.tIconWidth.Text = "32";
      this.toolTip.SetToolTip(this.tIconWidth, "Width");
      // 
      // rIconExact
      // 
      this.rIconExact.AutoSize = true;
      this.rIconExact.Location = new System.Drawing.Point(190, 4);
      this.rIconExact.Name = "rIconExact";
      this.rIconExact.Size = new System.Drawing.Size(52, 17);
      this.rIconExact.TabIndex = 79;
      this.rIconExact.Text = "Exact";
      this.toolTip.SetToolTip(this.rIconExact, "Exact size");
      this.rIconExact.UseVisualStyleBackColor = true;
      // 
      // rIconHeight
      // 
      this.rIconHeight.AutoSize = true;
      this.rIconHeight.Location = new System.Drawing.Point(122, 4);
      this.rIconHeight.Name = "rIconHeight";
      this.rIconHeight.Size = new System.Drawing.Size(56, 17);
      this.rIconHeight.TabIndex = 81;
      this.rIconHeight.Text = "Height";
      this.toolTip.SetToolTip(this.rIconHeight, "Fit to height");
      this.rIconHeight.UseVisualStyleBackColor = true;
      // 
      // rIconWidth
      // 
      this.rIconWidth.AutoSize = true;
      this.rIconWidth.Location = new System.Drawing.Point(61, 4);
      this.rIconWidth.Name = "rIconWidth";
      this.rIconWidth.Size = new System.Drawing.Size(53, 17);
      this.rIconWidth.TabIndex = 80;
      this.rIconWidth.Text = "Width";
      this.toolTip.SetToolTip(this.rIconWidth, "Fit to width");
      this.rIconWidth.UseVisualStyleBackColor = true;
      // 
      // rIconAspect
      // 
      this.rIconAspect.AutoSize = true;
      this.rIconAspect.Checked = true;
      this.rIconAspect.Location = new System.Drawing.Point(3, 3);
      this.rIconAspect.Name = "rIconAspect";
      this.rIconAspect.Size = new System.Drawing.Size(58, 17);
      this.rIconAspect.TabIndex = 82;
      this.rIconAspect.TabStop = true;
      this.rIconAspect.Text = "Aspect";
      this.toolTip.SetToolTip(this.rIconAspect, "Fit inside size");
      this.rIconAspect.UseVisualStyleBackColor = true;
      // 
      // rIcon1to1
      // 
      this.rIcon1to1.AutoSize = true;
      this.rIcon1to1.Location = new System.Drawing.Point(252, 4);
      this.rIcon1to1.Name = "rIcon1to1";
      this.rIcon1to1.Size = new System.Drawing.Size(40, 17);
      this.rIcon1to1.TabIndex = 83;
      this.rIcon1to1.Text = "1:1";
      this.toolTip.SetToolTip(this.rIcon1to1, "Image unchanged");
      this.rIcon1to1.UseVisualStyleBackColor = true;
      // 
      // chIconCursor
      // 
      this.chIconCursor.AutoSize = true;
      this.chIconCursor.Location = new System.Drawing.Point(177, 117);
      this.chIconCursor.Name = "chIconCursor";
      this.chIconCursor.Size = new System.Drawing.Size(56, 17);
      this.chIconCursor.TabIndex = 86;
      this.chIconCursor.Text = "Cursor";
      this.toolTip.SetToolTip(this.chIconCursor, "cursor or icon");
      this.chIconCursor.UseVisualStyleBackColor = true;
      // 
      // rIconTrWhite
      // 
      this.rIconTrWhite.AutoSize = true;
      this.rIconTrWhite.Checked = true;
      this.rIconTrWhite.Location = new System.Drawing.Point(4, 3);
      this.rIconTrWhite.Name = "rIconTrWhite";
      this.rIconTrWhite.Size = new System.Drawing.Size(53, 17);
      this.rIconTrWhite.TabIndex = 79;
      this.rIconTrWhite.TabStop = true;
      this.rIconTrWhite.Text = "White";
      this.toolTip.SetToolTip(this.rIconTrWhite, "White is transparent");
      this.rIconTrWhite.UseVisualStyleBackColor = true;
      // 
      // rIconTrNone
      // 
      this.rIconTrNone.AutoSize = true;
      this.rIconTrNone.Location = new System.Drawing.Point(126, 3);
      this.rIconTrNone.Name = "rIconTrNone";
      this.rIconTrNone.Size = new System.Drawing.Size(51, 17);
      this.rIconTrNone.TabIndex = 81;
      this.rIconTrNone.Text = "None";
      this.toolTip.SetToolTip(this.rIconTrNone, "No transparent color");
      this.rIconTrNone.UseVisualStyleBackColor = true;
      // 
      // rIconTrColor2
      // 
      this.rIconTrColor2.AutoSize = true;
      this.rIconTrColor2.Location = new System.Drawing.Point(61, 3);
      this.rIconTrColor2.Name = "rIconTrColor2";
      this.rIconTrColor2.Size = new System.Drawing.Size(62, 17);
      this.rIconTrColor2.TabIndex = 80;
      this.rIconTrColor2.Text = "Second";
      this.toolTip.SetToolTip(this.rIconTrColor2, "Color 2 is transparent");
      this.rIconTrColor2.UseVisualStyleBackColor = true;
      // 
      // rbFilterColor2
      // 
      this.rbFilterColor2.AutoSize = true;
      this.rbFilterColor2.Location = new System.Drawing.Point(96, 3);
      this.rbFilterColor2.Name = "rbFilterColor2";
      this.rbFilterColor2.Size = new System.Drawing.Size(58, 17);
      this.rbFilterColor2.TabIndex = 40;
      this.rbFilterColor2.Text = "Color 2";
      this.toolTip.SetToolTip(this.rbFilterColor2, "Paste only on color2");
      this.rbFilterColor2.UseVisualStyleBackColor = true;
      // 
      // rbFilterWhite
      // 
      this.rbFilterWhite.AutoSize = true;
      this.rbFilterWhite.Location = new System.Drawing.Point(43, 3);
      this.rbFilterWhite.Name = "rbFilterWhite";
      this.rbFilterWhite.Size = new System.Drawing.Size(53, 17);
      this.rbFilterWhite.TabIndex = 37;
      this.rbFilterWhite.Tag = "";
      this.rbFilterWhite.Text = "White";
      this.toolTip.SetToolTip(this.rbFilterWhite, "Paste only on white");
      this.rbFilterWhite.UseVisualStyleBackColor = true;
      // 
      // rbFilterOff
      // 
      this.rbFilterOff.AutoSize = true;
      this.rbFilterOff.Checked = true;
      this.rbFilterOff.Location = new System.Drawing.Point(3, 3);
      this.rbFilterOff.Name = "rbFilterOff";
      this.rbFilterOff.Size = new System.Drawing.Size(39, 17);
      this.rbFilterOff.TabIndex = 36;
      this.rbFilterOff.TabStop = true;
      this.rbFilterOff.Tag = "";
      this.rbFilterOff.Text = "Off";
      this.toolTip.SetToolTip(this.rbFilterOff, "No paste filter");
      this.rbFilterOff.UseVisualStyleBackColor = true;
      // 
      // rbFilterNotColor2
      // 
      this.rbFilterNotColor2.AutoSize = true;
      this.rbFilterNotColor2.Location = new System.Drawing.Point(155, 3);
      this.rbFilterNotColor2.Name = "rbFilterNotColor2";
      this.rbFilterNotColor2.Size = new System.Drawing.Size(74, 17);
      this.rbFilterNotColor2.TabIndex = 33;
      this.rbFilterNotColor2.Text = "Not color2";
      this.toolTip.SetToolTip(this.rbFilterNotColor2, "Do not paste on color2");
      this.rbFilterNotColor2.UseVisualStyleBackColor = true;
      // 
      // rbFilterAndNotBlack
      // 
      this.rbFilterAndNotBlack.AutoSize = true;
      this.rbFilterAndNotBlack.Location = new System.Drawing.Point(235, 3);
      this.rbFilterAndNotBlack.Name = "rbFilterAndNotBlack";
      this.rbFilterAndNotBlack.Size = new System.Drawing.Size(72, 17);
      this.rbFilterAndNotBlack.TabIndex = 41;
      this.rbFilterAndNotBlack.Text = "and black";
      this.toolTip.SetToolTip(this.rbFilterAndNotBlack, "Do not paste on color2 and black");
      this.rbFilterAndNotBlack.UseVisualStyleBackColor = true;
      // 
      // cbFill
      // 
      this.cbFill.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbFill.FormattingEnabled = true;
      this.cbFill.Items.AddRange(new object[] {
            "Circle ()",
            "Diamond <+>",
            "Square [x]",
            "Horizont =",
            "Vertical ||",
            "Raise //",
            "Fall \\\\"});
      this.cbFill.Location = new System.Drawing.Point(71, 89);
      this.cbFill.Name = "cbFill";
      this.cbFill.Size = new System.Drawing.Size(95, 21);
      this.cbFill.TabIndex = 50;
      // 
      // tabControl1
      // 
      this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.tabControl1.Controls.Add(this.tp6);
      this.tabControl1.Controls.Add(this.tp1);
      this.tabControl1.Controls.Add(this.tp3);
      this.tabControl1.Controls.Add(this.tp2);
      this.tabControl1.Controls.Add(this.tp4);
      this.tabControl1.Controls.Add(this.tp5);
      this.tabControl1.Controls.Add(this.tp7);
      this.tabControl1.Location = new System.Drawing.Point(0, 0);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new System.Drawing.Size(453, 196);
      this.tabControl1.TabIndex = 57;
      // 
      // tp6
      // 
      this.tp6.BackColor = System.Drawing.SystemColors.Control;
      this.tp6.Controls.Add(this.bDrawReplace);
      this.tp6.Controls.Add(this.bDrawMorph);
      this.tp6.Controls.Add(this.bDrawEdge);
      this.tp6.Controls.Add(this.bDrawPolar);
      this.tp6.Controls.Add(this.bDrawRect);
      this.tp6.Controls.Add(this.bDrawLine);
      this.tp6.Controls.Add(this.bDrawFree);
      this.tp6.Controls.Add(this.bModeRadial);
      this.tp6.Controls.Add(this.bModeBorder);
      this.tp6.Controls.Add(this.bABlack);
      this.tp6.Controls.Add(this.bCDark2);
      this.tp6.Controls.Add(this.bCLight2);
      this.tp6.Controls.Add(this.bCDark1);
      this.tp6.Controls.Add(this.bCLight1);
      this.tp6.Controls.Add(this.bColorGr8);
      this.tp6.Controls.Add(this.bModeLinear);
      this.tp6.Controls.Add(this.bColorGr6);
      this.tp6.Controls.Add(this.bColorGr5);
      this.tp6.Controls.Add(this.bColorGr4);
      this.tp6.Controls.Add(this.bSwap);
      this.tp6.Controls.Add(this.bColor2);
      this.tp6.Controls.Add(this.bColor);
      this.tp6.Controls.Add(this.bClear);
      this.tp6.Controls.Add(this.bModeSelect);
      this.tp6.Controls.Add(this.bModeFill);
      this.tp6.Controls.Add(this.bModeCircle);
      this.tp6.Controls.Add(this.bBlue);
      this.tp6.Controls.Add(this.button8);
      this.tp6.Controls.Add(this.button7);
      this.tp6.Controls.Add(this.button5);
      this.tp6.Controls.Add(this.button4);
      this.tp6.Controls.Add(this.button6);
      this.tp6.Controls.Add(this.bColorGr1);
      this.tp6.Controls.Add(this.bColorGr3);
      this.tp6.Controls.Add(this.bColorGr2);
      this.tp6.Controls.Add(this.bGY);
      this.tp6.Controls.Add(this.bGreen);
      this.tp6.Controls.Add(this.bRed);
      this.tp6.Controls.Add(this.bColorGr7);
      this.tp6.Controls.Add(this.bYellow);
      this.tp6.Controls.Add(this.button1);
      this.tp6.Controls.Add(this.bCyan);
      this.tp6.Controls.Add(this.bWhite);
      this.tp6.Location = new System.Drawing.Point(4, 22);
      this.tp6.Name = "tp6";
      this.tp6.Size = new System.Drawing.Size(445, 170);
      this.tp6.TabIndex = 5;
      this.tp6.Text = "Color";
      // 
      // bModeRadial
      // 
      this.bModeRadial.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeRadial.BackColor = System.Drawing.SystemColors.Control;
      this.bModeRadial.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeRadial.Location = new System.Drawing.Point(220, 17);
      this.bModeRadial.Name = "bModeRadial";
      this.bModeRadial.Size = new System.Drawing.Size(25, 25);
      this.bModeRadial.TabIndex = 80;
      this.bModeRadial.Tag = "-7";
      this.bModeRadial.Text = "X";
      this.bModeRadial.UseVisualStyleBackColor = false;
      this.bModeRadial.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bModeBorder
      // 
      this.bModeBorder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeBorder.BackColor = System.Drawing.SystemColors.Control;
      this.bModeBorder.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeBorder.Location = new System.Drawing.Point(192, 17);
      this.bModeBorder.Name = "bModeBorder";
      this.bModeBorder.Size = new System.Drawing.Size(25, 25);
      this.bModeBorder.TabIndex = 79;
      this.bModeBorder.Tag = "-3";
      this.bModeBorder.Text = "#";
      this.bModeBorder.UseVisualStyleBackColor = false;
      this.bModeBorder.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bABlack
      // 
      this.bABlack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bABlack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(1)))));
      this.bABlack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bABlack.Location = new System.Drawing.Point(313, 69);
      this.bABlack.Name = "bABlack";
      this.bABlack.Size = new System.Drawing.Size(20, 20);
      this.bABlack.TabIndex = 78;
      this.bABlack.Tag = "7";
      this.bABlack.UseVisualStyleBackColor = false;
      this.bABlack.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bCDark2
      // 
      this.bCDark2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCDark2.BackColor = System.Drawing.Color.Black;
      this.bCDark2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCDark2.Location = new System.Drawing.Point(311, 119);
      this.bCDark2.Name = "bCDark2";
      this.bCDark2.Size = new System.Drawing.Size(20, 20);
      this.bCDark2.TabIndex = 77;
      this.bCDark2.Tag = "7";
      this.bCDark2.UseVisualStyleBackColor = false;
      this.bCDark2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bCLight2
      // 
      this.bCLight2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCLight2.BackColor = System.Drawing.Color.White;
      this.bCLight2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCLight2.Location = new System.Drawing.Point(229, 117);
      this.bCLight2.Name = "bCLight2";
      this.bCLight2.Size = new System.Drawing.Size(20, 20);
      this.bCLight2.TabIndex = 76;
      this.bCLight2.Tag = "7";
      this.bCLight2.UseVisualStyleBackColor = false;
      this.bCLight2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bCDark1
      // 
      this.bCDark1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCDark1.BackColor = System.Drawing.Color.Black;
      this.bCDark1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCDark1.Location = new System.Drawing.Point(186, 117);
      this.bCDark1.Name = "bCDark1";
      this.bCDark1.Size = new System.Drawing.Size(20, 20);
      this.bCDark1.TabIndex = 75;
      this.bCDark1.Tag = "7";
      this.bCDark1.UseVisualStyleBackColor = false;
      this.bCDark1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bCLight1
      // 
      this.bCLight1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCLight1.BackColor = System.Drawing.Color.White;
      this.bCLight1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCLight1.Location = new System.Drawing.Point(104, 117);
      this.bCLight1.Name = "bCLight1";
      this.bCLight1.Size = new System.Drawing.Size(20, 20);
      this.bCLight1.TabIndex = 74;
      this.bCLight1.Tag = "7";
      this.bCLight1.UseVisualStyleBackColor = false;
      this.bCLight1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr8
      // 
      this.bColorGr8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
      this.bColorGr8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr8.Location = new System.Drawing.Point(271, 69);
      this.bColorGr8.Name = "bColorGr8";
      this.bColorGr8.Size = new System.Drawing.Size(20, 20);
      this.bColorGr8.TabIndex = 73;
      this.bColorGr8.Tag = "8";
      this.bColorGr8.UseVisualStyleBackColor = false;
      this.bColorGr8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bModeLinear
      // 
      this.bModeLinear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeLinear.BackColor = System.Drawing.SystemColors.Control;
      this.bModeLinear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeLinear.Location = new System.Drawing.Point(138, 17);
      this.bModeLinear.Name = "bModeLinear";
      this.bModeLinear.Size = new System.Drawing.Size(25, 25);
      this.bModeLinear.TabIndex = 72;
      this.bModeLinear.Tag = "-6";
      this.bModeLinear.Text = "//";
      this.bModeLinear.UseVisualStyleBackColor = false;
      this.bModeLinear.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bColorGr6
      // 
      this.bColorGr6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
      this.bColorGr6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr6.Location = new System.Drawing.Point(229, 69);
      this.bColorGr6.Name = "bColorGr6";
      this.bColorGr6.Size = new System.Drawing.Size(20, 20);
      this.bColorGr6.TabIndex = 71;
      this.bColorGr6.Tag = "";
      this.bColorGr6.UseVisualStyleBackColor = false;
      this.bColorGr6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr5
      // 
      this.bColorGr5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
      this.bColorGr5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr5.Location = new System.Drawing.Point(208, 69);
      this.bColorGr5.Name = "bColorGr5";
      this.bColorGr5.Size = new System.Drawing.Size(20, 20);
      this.bColorGr5.TabIndex = 70;
      this.bColorGr5.Tag = "";
      this.bColorGr5.UseVisualStyleBackColor = false;
      this.bColorGr5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr4
      // 
      this.bColorGr4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
      this.bColorGr4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr4.Location = new System.Drawing.Point(187, 69);
      this.bColorGr4.Name = "bColorGr4";
      this.bColorGr4.Size = new System.Drawing.Size(20, 20);
      this.bColorGr4.TabIndex = 69;
      this.bColorGr4.Tag = "";
      this.bColorGr4.UseVisualStyleBackColor = false;
      this.bColorGr4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bSwap
      // 
      this.bSwap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bSwap.BackColor = System.Drawing.SystemColors.Control;
      this.bSwap.Location = new System.Drawing.Point(207, 115);
      this.bSwap.Name = "bSwap";
      this.bSwap.Size = new System.Drawing.Size(22, 24);
      this.bSwap.TabIndex = 68;
      this.bSwap.Text = "x";
      this.bSwap.UseVisualStyleBackColor = false;
      this.bSwap.Click += new System.EventHandler(this.Color_Click);
      // 
      // bColor2
      // 
      this.bColor2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColor2.BackColor = System.Drawing.Color.Black;
      this.bColor2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColor2.Location = new System.Drawing.Point(125, 110);
      this.bColor2.Name = "bColor2";
      this.bColor2.Size = new System.Drawing.Size(60, 35);
      this.bColor2.TabIndex = 67;
      this.bColor2.UseVisualStyleBackColor = false;
      this.bColor2.Click += new System.EventHandler(this.Color_Click);
      this.bColor2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColor
      // 
      this.bColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColor.BackColor = System.Drawing.Color.Black;
      this.bColor.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColor.Location = new System.Drawing.Point(250, 110);
      this.bColor.Name = "bColor";
      this.bColor.Size = new System.Drawing.Size(60, 35);
      this.bColor.TabIndex = 65;
      this.bColor.UseVisualStyleBackColor = false;
      this.bColor.Click += new System.EventHandler(this.Color_Click);
      this.bColor.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bClear
      // 
      this.bClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bClear.BackColor = System.Drawing.SystemColors.Control;
      this.bClear.Location = new System.Drawing.Point(8, 110);
      this.bClear.Name = "bClear";
      this.bClear.Size = new System.Drawing.Size(44, 35);
      this.bClear.TabIndex = 66;
      this.bClear.Tag = "255";
      this.bClear.Text = "Clear";
      this.bClear.UseVisualStyleBackColor = false;
      this.bClear.Click += new System.EventHandler(this.Color_Click);
      // 
      // bModeSelect
      // 
      this.bModeSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeSelect.BackColor = System.Drawing.SystemColors.Control;
      this.bModeSelect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeSelect.Location = new System.Drawing.Point(71, 17);
      this.bModeSelect.Name = "bModeSelect";
      this.bModeSelect.Size = new System.Drawing.Size(25, 25);
      this.bModeSelect.TabIndex = 64;
      this.bModeSelect.Tag = "-5";
      this.bModeSelect.Text = "[ ]";
      this.bModeSelect.UseVisualStyleBackColor = false;
      this.bModeSelect.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bModeFill
      // 
      this.bModeFill.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeFill.BackColor = System.Drawing.SystemColors.Control;
      this.bModeFill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeFill.Location = new System.Drawing.Point(165, 17);
      this.bModeFill.Name = "bModeFill";
      this.bModeFill.Size = new System.Drawing.Size(25, 25);
      this.bModeFill.TabIndex = 63;
      this.bModeFill.Tag = "-2";
      this.bModeFill.Text = "@";
      this.bModeFill.UseVisualStyleBackColor = false;
      this.bModeFill.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bModeCircle
      // 
      this.bModeCircle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bModeCircle.BackColor = System.Drawing.SystemColors.Control;
      this.bModeCircle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bModeCircle.Location = new System.Drawing.Point(110, 17);
      this.bModeCircle.Name = "bModeCircle";
      this.bModeCircle.Size = new System.Drawing.Size(25, 25);
      this.bModeCircle.TabIndex = 62;
      this.bModeCircle.Tag = "-1";
      this.bModeCircle.Text = "()";
      this.bModeCircle.UseVisualStyleBackColor = false;
      this.bModeCircle.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bBlue
      // 
      this.bBlue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bBlue.BackColor = System.Drawing.Color.Blue;
      this.bBlue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bBlue.Location = new System.Drawing.Point(271, 48);
      this.bBlue.Name = "bBlue";
      this.bBlue.Size = new System.Drawing.Size(20, 20);
      this.bBlue.TabIndex = 61;
      this.bBlue.Tag = "5";
      this.bBlue.UseVisualStyleBackColor = false;
      this.bBlue.Click += new System.EventHandler(this.Color_Click);
      this.bBlue.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button8
      // 
      this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
      this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button8.Location = new System.Drawing.Point(292, 48);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(20, 20);
      this.button8.TabIndex = 59;
      this.button8.Tag = "";
      this.button8.UseVisualStyleBackColor = false;
      this.button8.Click += new System.EventHandler(this.Color_Click);
      this.button8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button7
      // 
      this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
      this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button7.Location = new System.Drawing.Point(250, 48);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(20, 20);
      this.button7.TabIndex = 58;
      this.button7.Tag = "";
      this.button7.UseVisualStyleBackColor = false;
      this.button7.Click += new System.EventHandler(this.Color_Click);
      this.button7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button5
      // 
      this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(128)))));
      this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button5.Location = new System.Drawing.Point(82, 48);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(20, 20);
      this.button5.TabIndex = 57;
      this.button5.Tag = "";
      this.button5.UseVisualStyleBackColor = false;
      this.button5.Click += new System.EventHandler(this.Color_Click);
      this.button5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button4
      // 
      this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
      this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button4.Location = new System.Drawing.Point(124, 48);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(20, 20);
      this.button4.TabIndex = 56;
      this.button4.Tag = "";
      this.button4.UseVisualStyleBackColor = false;
      this.button4.Click += new System.EventHandler(this.Color_Click);
      this.button4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button6
      // 
      this.button6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button6.Location = new System.Drawing.Point(208, 48);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(20, 20);
      this.button6.TabIndex = 60;
      this.button6.Tag = "";
      this.button6.UseVisualStyleBackColor = false;
      this.button6.Click += new System.EventHandler(this.Color_Click);
      this.button6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr1
      // 
      this.bColorGr1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
      this.bColorGr1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr1.Location = new System.Drawing.Point(124, 69);
      this.bColorGr1.Name = "bColorGr1";
      this.bColorGr1.Size = new System.Drawing.Size(20, 20);
      this.bColorGr1.TabIndex = 55;
      this.bColorGr1.Tag = "";
      this.bColorGr1.UseVisualStyleBackColor = false;
      this.bColorGr1.Click += new System.EventHandler(this.Color_Click);
      this.bColorGr1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr3
      // 
      this.bColorGr3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.bColorGr3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr3.Location = new System.Drawing.Point(166, 69);
      this.bColorGr3.Name = "bColorGr3";
      this.bColorGr3.Size = new System.Drawing.Size(20, 20);
      this.bColorGr3.TabIndex = 54;
      this.bColorGr3.Tag = "";
      this.bColorGr3.UseVisualStyleBackColor = false;
      this.bColorGr3.Click += new System.EventHandler(this.Color_Click);
      this.bColorGr3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr2
      // 
      this.bColorGr2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
      this.bColorGr2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr2.Location = new System.Drawing.Point(145, 69);
      this.bColorGr2.Name = "bColorGr2";
      this.bColorGr2.Size = new System.Drawing.Size(20, 20);
      this.bColorGr2.TabIndex = 53;
      this.bColorGr2.Tag = "";
      this.bColorGr2.UseVisualStyleBackColor = false;
      this.bColorGr2.Click += new System.EventHandler(this.Color_Click);
      this.bColorGr2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bGY
      // 
      this.bGY.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bGY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(0)))));
      this.bGY.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bGY.Location = new System.Drawing.Point(166, 48);
      this.bGY.Name = "bGY";
      this.bGY.Size = new System.Drawing.Size(20, 20);
      this.bGY.TabIndex = 52;
      this.bGY.Tag = "";
      this.bGY.UseVisualStyleBackColor = false;
      this.bGY.Click += new System.EventHandler(this.Color_Click);
      this.bGY.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bGreen
      // 
      this.bGreen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bGreen.BackColor = System.Drawing.Color.Lime;
      this.bGreen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bGreen.Location = new System.Drawing.Point(187, 48);
      this.bGreen.Name = "bGreen";
      this.bGreen.Size = new System.Drawing.Size(20, 20);
      this.bGreen.TabIndex = 51;
      this.bGreen.Tag = "3";
      this.bGreen.UseVisualStyleBackColor = false;
      this.bGreen.Click += new System.EventHandler(this.Color_Click);
      this.bGreen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bRed
      // 
      this.bRed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bRed.BackColor = System.Drawing.Color.Red;
      this.bRed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bRed.Location = new System.Drawing.Point(103, 48);
      this.bRed.Name = "bRed";
      this.bRed.Size = new System.Drawing.Size(20, 20);
      this.bRed.TabIndex = 50;
      this.bRed.Tag = "1";
      this.bRed.UseVisualStyleBackColor = false;
      this.bRed.Click += new System.EventHandler(this.Color_Click);
      this.bRed.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bColorGr7
      // 
      this.bColorGr7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bColorGr7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
      this.bColorGr7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bColorGr7.Location = new System.Drawing.Point(250, 69);
      this.bColorGr7.Name = "bColorGr7";
      this.bColorGr7.Size = new System.Drawing.Size(20, 20);
      this.bColorGr7.TabIndex = 49;
      this.bColorGr7.Tag = "8";
      this.bColorGr7.UseVisualStyleBackColor = false;
      this.bColorGr7.Click += new System.EventHandler(this.Color_Click);
      this.bColorGr7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bYellow
      // 
      this.bYellow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bYellow.BackColor = System.Drawing.Color.Yellow;
      this.bYellow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bYellow.Location = new System.Drawing.Point(145, 48);
      this.bYellow.Name = "bYellow";
      this.bYellow.Size = new System.Drawing.Size(20, 20);
      this.bYellow.TabIndex = 46;
      this.bYellow.Tag = "2";
      this.bYellow.UseVisualStyleBackColor = false;
      this.bYellow.Click += new System.EventHandler(this.Color_Click);
      this.bYellow.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // button1
      // 
      this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button1.BackColor = System.Drawing.Color.Magenta;
      this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.button1.Location = new System.Drawing.Point(313, 48);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(20, 20);
      this.button1.TabIndex = 48;
      this.button1.Tag = "6";
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new System.EventHandler(this.Color_Click);
      this.button1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bCyan
      // 
      this.bCyan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCyan.BackColor = System.Drawing.Color.Cyan;
      this.bCyan.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bCyan.Location = new System.Drawing.Point(229, 48);
      this.bCyan.Name = "bCyan";
      this.bCyan.Size = new System.Drawing.Size(20, 20);
      this.bCyan.TabIndex = 47;
      this.bCyan.Tag = "4";
      this.bCyan.UseVisualStyleBackColor = false;
      this.bCyan.Click += new System.EventHandler(this.Color_Click);
      this.bCyan.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // bWhite
      // 
      this.bWhite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bWhite.BackColor = System.Drawing.Color.White;
      this.bWhite.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bWhite.Location = new System.Drawing.Point(82, 69);
      this.bWhite.Name = "bWhite";
      this.bWhite.Size = new System.Drawing.Size(20, 20);
      this.bWhite.TabIndex = 45;
      this.bWhite.Tag = "7";
      this.bWhite.UseVisualStyleBackColor = false;
      this.bWhite.Click += new System.EventHandler(this.Color_Click);
      this.bWhite.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Color_MouseDown);
      // 
      // tp1
      // 
      this.tp1.BackColor = System.Drawing.SystemColors.Control;
      this.tp1.Controls.Add(this.bCRemove);
      this.tp1.Controls.Add(this.BOutline);
      this.tp1.Controls.Add(this.chImpandBlack);
      this.tp1.Controls.Add(this.ImpandB);
      this.tp1.Controls.Add(this.ScreenB);
      this.tp1.Controls.Add(this.RedoB);
      this.tp1.Controls.Add(this.FillNoBlack);
      this.tp1.Controls.Add(this.UndoB);
      this.tp1.Controls.Add(this.X8);
      this.tp1.Controls.Add(this.cbFill);
      this.tp1.Controls.Add(this.ExpandB);
      this.tp1.Controls.Add(this.ExpandWhite);
      this.tp1.Controls.Add(this.ExpandWOnly);
      this.tp1.Controls.Add(this.ExpandDiffB);
      this.tp1.Controls.Add(this.label2);
      this.tp1.Controls.Add(this.label3);
      this.tp1.Controls.Add(this.lFill);
      this.tp1.Controls.Add(this.Fill2Black);
      this.tp1.Controls.Add(this.FillD8);
      this.tp1.Location = new System.Drawing.Point(4, 22);
      this.tp1.Name = "tp1";
      this.tp1.Padding = new System.Windows.Forms.Padding(3);
      this.tp1.Size = new System.Drawing.Size(445, 170);
      this.tp1.TabIndex = 0;
      this.tp1.Text = "Fill";
      // 
      // tp3
      // 
      this.tp3.BackColor = System.Drawing.SystemColors.Control;
      this.tp3.Controls.Add(this.tbDash);
      this.tp3.Controls.Add(this.lDash);
      this.tp3.Controls.Add(this.chRadiusFlat);
      this.tp3.Controls.Add(this.lRadius);
      this.tp3.Controls.Add(this.dArrrowRadius);
      this.tp3.Controls.Add(this.dArrowWidth);
      this.tp3.Controls.Add(this.dArrowLen);
      this.tp3.Controls.Add(this.lArrow);
      this.tp3.Controls.Add(this.chSnap);
      this.tp3.Controls.Add(this.Snap);
      this.tp3.Controls.Add(this.cbRepeatMode);
      this.tp3.Controls.Add(this.RepeatCenter);
      this.tp3.Controls.Add(this.RepeatCount);
      this.tp3.Controls.Add(this.lRepeat);
      this.tp3.Controls.Add(this.RepeatOn);
      this.tp3.Controls.Add(this.RepeatX);
      this.tp3.Controls.Add(this.RepeatY);
      this.tp3.Controls.Add(this.label1);
      this.tp3.Controls.Add(this.cbBrush);
      this.tp3.Controls.Add(this.cbShape);
      this.tp3.Controls.Add(this.DrawWOnly);
      this.tp3.Controls.Add(this.lShape);
      this.tp3.Controls.Add(this.ShapeAdjust);
      this.tp3.Controls.Add(this.ShapeMirrorY);
      this.tp3.Controls.Add(this.ShapeMirrorX);
      this.tp3.Controls.Add(this.DrawFilled);
      this.tp3.Controls.Add(this.DrawOrto);
      this.tp3.Controls.Add(this.DrawBlack);
      this.tp3.Controls.Add(this.DrawCenter);
      this.tp3.Controls.Add(this.lDraw);
      this.tp3.Location = new System.Drawing.Point(4, 22);
      this.tp3.Name = "tp3";
      this.tp3.Size = new System.Drawing.Size(445, 170);
      this.tp3.TabIndex = 2;
      this.tp3.Text = "Draw";
      // 
      // tbDash
      // 
      this.tbDash.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tbDash.Location = new System.Drawing.Point(345, 105);
      this.tbDash.Name = "tbDash";
      this.tbDash.Size = new System.Drawing.Size(91, 20);
      this.tbDash.TabIndex = 95;
      this.tbDash.TextChanged += new System.EventHandler(this.tbDash_TextChanged);
      // 
      // lDash
      // 
      this.lDash.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lDash.AutoSize = true;
      this.lDash.Location = new System.Drawing.Point(304, 108);
      this.lDash.Name = "lDash";
      this.lDash.Size = new System.Drawing.Size(32, 13);
      this.lDash.TabIndex = 94;
      this.lDash.Text = "Dash";
      // 
      // chRadiusFlat
      // 
      this.chRadiusFlat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chRadiusFlat.AutoSize = true;
      this.chRadiusFlat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chRadiusFlat.Location = new System.Drawing.Point(389, 143);
      this.chRadiusFlat.Name = "chRadiusFlat";
      this.chRadiusFlat.Size = new System.Drawing.Size(43, 17);
      this.chRadiusFlat.TabIndex = 93;
      this.chRadiusFlat.Text = "Flat";
      this.chRadiusFlat.UseVisualStyleBackColor = true;
      // 
      // lRadius
      // 
      this.lRadius.AutoSize = true;
      this.lRadius.Location = new System.Drawing.Point(309, 144);
      this.lRadius.Name = "lRadius";
      this.lRadius.Size = new System.Drawing.Size(40, 13);
      this.lRadius.TabIndex = 77;
      this.lRadius.Text = "Radius";
      // 
      // dArrrowRadius
      // 
      this.dArrrowRadius.Location = new System.Drawing.Point(353, 141);
      this.dArrrowRadius.Name = "dArrrowRadius";
      this.dArrrowRadius.Size = new System.Drawing.Size(30, 20);
      this.dArrrowRadius.TabIndex = 76;
      this.dArrrowRadius.Text = "15";
      // 
      // dArrowWidth
      // 
      this.dArrowWidth.Location = new System.Drawing.Point(274, 141);
      this.dArrowWidth.Name = "dArrowWidth";
      this.dArrowWidth.Size = new System.Drawing.Size(30, 20);
      this.dArrowWidth.TabIndex = 75;
      this.dArrowWidth.Text = "20";
      // 
      // dArrowLen
      // 
      this.dArrowLen.Location = new System.Drawing.Point(238, 141);
      this.dArrowLen.Name = "dArrowLen";
      this.dArrowLen.Size = new System.Drawing.Size(30, 20);
      this.dArrowLen.TabIndex = 74;
      this.dArrowLen.Text = "30";
      // 
      // lArrow
      // 
      this.lArrow.AutoSize = true;
      this.lArrow.Location = new System.Drawing.Point(200, 144);
      this.lArrow.Name = "lArrow";
      this.lArrow.Size = new System.Drawing.Size(34, 13);
      this.lArrow.TabIndex = 73;
      this.lArrow.Text = "Arrow";
      // 
      // cbRepeatMode
      // 
      this.cbRepeatMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbRepeatMode.FormattingEnabled = true;
      this.cbRepeatMode.Items.AddRange(new object[] {
            "X",
            "Y",
            "XY",
            "Mirror8",
            "Rotate",
            "Rotate+Mirror",
            "Selection"});
      this.cbRepeatMode.Location = new System.Drawing.Point(118, 19);
      this.cbRepeatMode.Name = "cbRepeatMode";
      this.cbRepeatMode.Size = new System.Drawing.Size(88, 21);
      this.cbRepeatMode.TabIndex = 65;
      // 
      // RepeatCenter
      // 
      this.RepeatCenter.AutoSize = true;
      this.RepeatCenter.Location = new System.Drawing.Point(244, 21);
      this.RepeatCenter.Name = "RepeatCenter";
      this.RepeatCenter.Size = new System.Drawing.Size(57, 17);
      this.RepeatCenter.TabIndex = 62;
      this.RepeatCenter.Text = "Center";
      this.RepeatCenter.UseVisualStyleBackColor = true;
      // 
      // RepeatCount
      // 
      this.RepeatCount.Location = new System.Drawing.Point(212, 19);
      this.RepeatCount.Name = "RepeatCount";
      this.RepeatCount.Size = new System.Drawing.Size(26, 20);
      this.RepeatCount.TabIndex = 63;
      this.RepeatCount.Text = "6";
      // 
      // lRepeat
      // 
      this.lRepeat.AutoSize = true;
      this.lRepeat.Location = new System.Drawing.Point(23, 22);
      this.lRepeat.Name = "lRepeat";
      this.lRepeat.Size = new System.Drawing.Size(71, 13);
      this.lRepeat.TabIndex = 64;
      this.lRepeat.Text = "Repeater (W)";
      // 
      // RepeatOn
      // 
      this.RepeatOn.AutoSize = true;
      this.RepeatOn.Location = new System.Drawing.Point(100, 25);
      this.RepeatOn.Name = "RepeatOn";
      this.RepeatOn.Size = new System.Drawing.Size(15, 14);
      this.RepeatOn.TabIndex = 66;
      this.RepeatOn.UseVisualStyleBackColor = true;
      // 
      // RepeatX
      // 
      this.RepeatX.Location = new System.Drawing.Point(307, 19);
      this.RepeatX.Name = "RepeatX";
      this.RepeatX.Size = new System.Drawing.Size(40, 20);
      this.RepeatX.TabIndex = 67;
      this.RepeatX.Text = "0";
      // 
      // RepeatY
      // 
      this.RepeatY.Location = new System.Drawing.Point(353, 20);
      this.RepeatY.Name = "RepeatY";
      this.RepeatY.Size = new System.Drawing.Size(40, 20);
      this.RepeatY.TabIndex = 68;
      this.RepeatY.Text = "0";
      // 
      // label1
      // 
      this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label1.Location = new System.Drawing.Point(11, 43);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(400, 2);
      this.label1.TabIndex = 69;
      // 
      // cbBrush
      // 
      this.cbBrush.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbBrush.FormattingEnabled = true;
      this.cbBrush.Location = new System.Drawing.Point(53, 61);
      this.cbBrush.Name = "cbBrush";
      this.cbBrush.Size = new System.Drawing.Size(81, 21);
      this.cbBrush.TabIndex = 61;
      this.cbBrush.SelectedIndexChanged += new System.EventHandler(this.cbBrush_SelectedIndexChanged);
      // 
      // cbShape
      // 
      this.cbShape.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cbShape.FormattingEnabled = true;
      this.cbShape.Items.AddRange(new object[] {
            "Rectangle",
            "Circle",
            "Start",
            "Octagon",
            "Triangle",
            "Arrow",
            ""});
      this.cbShape.Location = new System.Drawing.Point(64, 87);
      this.cbShape.Name = "cbShape";
      this.cbShape.Size = new System.Drawing.Size(88, 21);
      this.cbShape.TabIndex = 60;
      this.cbShape.SelectedIndexChanged += new System.EventHandler(this.cbShape_SelectedIndexChanged);
      // 
      // lShape
      // 
      this.lShape.AutoSize = true;
      this.lShape.Location = new System.Drawing.Point(21, 91);
      this.lShape.Name = "lShape";
      this.lShape.Size = new System.Drawing.Size(38, 13);
      this.lShape.TabIndex = 58;
      this.lShape.Text = "Shape";
      // 
      // ShapeAdjust
      // 
      this.ShapeAdjust.AutoSize = true;
      this.ShapeAdjust.Location = new System.Drawing.Point(226, 91);
      this.ShapeAdjust.Name = "ShapeAdjust";
      this.ShapeAdjust.Size = new System.Drawing.Size(55, 17);
      this.ShapeAdjust.TabIndex = 57;
      this.ShapeAdjust.Text = "Adjust";
      this.ShapeAdjust.UseVisualStyleBackColor = true;
      // 
      // ShapeMirrorY
      // 
      this.ShapeMirrorY.AutoSize = true;
      this.ShapeMirrorY.Location = new System.Drawing.Point(194, 91);
      this.ShapeMirrorY.Name = "ShapeMirrorY";
      this.ShapeMirrorY.Size = new System.Drawing.Size(35, 17);
      this.ShapeMirrorY.TabIndex = 56;
      this.ShapeMirrorY.Text = "|Y";
      this.ShapeMirrorY.UseVisualStyleBackColor = true;
      // 
      // ShapeMirrorX
      // 
      this.ShapeMirrorX.AutoSize = true;
      this.ShapeMirrorX.Location = new System.Drawing.Point(158, 91);
      this.ShapeMirrorX.Name = "ShapeMirrorX";
      this.ShapeMirrorX.Size = new System.Drawing.Size(35, 17);
      this.ShapeMirrorX.TabIndex = 55;
      this.ShapeMirrorX.Text = "|X";
      this.ShapeMirrorX.UseVisualStyleBackColor = true;
      // 
      // DrawFilled
      // 
      this.DrawFilled.AutoSize = true;
      this.DrawFilled.Location = new System.Drawing.Point(287, 63);
      this.DrawFilled.Name = "DrawFilled";
      this.DrawFilled.Size = new System.Drawing.Size(50, 17);
      this.DrawFilled.TabIndex = 54;
      this.DrawFilled.Text = "Filled";
      this.DrawFilled.UseVisualStyleBackColor = true;
      // 
      // DrawOrto
      // 
      this.DrawOrto.AutoSize = true;
      this.DrawOrto.Location = new System.Drawing.Point(247, 63);
      this.DrawOrto.Name = "DrawOrto";
      this.DrawOrto.Size = new System.Drawing.Size(46, 17);
      this.DrawOrto.TabIndex = 53;
      this.DrawOrto.Text = "Orto";
      this.DrawOrto.UseVisualStyleBackColor = true;
      // 
      // DrawBlack
      // 
      this.DrawBlack.AutoSize = true;
      this.DrawBlack.Checked = true;
      this.DrawBlack.CheckState = System.Windows.Forms.CheckState.Checked;
      this.DrawBlack.Location = new System.Drawing.Point(140, 63);
      this.DrawBlack.Name = "DrawBlack";
      this.DrawBlack.Size = new System.Drawing.Size(53, 17);
      this.DrawBlack.TabIndex = 52;
      this.DrawBlack.Text = "Black";
      this.DrawBlack.UseVisualStyleBackColor = true;
      // 
      // DrawCenter
      // 
      this.DrawCenter.AutoSize = true;
      this.DrawCenter.Location = new System.Drawing.Point(193, 63);
      this.DrawCenter.Name = "DrawCenter";
      this.DrawCenter.Size = new System.Drawing.Size(57, 17);
      this.DrawCenter.TabIndex = 51;
      this.DrawCenter.Text = "Center";
      this.DrawCenter.UseVisualStyleBackColor = true;
      // 
      // lDraw
      // 
      this.lDraw.AutoSize = true;
      this.lDraw.Location = new System.Drawing.Point(21, 64);
      this.lDraw.Name = "lDraw";
      this.lDraw.Size = new System.Drawing.Size(32, 13);
      this.lDraw.TabIndex = 50;
      this.lDraw.Text = "Draw";
      // 
      // tp2
      // 
      this.tp2.BackColor = System.Drawing.SystemColors.Control;
      this.tp2.Controls.Add(this.rbPasteFilter);
      this.tp2.Controls.Add(this.gPasteDiff);
      this.tp2.Controls.Add(this.lMixLevel);
      this.tp2.Controls.Add(this.MixLevel);
      this.tp2.Controls.Add(this.pasteMix);
      this.tp2.Controls.Add(this.pasteExtend);
      this.tp2.Controls.Add(this.pasteRepeat);
      this.tp2.Controls.Add(this.pasteTRX);
      this.tp2.Controls.Add(this.pasteTrans);
      this.tp2.Controls.Add(this.pasteFiles);
      this.tp2.Controls.Add(this.pasteQuad);
      this.tp2.Location = new System.Drawing.Point(4, 22);
      this.tp2.Name = "tp2";
      this.tp2.Padding = new System.Windows.Forms.Padding(3);
      this.tp2.Size = new System.Drawing.Size(445, 170);
      this.tp2.TabIndex = 1;
      this.tp2.Text = "Paste";
      // 
      // rbPasteFilter
      // 
      this.rbPasteFilter.Controls.Add(this.rbFilterAndNotBlack);
      this.rbPasteFilter.Controls.Add(this.rbFilterColor2);
      this.rbPasteFilter.Controls.Add(this.rbFilterWhite);
      this.rbPasteFilter.Controls.Add(this.rbFilterOff);
      this.rbPasteFilter.Controls.Add(this.rbFilterNotColor2);
      this.rbPasteFilter.Location = new System.Drawing.Point(0, 33);
      this.rbPasteFilter.Name = "rbPasteFilter";
      this.rbPasteFilter.Size = new System.Drawing.Size(442, 23);
      this.rbPasteFilter.TabIndex = 81;
      // 
      // gPasteDiff
      // 
      this.gPasteDiff.Controls.Add(this.rbDiffBW);
      this.gPasteDiff.Controls.Add(this.rbDiffDiff);
      this.gPasteDiff.Controls.Add(this.rbDiffRed);
      this.gPasteDiff.Controls.Add(this.rbDiffXor);
      this.gPasteDiff.Controls.Add(this.rbDiffOff);
      this.gPasteDiff.Controls.Add(this.rbDiffMax);
      this.gPasteDiff.Controls.Add(this.rbDiffMin);
      this.gPasteDiff.Controls.Add(this.rbDiffAvg);
      this.gPasteDiff.Location = new System.Drawing.Point(3, 4);
      this.gPasteDiff.Name = "gPasteDiff";
      this.gPasteDiff.Size = new System.Drawing.Size(442, 23);
      this.gPasteDiff.TabIndex = 80;
      // 
      // rbDiffBW
      // 
      this.rbDiffBW.AutoSize = true;
      this.rbDiffBW.Location = new System.Drawing.Point(194, 3);
      this.rbDiffBW.Name = "rbDiffBW";
      this.rbDiffBW.Size = new System.Drawing.Size(43, 17);
      this.rbDiffBW.TabIndex = 40;
      this.rbDiffBW.Text = "BW";
      this.rbDiffBW.UseVisualStyleBackColor = true;
      this.rbDiffBW.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffDiff
      // 
      this.rbDiffDiff.AutoSize = true;
      this.rbDiffDiff.Location = new System.Drawing.Point(93, 3);
      this.rbDiffDiff.Name = "rbDiffDiff";
      this.rbDiffDiff.Size = new System.Drawing.Size(41, 17);
      this.rbDiffDiff.TabIndex = 38;
      this.rbDiffDiff.Text = "Diff";
      this.rbDiffDiff.UseVisualStyleBackColor = true;
      this.rbDiffDiff.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffRed
      // 
      this.rbDiffRed.AutoSize = true;
      this.rbDiffRed.Location = new System.Drawing.Point(141, 2);
      this.rbDiffRed.Name = "rbDiffRed";
      this.rbDiffRed.Size = new System.Drawing.Size(45, 17);
      this.rbDiffRed.TabIndex = 39;
      this.rbDiffRed.Text = "Red";
      this.rbDiffRed.UseVisualStyleBackColor = true;
      this.rbDiffRed.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffXor
      // 
      this.rbDiffXor.AutoSize = true;
      this.rbDiffXor.Location = new System.Drawing.Point(43, 3);
      this.rbDiffXor.Name = "rbDiffXor";
      this.rbDiffXor.Size = new System.Drawing.Size(48, 17);
      this.rbDiffXor.TabIndex = 37;
      this.rbDiffXor.Tag = "";
      this.rbDiffXor.Text = "XOR";
      this.rbDiffXor.UseVisualStyleBackColor = true;
      this.rbDiffXor.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffOff
      // 
      this.rbDiffOff.AutoSize = true;
      this.rbDiffOff.Checked = true;
      this.rbDiffOff.Location = new System.Drawing.Point(3, 3);
      this.rbDiffOff.Name = "rbDiffOff";
      this.rbDiffOff.Size = new System.Drawing.Size(39, 17);
      this.rbDiffOff.TabIndex = 36;
      this.rbDiffOff.TabStop = true;
      this.rbDiffOff.Tag = "";
      this.rbDiffOff.Text = "Off";
      this.rbDiffOff.UseVisualStyleBackColor = true;
      this.rbDiffOff.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffMax
      // 
      this.rbDiffMax.AutoSize = true;
      this.rbDiffMax.Location = new System.Drawing.Point(339, 3);
      this.rbDiffMax.Name = "rbDiffMax";
      this.rbDiffMax.Size = new System.Drawing.Size(45, 17);
      this.rbDiffMax.TabIndex = 35;
      this.rbDiffMax.Text = "Max";
      this.rbDiffMax.UseVisualStyleBackColor = true;
      this.rbDiffMax.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffMin
      // 
      this.rbDiffMin.AutoSize = true;
      this.rbDiffMin.Location = new System.Drawing.Point(249, 3);
      this.rbDiffMin.Name = "rbDiffMin";
      this.rbDiffMin.Size = new System.Drawing.Size(42, 17);
      this.rbDiffMin.TabIndex = 33;
      this.rbDiffMin.Text = "Min";
      this.rbDiffMin.UseVisualStyleBackColor = true;
      this.rbDiffMin.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // rbDiffAvg
      // 
      this.rbDiffAvg.AutoSize = true;
      this.rbDiffAvg.Location = new System.Drawing.Point(295, 3);
      this.rbDiffAvg.Name = "rbDiffAvg";
      this.rbDiffAvg.Size = new System.Drawing.Size(44, 17);
      this.rbDiffAvg.TabIndex = 34;
      this.rbDiffAvg.Text = "Avg";
      this.rbDiffAvg.UseVisualStyleBackColor = true;
      this.rbDiffAvg.CheckedChanged += new System.EventHandler(this.pasteDiff_CheckedChanged);
      // 
      // lMixLevel
      // 
      this.lMixLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lMixLevel.AutoSize = true;
      this.lMixLevel.Location = new System.Drawing.Point(55, 85);
      this.lMixLevel.Name = "lMixLevel";
      this.lMixLevel.Size = new System.Drawing.Size(33, 13);
      this.lMixLevel.TabIndex = 79;
      this.lMixLevel.Text = "Level";
      this.lMixLevel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lIntText_MouseDown);
      // 
      // MixLevel
      // 
      this.MixLevel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.MixLevel.Location = new System.Drawing.Point(94, 82);
      this.MixLevel.Name = "MixLevel";
      this.MixLevel.Size = new System.Drawing.Size(29, 20);
      this.MixLevel.TabIndex = 78;
      this.MixLevel.Text = "25";
      // 
      // pasteExtend
      // 
      this.pasteExtend.AutoSize = true;
      this.pasteExtend.Location = new System.Drawing.Point(281, 109);
      this.pasteExtend.Name = "pasteExtend";
      this.pasteExtend.Size = new System.Drawing.Size(59, 17);
      this.pasteExtend.TabIndex = 58;
      this.pasteExtend.Text = "Extend";
      this.pasteExtend.UseVisualStyleBackColor = true;
      // 
      // pasteRepeat
      // 
      this.pasteRepeat.AutoSize = true;
      this.pasteRepeat.Location = new System.Drawing.Point(7, 109);
      this.pasteRepeat.Name = "pasteRepeat";
      this.pasteRepeat.Size = new System.Drawing.Size(61, 17);
      this.pasteRepeat.TabIndex = 57;
      this.pasteRepeat.Text = "Repeat";
      this.pasteRepeat.UseVisualStyleBackColor = true;
      // 
      // pasteQuad
      // 
      this.pasteQuad.AutoSize = true;
      this.pasteQuad.Location = new System.Drawing.Point(74, 109);
      this.pasteQuad.Name = "pasteQuad";
      this.pasteQuad.Size = new System.Drawing.Size(52, 17);
      this.pasteQuad.TabIndex = 52;
      this.pasteQuad.Text = "Quad";
      this.pasteQuad.UseVisualStyleBackColor = true;
      // 
      // tp4
      // 
      this.tp4.BackColor = System.Drawing.SystemColors.Control;
      this.tp4.Controls.Add(this.whiteDust);
      this.tp4.Controls.Add(this.blackDust);
      this.tp4.Controls.Add(this.dustLevel);
      this.tp4.Controls.Add(this.bRemoveDust);
      this.tp4.Controls.Add(this.bCReplace);
      this.tp4.Controls.Add(this.chBrightBW);
      this.tp4.Controls.Add(this.panel1);
      this.tp4.Controls.Add(this.chRemDotBlack);
      this.tp4.Controls.Add(this.chRemDotWhite);
      this.tp4.Controls.Add(this.bRemoveDots);
      this.tp4.Controls.Add(this.borderLevel);
      this.tp4.Controls.Add(this.bBorder);
      this.tp4.Controls.Add(this.cbContrast);
      this.tp4.Controls.Add(this.NormColorB);
      this.tp4.Controls.Add(this.darkB);
      this.tp4.Controls.Add(this.brightB);
      this.tp4.Controls.Add(this.redoB2);
      this.tp4.Controls.Add(this.undoB2);
      this.tp4.Controls.Add(this.bGray);
      this.tp4.Controls.Add(this.Invert);
      this.tp4.Controls.Add(this.cbInvertBW);
      this.tp4.Controls.Add(this.cbInvertIntensity);
      this.tp4.Controls.Add(this.rgb2cmyB);
      this.tp4.Controls.Add(this.rgbshiftB);
      this.tp4.Controls.Add(this.levelsB);
      this.tp4.Controls.Add(this.levelsCount);
      this.tp4.Controls.Add(this.contour);
      this.tp4.Controls.Add(this.BWPanel);
      this.tp4.Controls.Add(this.BW);
      this.tp4.Controls.Add(this.BWLevel);
      this.tp4.Location = new System.Drawing.Point(4, 22);
      this.tp4.Name = "tp4";
      this.tp4.Size = new System.Drawing.Size(445, 170);
      this.tp4.TabIndex = 3;
      this.tp4.Text = "Filter";
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.rRemDot3);
      this.panel1.Controls.Add(this.rRemDot8);
      this.panel1.Controls.Add(this.rRemDot4);
      this.panel1.Location = new System.Drawing.Point(190, 75);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(117, 23);
      this.panel1.TabIndex = 64;
      // 
      // borderLevel
      // 
      this.borderLevel.Location = new System.Drawing.Point(326, 21);
      this.borderLevel.Name = "borderLevel";
      this.borderLevel.Size = new System.Drawing.Size(22, 20);
      this.borderLevel.TabIndex = 75;
      this.borderLevel.Tag = "";
      this.borderLevel.Text = "24";
      // 
      // darkB
      // 
      this.darkB.Location = new System.Drawing.Point(90, 122);
      this.darkB.Name = "darkB";
      this.darkB.Size = new System.Drawing.Size(53, 23);
      this.darkB.TabIndex = 71;
      this.darkB.Tag = "dark";
      this.darkB.Text = "Dark";
      this.darkB.UseVisualStyleBackColor = true;
      this.darkB.Click += new System.EventHandler(this.Cmd);
      // 
      // brightB
      // 
      this.brightB.Location = new System.Drawing.Point(20, 122);
      this.brightB.Name = "brightB";
      this.brightB.Size = new System.Drawing.Size(53, 23);
      this.brightB.TabIndex = 70;
      this.brightB.Tag = "bright";
      this.brightB.Text = "Bright";
      this.brightB.UseVisualStyleBackColor = true;
      this.brightB.Click += new System.EventHandler(this.Cmd);
      // 
      // redoB2
      // 
      this.redoB2.Location = new System.Drawing.Point(380, 138);
      this.redoB2.Name = "redoB2";
      this.redoB2.Size = new System.Drawing.Size(53, 23);
      this.redoB2.TabIndex = 69;
      this.redoB2.Tag = "redo";
      this.redoB2.Text = "Redo";
      this.redoB2.UseVisualStyleBackColor = true;
      this.redoB2.Click += new System.EventHandler(this.Cmd);
      // 
      // undoB2
      // 
      this.undoB2.Location = new System.Drawing.Point(321, 138);
      this.undoB2.Name = "undoB2";
      this.undoB2.Size = new System.Drawing.Size(53, 23);
      this.undoB2.TabIndex = 68;
      this.undoB2.Tag = "undo";
      this.undoB2.Text = "Undo";
      this.undoB2.UseVisualStyleBackColor = true;
      this.undoB2.Click += new System.EventHandler(this.Cmd);
      // 
      // levelsCount
      // 
      this.levelsCount.Location = new System.Drawing.Point(269, 48);
      this.levelsCount.Name = "levelsCount";
      this.levelsCount.Size = new System.Drawing.Size(22, 20);
      this.levelsCount.TabIndex = 59;
      this.levelsCount.Tag = "";
      this.levelsCount.Text = "16";
      // 
      // BWPanel
      // 
      this.BWPanel.Controls.Add(this.BWMax);
      this.BWPanel.Controls.Add(this.BWMin);
      this.BWPanel.Controls.Add(this.BWAvg);
      this.BWPanel.Location = new System.Drawing.Point(28, 21);
      this.BWPanel.Name = "BWPanel";
      this.BWPanel.Size = new System.Drawing.Size(136, 23);
      this.BWPanel.TabIndex = 63;
      // 
      // BWMax
      // 
      this.BWMax.AutoSize = true;
      this.BWMax.Location = new System.Drawing.Point(89, 3);
      this.BWMax.Name = "BWMax";
      this.BWMax.Size = new System.Drawing.Size(44, 17);
      this.BWMax.TabIndex = 35;
      this.BWMax.Text = "max";
      this.BWMax.UseVisualStyleBackColor = true;
      // 
      // BWMin
      // 
      this.BWMin.AutoSize = true;
      this.BWMin.Location = new System.Drawing.Point(3, 3);
      this.BWMin.Name = "BWMin";
      this.BWMin.Size = new System.Drawing.Size(41, 17);
      this.BWMin.TabIndex = 33;
      this.BWMin.Text = "min";
      this.BWMin.UseVisualStyleBackColor = true;
      // 
      // BWAvg
      // 
      this.BWAvg.AutoSize = true;
      this.BWAvg.Checked = true;
      this.BWAvg.Location = new System.Drawing.Point(45, 3);
      this.BWAvg.Name = "BWAvg";
      this.BWAvg.Size = new System.Drawing.Size(43, 17);
      this.BWAvg.TabIndex = 34;
      this.BWAvg.TabStop = true;
      this.BWAvg.Text = "avg";
      this.BWAvg.UseVisualStyleBackColor = true;
      // 
      // BWLevel
      // 
      this.BWLevel.Location = new System.Drawing.Point(165, 23);
      this.BWLevel.Name = "BWLevel";
      this.BWLevel.Size = new System.Drawing.Size(31, 20);
      this.BWLevel.TabIndex = 61;
      this.BWLevel.Tag = "";
      this.BWLevel.Text = "128";
      // 
      // tp5
      // 
      this.tp5.BackColor = System.Drawing.SystemColors.Control;
      this.tp5.Controls.Add(this.lPadding);
      this.tp5.Controls.Add(this.tPadding);
      this.tp5.Controls.Add(this.panel3);
      this.tp5.Controls.Add(this.tbTlDash2);
      this.tp5.Controls.Add(this.ltDash);
      this.tp5.Controls.Add(this.tbTLWidth2);
      this.tp5.Controls.Add(this.chLColorFont);
      this.tp5.Controls.Add(this.chTBWAuto);
      this.tp5.Controls.Add(this.chTOpaq);
      this.tp5.Controls.Add(this.chTPasteLine);
      this.tp5.Controls.Add(this.chTLHeader);
      this.tp5.Controls.Add(this.chTLFlat);
      this.tp5.Controls.Add(this.tbTLRound);
      this.tp5.Controls.Add(this.ltlRound);
      this.tp5.Controls.Add(this.ltlWidth);
      this.tp5.Controls.Add(this.blColor);
      this.tp5.Controls.Add(this.btColor);
      this.tp5.Controls.Add(this.FontStrike);
      this.tp5.Controls.Add(this.FontUnder);
      this.tp5.Controls.Add(this.FntDialog);
      this.tp5.Controls.Add(this.TextAlign);
      this.tp5.Controls.Add(this.FontItalic);
      this.tp5.Controls.Add(this.FontBold);
      this.tp5.Controls.Add(this.FontFamily);
      this.tp5.Controls.Add(this.lFamily);
      this.tp5.Controls.Add(this.lFontSize);
      this.tp5.Controls.Add(this.FontSize);
      this.tp5.Controls.Add(this.bText);
      this.tp5.Controls.Add(this.tbText);
      this.tp5.Location = new System.Drawing.Point(4, 22);
      this.tp5.Name = "tp5";
      this.tp5.Size = new System.Drawing.Size(445, 170);
      this.tp5.TabIndex = 4;
      this.tp5.Text = "Text";
      // 
      // lPadding
      // 
      this.lPadding.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lPadding.AutoSize = true;
      this.lPadding.Location = new System.Drawing.Point(237, 128);
      this.lPadding.Name = "lPadding";
      this.lPadding.Size = new System.Drawing.Size(46, 13);
      this.lPadding.TabIndex = 104;
      this.lPadding.Text = "Padding";
      this.lPadding.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LabelMouseDown);
      // 
      // tPadding
      // 
      this.tPadding.Location = new System.Drawing.Point(288, 125);
      this.tPadding.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
      this.tPadding.Name = "tPadding";
      this.tPadding.Size = new System.Drawing.Size(30, 20);
      this.tPadding.TabIndex = 103;
      // 
      // panel3
      // 
      this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.panel3.Controls.Add(this.tsDiamond);
      this.panel3.Controls.Add(this.tsCircle);
      this.panel3.Controls.Add(this.tsBox);
      this.panel3.Location = new System.Drawing.Point(174, 102);
      this.panel3.Name = "panel3";
      this.panel3.Size = new System.Drawing.Size(192, 23);
      this.panel3.TabIndex = 102;
      // 
      // tbTlDash2
      // 
      this.tbTlDash2.Location = new System.Drawing.Point(412, 124);
      this.tbTlDash2.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
      this.tbTlDash2.Name = "tbTlDash2";
      this.tbTlDash2.Size = new System.Drawing.Size(30, 20);
      this.tbTlDash2.TabIndex = 101;
      // 
      // ltDash
      // 
      this.ltDash.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ltDash.AutoSize = true;
      this.ltDash.Location = new System.Drawing.Point(377, 128);
      this.ltDash.Name = "ltDash";
      this.ltDash.Size = new System.Drawing.Size(32, 13);
      this.ltDash.TabIndex = 99;
      this.ltDash.Text = "Dash";
      this.ltDash.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LabelMouseDown);
      // 
      // tbTLWidth2
      // 
      this.tbTLWidth2.Location = new System.Drawing.Point(215, 145);
      this.tbTLWidth2.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
      this.tbTLWidth2.Minimum = new decimal(new int[] {
            9,
            0,
            0,
            -2147483648});
      this.tbTLWidth2.Name = "tbTLWidth2";
      this.tbTLWidth2.Size = new System.Drawing.Size(30, 20);
      this.tbTLWidth2.TabIndex = 98;
      this.tbTLWidth2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
      // 
      // chTOpaq
      // 
      this.chTOpaq.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chTOpaq.AutoSize = true;
      this.chTOpaq.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chTOpaq.Location = new System.Drawing.Point(176, 126);
      this.chTOpaq.Name = "chTOpaq";
      this.chTOpaq.Size = new System.Drawing.Size(52, 17);
      this.chTOpaq.TabIndex = 95;
      this.chTOpaq.Text = "Opaq";
      this.chTOpaq.UseVisualStyleBackColor = true;
      // 
      // chTPasteLine
      // 
      this.chTPasteLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chTPasteLine.AutoSize = true;
      this.chTPasteLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chTPasteLine.Location = new System.Drawing.Point(371, 102);
      this.chTPasteLine.Name = "chTPasteLine";
      this.chTPasteLine.Size = new System.Drawing.Size(72, 17);
      this.chTPasteLine.TabIndex = 94;
      this.chTPasteLine.Text = "Paste line";
      this.chTPasteLine.UseVisualStyleBackColor = true;
      // 
      // chTLHeader
      // 
      this.chTLHeader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chTLHeader.AutoSize = true;
      this.chTLHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chTLHeader.Location = new System.Drawing.Point(322, 78);
      this.chTLHeader.Name = "chTLHeader";
      this.chTLHeader.Size = new System.Drawing.Size(61, 17);
      this.chTLHeader.TabIndex = 93;
      this.chTLHeader.Text = "Header";
      this.chTLHeader.UseVisualStyleBackColor = true;
      // 
      // chTLFlat
      // 
      this.chTLFlat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.chTLFlat.AutoSize = true;
      this.chTLFlat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.chTLFlat.Location = new System.Drawing.Point(321, 127);
      this.chTLFlat.Name = "chTLFlat";
      this.chTLFlat.Size = new System.Drawing.Size(43, 17);
      this.chTLFlat.TabIndex = 92;
      this.chTLFlat.Text = "Flat";
      this.chTLFlat.UseVisualStyleBackColor = true;
      // 
      // tbTLRound
      // 
      this.tbTLRound.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tbTLRound.Location = new System.Drawing.Point(351, 147);
      this.tbTLRound.Name = "tbTLRound";
      this.tbTLRound.Size = new System.Drawing.Size(91, 20);
      this.tbTLRound.TabIndex = 91;
      this.tbTLRound.Text = "10";
      // 
      // ltlRound
      // 
      this.ltlRound.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ltlRound.AutoSize = true;
      this.ltlRound.Location = new System.Drawing.Point(310, 150);
      this.ltlRound.Name = "ltlRound";
      this.ltlRound.Size = new System.Drawing.Size(39, 13);
      this.ltlRound.TabIndex = 90;
      this.ltlRound.Text = "Round";
      // 
      // ltlWidth
      // 
      this.ltlWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.ltlWidth.AutoSize = true;
      this.ltlWidth.Location = new System.Drawing.Point(181, 149);
      this.ltlWidth.Name = "ltlWidth";
      this.ltlWidth.Size = new System.Drawing.Size(35, 13);
      this.ltlWidth.TabIndex = 89;
      this.ltlWidth.Text = "Width";
      this.ltlWidth.MouseDown += new System.Windows.Forms.MouseEventHandler(this.LabelMouseDown);
      // 
      // blColor
      // 
      this.blColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.blColor.BackColor = System.Drawing.Color.Black;
      this.blColor.Location = new System.Drawing.Point(246, 144);
      this.blColor.Name = "blColor";
      this.blColor.Size = new System.Drawing.Size(39, 23);
      this.blColor.TabIndex = 87;
      this.blColor.UseVisualStyleBackColor = false;
      this.blColor.Click += new System.EventHandler(this.btColor_Click);
      // 
      // btColor
      // 
      this.btColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.btColor.BackColor = System.Drawing.Color.Black;
      this.btColor.Location = new System.Drawing.Point(293, 4);
      this.btColor.Name = "btColor";
      this.btColor.Size = new System.Drawing.Size(39, 23);
      this.btColor.TabIndex = 86;
      this.btColor.UseVisualStyleBackColor = false;
      this.btColor.Click += new System.EventHandler(this.btColor_Click);
      // 
      // FontStrike
      // 
      this.FontStrike.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontStrike.AutoSize = true;
      this.FontStrike.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.FontStrike.Location = new System.Drawing.Point(342, 53);
      this.FontStrike.Name = "FontStrike";
      this.FontStrike.Size = new System.Drawing.Size(53, 17);
      this.FontStrike.TabIndex = 85;
      this.FontStrike.Text = "Strike";
      this.FontStrike.UseVisualStyleBackColor = true;
      this.FontStrike.CheckedChanged += new System.EventHandler(this.UpdateFont);
      // 
      // FontUnder
      // 
      this.FontUnder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontUnder.AutoSize = true;
      this.FontUnder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.FontUnder.Location = new System.Drawing.Point(288, 53);
      this.FontUnder.Name = "FontUnder";
      this.FontUnder.Size = new System.Drawing.Size(55, 17);
      this.FontUnder.TabIndex = 84;
      this.FontUnder.Text = "Under";
      this.FontUnder.UseVisualStyleBackColor = true;
      this.FontUnder.CheckedChanged += new System.EventHandler(this.UpdateFont);
      // 
      // TextAlign
      // 
      this.TextAlign.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.TextAlign.Controls.Add(this.taRight);
      this.TextAlign.Controls.Add(this.taCenter);
      this.TextAlign.Controls.Add(this.taLeft);
      this.TextAlign.Location = new System.Drawing.Point(177, 75);
      this.TextAlign.Name = "TextAlign";
      this.TextAlign.Size = new System.Drawing.Size(141, 23);
      this.TextAlign.TabIndex = 82;
      // 
      // taRight
      // 
      this.taRight.AutoSize = true;
      this.taRight.Location = new System.Drawing.Point(92, 3);
      this.taRight.Name = "taRight";
      this.taRight.Size = new System.Drawing.Size(45, 17);
      this.taRight.TabIndex = 35;
      this.taRight.Text = "right";
      this.taRight.UseVisualStyleBackColor = true;
      // 
      // taCenter
      // 
      this.taCenter.AutoSize = true;
      this.taCenter.Checked = true;
      this.taCenter.Location = new System.Drawing.Point(39, 3);
      this.taCenter.Name = "taCenter";
      this.taCenter.Size = new System.Drawing.Size(55, 17);
      this.taCenter.TabIndex = 34;
      this.taCenter.TabStop = true;
      this.taCenter.Text = "center";
      this.taCenter.UseVisualStyleBackColor = true;
      // 
      // taLeft
      // 
      this.taLeft.AutoSize = true;
      this.taLeft.Location = new System.Drawing.Point(3, 3);
      this.taLeft.Name = "taLeft";
      this.taLeft.Size = new System.Drawing.Size(39, 17);
      this.taLeft.TabIndex = 33;
      this.taLeft.Text = "left";
      this.taLeft.UseVisualStyleBackColor = true;
      // 
      // FontItalic
      // 
      this.FontItalic.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontItalic.AutoSize = true;
      this.FontItalic.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.FontItalic.Location = new System.Drawing.Point(240, 53);
      this.FontItalic.Name = "FontItalic";
      this.FontItalic.Size = new System.Drawing.Size(48, 17);
      this.FontItalic.TabIndex = 81;
      this.FontItalic.Text = "Italic";
      this.FontItalic.UseVisualStyleBackColor = true;
      this.FontItalic.CheckedChanged += new System.EventHandler(this.UpdateFont);
      // 
      // FontBold
      // 
      this.FontBold.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontBold.AutoSize = true;
      this.FontBold.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
      this.FontBold.Location = new System.Drawing.Point(186, 53);
      this.FontBold.Name = "FontBold";
      this.FontBold.Size = new System.Drawing.Size(51, 17);
      this.FontBold.TabIndex = 80;
      this.FontBold.Text = "Bold";
      this.FontBold.UseVisualStyleBackColor = true;
      this.FontBold.CheckedChanged += new System.EventHandler(this.UpdateFont);
      // 
      // FontFamily
      // 
      this.FontFamily.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontFamily.Location = new System.Drawing.Point(214, 29);
      this.FontFamily.Name = "FontFamily";
      this.FontFamily.Size = new System.Drawing.Size(228, 20);
      this.FontFamily.TabIndex = 79;
      this.FontFamily.Text = "Arial";
      this.FontFamily.TextAlignChanged += new System.EventHandler(this.UpdateFont);
      // 
      // lFamily
      // 
      this.lFamily.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lFamily.AutoSize = true;
      this.lFamily.Location = new System.Drawing.Point(177, 33);
      this.lFamily.Name = "lFamily";
      this.lFamily.Size = new System.Drawing.Size(36, 13);
      this.lFamily.TabIndex = 78;
      this.lFamily.Text = "Family";
      // 
      // lFontSize
      // 
      this.lFontSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.lFontSize.AutoSize = true;
      this.lFontSize.Location = new System.Drawing.Point(189, 9);
      this.lFontSize.Name = "lFontSize";
      this.lFontSize.Size = new System.Drawing.Size(27, 13);
      this.lFontSize.TabIndex = 77;
      this.lFontSize.Text = "Size";
      this.lFontSize.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lIntText_MouseDown);
      // 
      // FontSize
      // 
      this.FontSize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.FontSize.Location = new System.Drawing.Point(222, 6);
      this.FontSize.Name = "FontSize";
      this.FontSize.Size = new System.Drawing.Size(29, 20);
      this.FontSize.TabIndex = 76;
      this.FontSize.Text = "10";
      this.FontSize.TextChanged += new System.EventHandler(this.UpdateFont);
      // 
      // tbText
      // 
      this.tbText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.tbText.Location = new System.Drawing.Point(3, 3);
      this.tbText.Multiline = true;
      this.tbText.Name = "tbText";
      this.tbText.Size = new System.Drawing.Size(170, 164);
      this.tbText.TabIndex = 62;
      this.tbText.Tag = "";
      // 
      // tp7
      // 
      this.tp7.BackColor = System.Drawing.SystemColors.Control;
      this.tp7.Controls.Add(this.gOrientation);
      this.tp7.Controls.Add(this.gPrintMulti);
      this.tp7.Controls.Add(this.bPrint);
      this.tp7.Controls.Add(this.label5);
      this.tp7.Controls.Add(this.gIconTransp);
      this.tp7.Controls.Add(this.chIconCursor);
      this.tp7.Controls.Add(this.gIconSize);
      this.tp7.Controls.Add(this.label4);
      this.tp7.Controls.Add(this.bSaveIcon);
      this.tp7.Controls.Add(this.tIconHeight);
      this.tp7.Controls.Add(this.tIconWidth);
      this.tp7.Controls.Add(this.lIcon);
      this.tp7.Controls.Add(this.bNew);
      this.tp7.Controls.Add(this.tNewHeight);
      this.tp7.Controls.Add(this.tNewWidth);
      this.tp7.Controls.Add(this.lNew);
      this.tp7.Location = new System.Drawing.Point(4, 22);
      this.tp7.Name = "tp7";
      this.tp7.Size = new System.Drawing.Size(445, 170);
      this.tp7.TabIndex = 6;
      this.tp7.Text = "File";
      // 
      // gIconTransp
      // 
      this.gIconTransp.Controls.Add(this.rIconTrWhite);
      this.gIconTransp.Controls.Add(this.rIconTrNone);
      this.gIconTransp.Controls.Add(this.rIconTrColor2);
      this.gIconTransp.Location = new System.Drawing.Point(252, 112);
      this.gIconTransp.Name = "gIconTransp";
      this.gIconTransp.Size = new System.Drawing.Size(184, 23);
      this.gIconTransp.TabIndex = 87;
      // 
      // gIconSize
      // 
      this.gIconSize.Controls.Add(this.rIcon1to1);
      this.gIconSize.Controls.Add(this.rIconAspect);
      this.gIconSize.Controls.Add(this.rIconExact);
      this.gIconSize.Controls.Add(this.rIconHeight);
      this.gIconSize.Controls.Add(this.rIconWidth);
      this.gIconSize.Location = new System.Drawing.Point(8, 140);
      this.gIconSize.Name = "gIconSize";
      this.gIconSize.Size = new System.Drawing.Size(312, 25);
      this.gIconSize.TabIndex = 85;
      // 
      // label4
      // 
      this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label4.Location = new System.Drawing.Point(22, 33);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(400, 2);
      this.label4.TabIndex = 84;
      // 
      // lIcon
      // 
      this.lIcon.AutoSize = true;
      this.lIcon.Location = new System.Drawing.Point(4, 117);
      this.lIcon.Name = "lIcon";
      this.lIcon.Size = new System.Drawing.Size(28, 13);
      this.lIcon.TabIndex = 80;
      this.lIcon.Text = "Icon";
      // 
      // tNewHeight
      // 
      this.tNewHeight.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tNewHeight.Location = new System.Drawing.Point(105, 8);
      this.tNewHeight.Name = "tNewHeight";
      this.tNewHeight.Size = new System.Drawing.Size(33, 20);
      this.tNewHeight.TabIndex = 78;
      this.tNewHeight.Text = "480";
      // 
      // tNewWidth
      // 
      this.tNewWidth.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.tNewWidth.Location = new System.Drawing.Point(54, 8);
      this.tNewWidth.Name = "tNewWidth";
      this.tNewWidth.Size = new System.Drawing.Size(45, 20);
      this.tNewWidth.TabIndex = 77;
      this.tNewWidth.Text = "640";
      // 
      // lNew
      // 
      this.lNew.AutoSize = true;
      this.lNew.Location = new System.Drawing.Point(19, 11);
      this.lNew.Name = "lNew";
      this.lNew.Size = new System.Drawing.Size(29, 13);
      this.lNew.TabIndex = 75;
      this.lNew.Text = "New";
      // 
      // label5
      // 
      this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.label5.Location = new System.Drawing.Point(18, 102);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(400, 2);
      this.label5.TabIndex = 88;
      // 
      // bPrint
      // 
      this.bPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bPrint.Location = new System.Drawing.Point(216, 39);
      this.bPrint.Name = "bPrint";
      this.bPrint.Size = new System.Drawing.Size(48, 23);
      this.bPrint.TabIndex = 89;
      this.bPrint.Tag = "print";
      this.bPrint.Text = "&Print";
      this.toolTip.SetToolTip(this.bPrint, "Draw text");
      this.bPrint.UseVisualStyleBackColor = true;
      this.bPrint.Click += new System.EventHandler(this.Cmd);
      // 
      // gPrintMulti
      // 
      this.gPrintMulti.Controls.Add(this.rPrint3x1);
      this.gPrintMulti.Controls.Add(this.rPrint3x2);
      this.gPrintMulti.Controls.Add(this.rPrint1x1);
      this.gPrintMulti.Controls.Add(this.rPrint2x2);
      this.gPrintMulti.Controls.Add(this.rPrint2x1);
      this.gPrintMulti.Location = new System.Drawing.Point(21, 68);
      this.gPrintMulti.Name = "gPrintMulti";
      this.gPrintMulti.Size = new System.Drawing.Size(249, 23);
      this.gPrintMulti.TabIndex = 88;
      // 
      // rPrint1x1
      // 
      this.rPrint1x1.AutoSize = true;
      this.rPrint1x1.Checked = true;
      this.rPrint1x1.Location = new System.Drawing.Point(4, 3);
      this.rPrint1x1.Name = "rPrint1x1";
      this.rPrint1x1.Size = new System.Drawing.Size(42, 17);
      this.rPrint1x1.TabIndex = 79;
      this.rPrint1x1.TabStop = true;
      this.rPrint1x1.Tag = "1";
      this.rPrint1x1.Text = "1x1";
      this.toolTip.SetToolTip(this.rPrint1x1, "Print on 1 page");
      this.rPrint1x1.UseVisualStyleBackColor = true;
      // 
      // rPrint2x2
      // 
      this.rPrint2x2.AutoSize = true;
      this.rPrint2x2.Location = new System.Drawing.Point(149, 3);
      this.rPrint2x2.Name = "rPrint2x2";
      this.rPrint2x2.Size = new System.Drawing.Size(42, 17);
      this.rPrint2x2.TabIndex = 81;
      this.rPrint2x2.Tag = "4";
      this.rPrint2x2.Text = "2x2";
      this.toolTip.SetToolTip(this.rPrint2x2, "Print on 2x2 pages");
      this.rPrint2x2.UseVisualStyleBackColor = true;
      // 
      // rPrint2x1
      // 
      this.rPrint2x1.AutoSize = true;
      this.rPrint2x1.Location = new System.Drawing.Point(51, 3);
      this.rPrint2x1.Name = "rPrint2x1";
      this.rPrint2x1.Size = new System.Drawing.Size(42, 17);
      this.rPrint2x1.TabIndex = 80;
      this.rPrint2x1.Tag = "2";
      this.rPrint2x1.Text = "2x1";
      this.toolTip.SetToolTip(this.rPrint2x1, "Print on 2 pages");
      this.rPrint2x1.UseVisualStyleBackColor = true;
      // 
      // rPrint3x2
      // 
      this.rPrint3x2.AutoSize = true;
      this.rPrint3x2.Location = new System.Drawing.Point(195, 3);
      this.rPrint3x2.Name = "rPrint3x2";
      this.rPrint3x2.Size = new System.Drawing.Size(42, 17);
      this.rPrint3x2.TabIndex = 82;
      this.rPrint3x2.Tag = "6";
      this.rPrint3x2.Text = "3x2";
      this.toolTip.SetToolTip(this.rPrint3x2, "Print on 3x2 pages");
      this.rPrint3x2.UseVisualStyleBackColor = true;
      // 
      // rPrint3x1
      // 
      this.rPrint3x1.AutoSize = true;
      this.rPrint3x1.Location = new System.Drawing.Point(98, 3);
      this.rPrint3x1.Name = "rPrint3x1";
      this.rPrint3x1.Size = new System.Drawing.Size(42, 17);
      this.rPrint3x1.TabIndex = 83;
      this.rPrint3x1.Tag = "2";
      this.rPrint3x1.Text = "3x1";
      this.toolTip.SetToolTip(this.rPrint3x1, "Print on 3 pages");
      this.rPrint3x1.UseVisualStyleBackColor = true;
      // 
      // gOrientation
      // 
      this.gOrientation.Controls.Add(this.rPortrait);
      this.gOrientation.Controls.Add(this.rLandscape);
      this.gOrientation.Location = new System.Drawing.Point(22, 38);
      this.gOrientation.Name = "gOrientation";
      this.gOrientation.Size = new System.Drawing.Size(148, 23);
      this.gOrientation.TabIndex = 90;
      // 
      // rPortrait
      // 
      this.rPortrait.AutoSize = true;
      this.rPortrait.Location = new System.Drawing.Point(4, 3);
      this.rPortrait.Name = "rPortrait";
      this.rPortrait.Size = new System.Drawing.Size(58, 17);
      this.rPortrait.TabIndex = 79;
      this.rPortrait.Text = "Portrait";
      this.toolTip.SetToolTip(this.rPortrait, "In height");
      this.rPortrait.UseVisualStyleBackColor = true;
      // 
      // rLandscape
      // 
      this.rLandscape.AutoSize = true;
      this.rLandscape.Checked = true;
      this.rLandscape.Location = new System.Drawing.Point(67, 3);
      this.rLandscape.Name = "rLandscape";
      this.rLandscape.Size = new System.Drawing.Size(78, 17);
      this.rLandscape.TabIndex = 80;
      this.rLandscape.TabStop = true;
      this.rLandscape.Text = "Landscape";
      this.toolTip.SetToolTip(this.rLandscape, "In width");
      this.rLandscape.UseVisualStyleBackColor = true;
      // 
      // bDrawFree
      // 
      this.bDrawFree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawFree.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawFree.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawFree.Location = new System.Drawing.Point(267, 17);
      this.bDrawFree.Name = "bDrawFree";
      this.bDrawFree.Size = new System.Drawing.Size(41, 25);
      this.bDrawFree.TabIndex = 81;
      this.bDrawFree.Tag = "F";
      this.bDrawFree.Text = "Free";
      this.bDrawFree.UseVisualStyleBackColor = false;
      this.bDrawFree.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawLine
      // 
      this.bDrawLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawLine.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawLine.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawLine.Location = new System.Drawing.Point(309, 17);
      this.bDrawLine.Name = "bDrawLine";
      this.bDrawLine.Size = new System.Drawing.Size(41, 25);
      this.bDrawLine.TabIndex = 82;
      this.bDrawLine.Tag = "L";
      this.bDrawLine.Text = "Line";
      this.bDrawLine.UseVisualStyleBackColor = false;
      this.bDrawLine.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawRect
      // 
      this.bDrawRect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawRect.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawRect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawRect.Location = new System.Drawing.Point(351, 17);
      this.bDrawRect.Name = "bDrawRect";
      this.bDrawRect.Size = new System.Drawing.Size(41, 25);
      this.bDrawRect.TabIndex = 83;
      this.bDrawRect.Tag = "R";
      this.bDrawRect.Text = "Rect";
      this.bDrawRect.UseVisualStyleBackColor = false;
      this.bDrawRect.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawPolar
      // 
      this.bDrawPolar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawPolar.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawPolar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawPolar.Location = new System.Drawing.Point(394, 17);
      this.bDrawPolar.Name = "bDrawPolar";
      this.bDrawPolar.Size = new System.Drawing.Size(41, 25);
      this.bDrawPolar.TabIndex = 84;
      this.bDrawPolar.Tag = "P";
      this.bDrawPolar.Text = "Polar";
      this.bDrawPolar.UseVisualStyleBackColor = false;
      this.bDrawPolar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawEdge
      // 
      this.bDrawEdge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawEdge.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawEdge.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawEdge.Location = new System.Drawing.Point(392, 48);
      this.bDrawEdge.Name = "bDrawEdge";
      this.bDrawEdge.Size = new System.Drawing.Size(41, 25);
      this.bDrawEdge.TabIndex = 85;
      this.bDrawEdge.Tag = "E";
      this.bDrawEdge.Text = "Edge";
      this.bDrawEdge.UseVisualStyleBackColor = false;
      this.bDrawEdge.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawMorph
      // 
      this.bDrawMorph.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawMorph.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawMorph.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawMorph.Location = new System.Drawing.Point(377, 77);
      this.bDrawMorph.Name = "bDrawMorph";
      this.bDrawMorph.Size = new System.Drawing.Size(59, 25);
      this.bDrawMorph.TabIndex = 86;
      this.bDrawMorph.Tag = "M";
      this.bDrawMorph.Text = "Morph";
      this.bDrawMorph.UseVisualStyleBackColor = false;
      this.bDrawMorph.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // bDrawReplace
      // 
      this.bDrawReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bDrawReplace.BackColor = System.Drawing.SystemColors.Control;
      this.bDrawReplace.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
      this.bDrawReplace.Location = new System.Drawing.Point(5, 17);
      this.bDrawReplace.Name = "bDrawReplace";
      this.bDrawReplace.Size = new System.Drawing.Size(59, 25);
      this.bDrawReplace.TabIndex = 87;
      this.bDrawReplace.Tag = "A";
      this.bDrawReplace.Text = "Replace";
      this.bDrawReplace.UseVisualStyleBackColor = false;
      this.bDrawReplace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Color_MouseUp);
      // 
      // fBoard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(452, 195);
      this.Controls.Add(this.tabControl1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "fBoard";
      this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
      this.Text = "Board";
      this.tabControl1.ResumeLayout(false);
      this.tp6.ResumeLayout(false);
      this.tp1.ResumeLayout(false);
      this.tp1.PerformLayout();
      this.tp3.ResumeLayout(false);
      this.tp3.PerformLayout();
      this.tp2.ResumeLayout(false);
      this.tp2.PerformLayout();
      this.rbPasteFilter.ResumeLayout(false);
      this.rbPasteFilter.PerformLayout();
      this.gPasteDiff.ResumeLayout(false);
      this.gPasteDiff.PerformLayout();
      this.tp4.ResumeLayout(false);
      this.tp4.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.BWPanel.ResumeLayout(false);
      this.BWPanel.PerformLayout();
      this.tp5.ResumeLayout(false);
      this.tp5.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tPadding)).EndInit();
      this.panel3.ResumeLayout(false);
      this.panel3.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tbTlDash2)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tbTLWidth2)).EndInit();
      this.TextAlign.ResumeLayout(false);
      this.TextAlign.PerformLayout();
      this.tp7.ResumeLayout(false);
      this.tp7.PerformLayout();
      this.gIconTransp.ResumeLayout(false);
      this.gIconTransp.PerformLayout();
      this.gIconSize.ResumeLayout(false);
      this.gIconSize.PerformLayout();
      this.gPrintMulti.ResumeLayout(false);
      this.gPrintMulti.PerformLayout();
      this.gOrientation.ResumeLayout(false);
      this.gOrientation.PerformLayout();
      this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button ExpandB;
		internal System.Windows.Forms.CheckBox X8;
		internal System.Windows.Forms.CheckBox ExpandWhite;
		internal System.Windows.Forms.CheckBox ExpandWOnly;
		private System.Windows.Forms.Button UndoB;
		private System.Windows.Forms.Button RedoB;
		private System.Windows.Forms.Button ScreenB;
		private System.Windows.Forms.Button ExpandDiffB;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label lFill;
		internal System.Windows.Forms.CheckBox Fill2Black;
		internal System.Windows.Forms.CheckBox FillD8;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ToolTip toolTip;
		internal System.Windows.Forms.ComboBox cbFill;
    internal System.Windows.Forms.CheckBox FillNoBlack;
    private System.Windows.Forms.TabPage tp1;
    private System.Windows.Forms.TabPage tp3;
    private System.Windows.Forms.ComboBox cbRepeatMode;
    internal System.Windows.Forms.CheckBox RepeatCenter;
    internal System.Windows.Forms.TextBox RepeatCount;
    private System.Windows.Forms.Label lRepeat;
    internal System.Windows.Forms.CheckBox RepeatOn;
    internal System.Windows.Forms.TextBox RepeatX;
    internal System.Windows.Forms.TextBox RepeatY;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cbBrush;
    private System.Windows.Forms.ComboBox cbShape;
    internal System.Windows.Forms.CheckBox DrawWOnly;
    private System.Windows.Forms.Label lShape;
    internal System.Windows.Forms.CheckBox ShapeAdjust;
    internal System.Windows.Forms.CheckBox ShapeMirrorY;
    internal System.Windows.Forms.CheckBox ShapeMirrorX;
    internal System.Windows.Forms.CheckBox DrawFilled;
    internal System.Windows.Forms.CheckBox DrawOrto;
    internal System.Windows.Forms.CheckBox DrawBlack;
    internal System.Windows.Forms.CheckBox DrawCenter;
    private System.Windows.Forms.Label lDraw;
    private System.Windows.Forms.TabPage tp2;
    private System.Windows.Forms.TabPage tp4;
    private System.Windows.Forms.Button bGray;
    private System.Windows.Forms.Button Invert;
    internal System.Windows.Forms.CheckBox cbInvertBW;
    internal System.Windows.Forms.CheckBox cbInvertIntensity;
    private System.Windows.Forms.Button rgb2cmyB;
    private System.Windows.Forms.Button rgbshiftB;
    private System.Windows.Forms.Button levelsB;
    internal System.Windows.Forms.TextBox levelsCount;
    private System.Windows.Forms.Button contour;
    private System.Windows.Forms.Panel BWPanel;
    private System.Windows.Forms.RadioButton BWMax;
    private System.Windows.Forms.RadioButton BWMin;
    private System.Windows.Forms.RadioButton BWAvg;
    private System.Windows.Forms.Button BW;
    internal System.Windows.Forms.TextBox BWLevel;
    private System.Windows.Forms.Button redoB2;
    private System.Windows.Forms.Button undoB2;
    private System.Windows.Forms.Button darkB;
    private System.Windows.Forms.Button brightB;
    internal System.Windows.Forms.CheckBox pasteQuad;
    internal System.Windows.Forms.CheckBox pasteFiles;
    internal System.Windows.Forms.CheckBox pasteTrans;
    internal System.Windows.Forms.CheckBox pasteTRX;
    internal System.Windows.Forms.CheckBox pasteRepeat;
    private System.Windows.Forms.Button NormColorB;
    internal System.Windows.Forms.CheckBox cbContrast;
    private System.Windows.Forms.Button bBorder;
    internal System.Windows.Forms.TextBox borderLevel;
    internal System.Windows.Forms.CheckBox chRemDotWhite;
    private System.Windows.Forms.Button bRemoveDots;
    internal System.Windows.Forms.CheckBox chRemDotBlack;
    private System.Windows.Forms.RadioButton rRemDot8;
    private System.Windows.Forms.RadioButton rRemDot4;
    private System.Windows.Forms.RadioButton rRemDot3;
    private System.Windows.Forms.Panel panel1;
    internal System.Windows.Forms.CheckBox chBrightBW;
    private System.Windows.Forms.Button bCReplace;
    internal System.Windows.Forms.TextBox Snap;
    internal System.Windows.Forms.CheckBox chSnap;
    internal System.Windows.Forms.CheckBox pasteExtend;
    private System.Windows.Forms.Button ImpandB;
    internal System.Windows.Forms.CheckBox chImpandBlack;
    internal System.Windows.Forms.TextBox dustLevel;
    private System.Windows.Forms.Button bRemoveDust;
    internal System.Windows.Forms.CheckBox whiteDust;
    internal System.Windows.Forms.CheckBox blackDust;
    internal System.Windows.Forms.CheckBox pasteMix;
    private System.Windows.Forms.TabPage tp5;
    private System.Windows.Forms.Button bText;
    internal System.Windows.Forms.TextBox tbText;
    private System.Windows.Forms.Label lFontSize;
    internal System.Windows.Forms.TextBox FontSize;
    internal System.Windows.Forms.TextBox FontFamily;
    private System.Windows.Forms.Label lFamily;
    internal System.Windows.Forms.CheckBox FontItalic;
    internal System.Windows.Forms.CheckBox FontBold;
    private System.Windows.Forms.Panel TextAlign;
    internal System.Windows.Forms.RadioButton taRight;
    internal System.Windows.Forms.RadioButton taLeft;
    internal System.Windows.Forms.RadioButton taCenter;
    private System.Windows.Forms.Button FntDialog;
    internal System.Windows.Forms.CheckBox FontUnder;
    internal System.Windows.Forms.CheckBox FontStrike;
    public System.Windows.Forms.Button btColor;
    private System.Windows.Forms.Label ltlWidth;
    public System.Windows.Forms.Button blColor;
    internal System.Windows.Forms.TextBox tbTLRound;
    private System.Windows.Forms.Label ltlRound;
    internal System.Windows.Forms.CheckBox chTLFlat;
    internal System.Windows.Forms.CheckBox chTLHeader;
    internal System.Windows.Forms.CheckBox chTOpaq;
    internal System.Windows.Forms.CheckBox chTPasteLine;
    internal System.Windows.Forms.CheckBox chTBWAuto;
    internal System.Windows.Forms.CheckBox chLColorFont;
    internal System.Windows.Forms.TextBox dArrowWidth;
    internal System.Windows.Forms.TextBox dArrowLen;
    private System.Windows.Forms.Label lArrow;
    private System.Windows.Forms.Label lRadius;
    internal System.Windows.Forms.TextBox dArrrowRadius;
    internal System.Windows.Forms.CheckBox chRadiusFlat;
    private System.Windows.Forms.Button BOutline;
    private System.Windows.Forms.Button bCRemove;
    internal System.Windows.Forms.NumericUpDown tbTLWidth2;
    internal System.Windows.Forms.TabControl tabControl1;
    private System.Windows.Forms.TabPage tp6;
    internal System.Windows.Forms.Button bModeSelect;
    internal System.Windows.Forms.Button bModeFill;
    internal System.Windows.Forms.Button bModeCircle;
    internal System.Windows.Forms.Button bBlue;
    internal System.Windows.Forms.Button button8;
    internal System.Windows.Forms.Button button7;
    internal System.Windows.Forms.Button button5;
    internal System.Windows.Forms.Button button4;
    internal System.Windows.Forms.Button button6;
    internal System.Windows.Forms.Button bColorGr1;
    internal System.Windows.Forms.Button bColorGr3;
    internal System.Windows.Forms.Button bColorGr2;
    internal System.Windows.Forms.Button bGY;
    internal System.Windows.Forms.Button bGreen;
    internal System.Windows.Forms.Button bRed;
    internal System.Windows.Forms.Button bColorGr7;
    internal System.Windows.Forms.Button bYellow;
    internal System.Windows.Forms.Button button1;
    internal System.Windows.Forms.Button bCyan;
    internal System.Windows.Forms.Button bWhite;
    internal System.Windows.Forms.Button bColor2;
    internal System.Windows.Forms.Button bColor;
    internal System.Windows.Forms.Button bClear;
    internal System.Windows.Forms.Button bSwap;
    internal System.Windows.Forms.Button bColorGr6;
    internal System.Windows.Forms.Button bColorGr5;
    internal System.Windows.Forms.Button bColorGr4;
    internal System.Windows.Forms.Button bModeLinear;
    internal System.Windows.Forms.Button bColorGr8;
    internal System.Windows.Forms.Button bCDark1;
    internal System.Windows.Forms.Button bCLight1;
    internal System.Windows.Forms.Button bCDark2;
    internal System.Windows.Forms.Button bCLight2;
    private System.Windows.Forms.Label ltDash;
    internal System.Windows.Forms.NumericUpDown tbTlDash2;
    internal System.Windows.Forms.TextBox tbDash;
    private System.Windows.Forms.Label lDash;
    private System.Windows.Forms.Label lMixLevel;
    internal System.Windows.Forms.TextBox MixLevel;
    private System.Windows.Forms.Panel gPasteDiff;
    private System.Windows.Forms.RadioButton rbDiffBW;
    private System.Windows.Forms.RadioButton rbDiffDiff;
    private System.Windows.Forms.RadioButton rbDiffRed;
    private System.Windows.Forms.RadioButton rbDiffXor;
    private System.Windows.Forms.RadioButton rbDiffOff;
    private System.Windows.Forms.RadioButton rbDiffMax;
    private System.Windows.Forms.RadioButton rbDiffMin;
    private System.Windows.Forms.RadioButton rbDiffAvg;
    private System.Windows.Forms.Panel panel3;
    internal System.Windows.Forms.RadioButton tsDiamond;
    internal System.Windows.Forms.RadioButton tsCircle;
    internal System.Windows.Forms.RadioButton tsBox;
    private System.Windows.Forms.Label lPadding;
    internal System.Windows.Forms.NumericUpDown tPadding;
    internal System.Windows.Forms.Button bABlack;
    internal System.Windows.Forms.Button bModeRadial;
    internal System.Windows.Forms.Button bModeBorder;
    private System.Windows.Forms.TabPage tp7;
    internal System.Windows.Forms.TextBox tNewHeight;
    internal System.Windows.Forms.TextBox tNewWidth;
    private System.Windows.Forms.Label lNew;
    private System.Windows.Forms.Button bNew;
    internal System.Windows.Forms.TextBox tIconHeight;
    internal System.Windows.Forms.TextBox tIconWidth;
    private System.Windows.Forms.Label lIcon;
    private System.Windows.Forms.Button bSaveIcon;
    private System.Windows.Forms.Panel gIconSize;
    private System.Windows.Forms.RadioButton rIconAspect;
    private System.Windows.Forms.RadioButton rIconExact;
    private System.Windows.Forms.RadioButton rIconHeight;
    private System.Windows.Forms.RadioButton rIconWidth;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.RadioButton rIcon1to1;
    internal System.Windows.Forms.CheckBox chIconCursor;
    private System.Windows.Forms.Panel gIconTransp;
    private System.Windows.Forms.RadioButton rIconTrWhite;
    private System.Windows.Forms.RadioButton rIconTrNone;
    private System.Windows.Forms.RadioButton rIconTrColor2;
    private System.Windows.Forms.Panel rbPasteFilter;
    private System.Windows.Forms.RadioButton rbFilterColor2;
    private System.Windows.Forms.RadioButton rbFilterWhite;
    private System.Windows.Forms.RadioButton rbFilterOff;
    private System.Windows.Forms.RadioButton rbFilterNotColor2;
    private System.Windows.Forms.RadioButton rbFilterAndNotBlack;
    private System.Windows.Forms.Button bPrint;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Panel gPrintMulti;
    private System.Windows.Forms.RadioButton rPrint3x2;
    private System.Windows.Forms.RadioButton rPrint1x1;
    private System.Windows.Forms.RadioButton rPrint2x2;
    private System.Windows.Forms.RadioButton rPrint2x1;
    private System.Windows.Forms.RadioButton rPrint3x1;
    private System.Windows.Forms.Panel gOrientation;
    internal System.Windows.Forms.RadioButton rPortrait;
    internal System.Windows.Forms.RadioButton rLandscape;
    internal System.Windows.Forms.Button bDrawFree;
    internal System.Windows.Forms.Button bDrawPolar;
    internal System.Windows.Forms.Button bDrawRect;
    internal System.Windows.Forms.Button bDrawLine;
    internal System.Windows.Forms.Button bDrawMorph;
    internal System.Windows.Forms.Button bDrawEdge;
    internal System.Windows.Forms.Button bDrawReplace;
  }
}