﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;


namespace fill {
    public struct fillres {
      public int x0,y0,x1,y1,m;
    }
    public class Shape {
      public int[] pts;
      public bool[] move;
      
      public Shape(int len) { pts=new int[len];}      
      public Shape(Shape src) { 
        if(src.pts!=null) pts=src.pts.Clone() as int[];
        if(src.move!=null) move=src.move.Clone() as bool[];
      }
      public static int[] BoundingBox(int[] pts) {
        if(pts==null||pts.Length<2) return null;
        int[] bb=new int[4];
        bb[0]=bb[2]=pts[0];bb[1]=bb[3]=pts[1];
        for(int i=2;i<pts.Length;i++) {
          if(pts[i]<bb[0]) bb[0]=pts[i];else if(pts[i]>bb[2]) bb[2]=pts[i];
          i++;
          if(pts[i]<bb[1]) bb[1]=pts[i];else if(pts[i]>bb[3]) bb[3]=pts[i];
        }
        return bb;
      }
      public static void Move(int[] pts,int dx,int dy) {
        if(pts==null) return;
        for(int i=0;i<pts.Length;i++)
          pts[i]+=0==(i&1)?dx:dy;
      }
    }    

    public class bmap {
      public int Width,Height;
      public int[] Data; //r,g,b,h
      public const int White=0xffffff,Black=0;
      public static readonly int[] sqrt=new int[1048577];      

      public override string ToString() {
        return ""+Width+"x"+Height;
      }
      static bmap() {
        int j=0,j2=0;
        for(int i=0;i<sqrt.Length;i++) {
          if(j2<=i) {j2+=2*j+1;j++;}
          sqrt[i]=j-1;
        }
      }
      public static int isqrt(int x) {
        if(x<1) return 0;
        else if(x<sqrt.Length) return sqrt[x];
        else return (int)Math.Sqrt(x);
      }
      public static int isqrt(int x,int y) {
        return isqrt(x*x+y*y);
      }
      public static int sqr(int x) { return x*x;}
      public static int sqr(int x,int y) { return x*x+y*y;}
      public static int sabs(int x,int y) { return Math.Abs(x)+Math.Abs(y);}      
      public static int abs(int x) { return Math.Abs(x);}
      public int isqrt2(int x) {
        uint a,a2;
        if(x<4) return x>0?1:0;
        a=(uint)(x>>(bitscan(x)>>1));
        do {
          a2=a;
          a=(uint)(a2+x/a2)>>1;
        } while(a<a2);
        return (int)a2;
      }
      public static int idiv(int x,int div) {
        if(div<0) {x=-x;div=-div;}
        if(x>=0) return x/div;
        int r=x/div;
        return x==r*div?r:r-1;
      }
      public static int ceil(int x,int div) {
        if(div<2) return x;
        int r=x%div;
        return r==0?x:x-r+div;
      }
      public static int floor(int x,int div) {
        return div>1?x-x%div:x;
      }
      public static int modp(int x,int div) {
        if(div<2) return 0;
        x=x%div;
        if(x<0) x+=div;
        return x;
      }
      public static int round(int x,int div) {
        if(div<2) return 0;
        int r=x%div;
        if(2*r<div) x-=r;else x+=div-r;
        return x;
      }       

      
      public bmap() {}
      public bmap(int width,int height) {Alloc(width,height);}
      public bmap(bmap src,int x,int y,int x2,int y2,int extent) {
        int w=x2-x+1+2*extent,h=y2-y+1+2*extent;
        Alloc(w,h);
        if(src!=null) CopyRectangle(src,x,y,x2,y2,extent,extent,-1);
      }
      public bmap(string brush) {
        string[] line=brush.Split('.');
        Width=line[0].Length;Height=line.Length;
        Alloc(Width,Height);
        for(int y=0;y<Height;y++) {
          string l=line[y];
          for(int x=0;x<l.Length;x++)
            Data[y*Width+x]=l[x]!='0'?White:0;
        }
      }      
      public bmap(bmap src) {Copy(src);}
      public bmap Clone() { return new bmap(this);}
      public void Copy(bmap src) {
        if(src==null) return;
        Data=src.Data.Clone() as int[];
        Width=src.Width;Height=src.Height;
      }
      public void Alloc(int width,int height) {        
        Data=new int[(Width=width)*(Height=height)];
      }
      public int XY(int x,int y) {
        if(x<0||y<0||x>=Width||y>=Height) return -1;
        return Data[y*Width+x];
      }
      public void XY(int x,int y,int color) {
        if(x<0||y<0||x>=Width||y>=Height) return;
        Data[y*Width+x]=color;
      }
      public void XY(int x,int y,int color,bool whiteonly) {
        if(x<0||y<0||x>=Width||y>=Height) return;
        if(!whiteonly||(Data[y*Width+x]&0xffffff)==White)
          Data[y*Width+x]=color;
      }
      
      public void Brush(int x,int y,int color,bmap brush,bool whiteonly) {
        if(brush==null) { XY(x,y,color,whiteonly);return;}
        int bx=brush.Width/2,by=brush.Height/2;
        if(x<-brush.Width||y<-brush.Height||x>=Width+brush.Width||y>=Height+brush.Height) return;
        for(int i=0;i<brush.Height;i++) {
          int dy=y+i-by;
          if(dy<0||dy>=Height) continue;
          for(int j=0;j<brush.Width;j++) {
           int dx=x+j-bx;
           if(dx<0||dx>=Width) continue;
           if(brush.Data[i*brush.Width+j]!=0) 
             if(!whiteonly||(Data[dy*Width+dx]&0xffffff)==White) Data[dy*Width+dx]=color;
          }
        }
      }

      public void LeaveBlack() {
        for(int i=0;i<Data.Length;i++) {
          int x=Data[i]&White;
          if(x!=0&&x!=White) Data[i]=White;
        }
      }      
      public void FillRectangle(int x,int y,int x2,int y2,int color) { FillRectangle(x,y,x2,y2,color,0);}
      public void FillRectangle(int x,int y,int x2,int y2,int color,int cmode) {
        int r;
        if(x2<x) {r=x;x=x2;x2=r;}
        if(y2<y) {r=y;y=y2;y2=r;}
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        if(x<0) x=0;if(x2>=Width) x2=Width-1;
        if(y<0) y=0;if(y2>=Height) y2=Height-1;
        int h=y*Width+x,n=x2-x+1;
        while(y<=y2) {
          if(cmode>0)
            for(int he=h+n;h<he;h++)
              Data[h]=Palette.Colorize(cmode,color,Data[h]);
          else
            for(int he=h+n;h<he;h++) Data[h]=color;
          h+=Width-n;
          y++;
        }        
      }
			public void SmartSelect(int[] rect) {
			  R.Norm(rect);
				R.Intersect(rect,0,0,Width-1,Height-1);			
				if(rect[0]==rect[2]||rect[1]==rect[3]) return;
				int c=White&(Data[rect[1]*Width+rect[0]]),x,y;
				while(rect[0]<rect[2]) {
					for(y=rect[1];y<=rect[3];y++)
					  if((Data[y*Width+rect[0]]&White)!=c) break;
				  if(y>rect[3]) rect[0]++;else break;
				}
				while(rect[0]<rect[2]) {
					for(y=rect[1];y<=rect[3];y++)
					  if((Data[y*Width+rect[2]]&White)!=c) break;
				  if(y>rect[3]) rect[2]--;else break;
				}
				while(rect[1]<rect[3]) {
					for(x=rect[0];x<=rect[2];x++)
					  if((Data[rect[1]*Width+x]&White)!=c) break;
				  if(x>rect[2]) rect[1]++;else break;
				}
				while(rect[1]<rect[3]) {
					for(x=rect[0];x<=rect[2];x++)
					  if((Data[rect[3]*Width+x]&White)!=c) break;
				  if(x>rect[2]) rect[3]--;else break;
				}
			}
      public void Erase(int x,int y,int x2,int y2,bool dox,bool doy) { Erase(x,y,x2,y2,dox?doy?0:1:doy?2:0);}
			public void Erase(int x,int y,int x2,int y2,int mode) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
				int width=x2-x+1,height=y2-y+1;
        int y0=y<1?0:y-1,y1=y2+1<Height?y2+1:y2;
        int x0=x<1?0:x-1,x1=x2+1<Width?x2+1:x2;
        int dx=2*(x2-x+1),dy=2*(y2-y+1);
        for(int iy=y;iy<=y2;iy++) {
          int cy=Data[iy*Width+x0],cy2=Data[iy*Width+x1];
          for(int ix=x;ix<=x2;ix++) {
					  int c;						
					  if(mode>=3) {
							int _x=ix-x,_y=iy-y,w1=width+1,h1=height+1,_x2=(_y+1)*w1,_y2=(_x+1)*h1,cx2;
							int xa,ya,xb,yb,xc,yc,xd,yd,ca,cb,cc,cd,ab;
							if((width-_x)*height>=width*(_y+1)) {
								xa=(h1*(_x+1)+_x2)/h1;ya=0;xb=0;yb=(w1*(_y+1)+_y2)/w1;ab=xa+yb<1?128:(_x+1+yb-_y)*255/(xa+yb);
							} else {
								xa=w1;ya=(w1*(_y+1-h1)+_y2)/w1;xb=(h1*(_x+1-w1)+_x2)/h1;yb=h1;ab=width-xb+height-ya<1?128:(_x+1-xb+height-_y)*255/(width-xb+height-ya);
							}
							if(xa<0) xa=0;else if(xa>w1) xa=w1;
							if(xb<0) xb=0;else if(xb>w1) xb=w1;
							if(ya<0) ya=0;else if(ya>h1) ya=h1;
							if(yb<0) yb=0;else if(yb>h1) yb=h1;
							ca=Data[(y+ya-1)*Width+x+xa-1];cb=Data[(y+yb-1)*Width+x+xb-1];
							c=Palette.RGBMix(cb,ca,ab,255);

							if((_x+1)*height<width*(_y+1)) {
								xc=0;yc=(w1*(_y+1)-_y2)/w1;xd=(h1*(_x+1+w1)-_x2)/h1;yd=h1;ab=xd+height-yc<1?128:(_x+1+_y-yc)*255/(xd+height-yc);
							} else {
								xc=(h1*(_x+1)-_x2)/h1;yc=0;xd=w1;yd=(w1*(_y+1+h1)-_y2)/w1;ab=width-xc+yd<1?128:(_x-xc+_y+1)*255/(width-xc+yd);
							}
							if(xc<0) xa=0;else if(xa>w1) xa=w1;
							if(xd<0) xd=0;else if(xd>w1) xd=w1;
							if(yc<0) yc=0;else if(yc>h1) yc=h1;
							if(yd<0) yd=0;else if(yd>h1) yd=h1;
							cc=Data[(y+yc-1)*Width+x+xc-1];cd=Data[(y+yd-1)*Width+x+xd-1];
							cx2=Palette.RGBMix(cc,cd,ab,255);
							if(mode!=3) c=mode==4?cx2:Palette.RGBMix(c,cx2,128,255);
						} else {
						  bool dox=mode<2,doy=mode!=1;
              int cx=Data[y0*Width+ix],cx2=Data[y1*Width+ix];
              cx=doy?Palette.RGBMix(cx,cx2,2*(iy-y)+1,dy):0;
              cx2=dox?Palette.RGBMix(cy,cy2,2*(ix-x)+1,dx):0;
							c=Palette.RGBMix(cx,cx2,1-(dox?0:1)+(doy?0:1),2);
						}
            Data[iy*Width+ix]=c;
          }
        }        
      }
      public void EraseColor(int x,int y,int x2,int y2,int color,bool vert,bool hori) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        ClearByte(x,y,x2,y2,true,color);        
        RectByte(x-1,y-1,x2+1,y2+1,1);
        int c24=1<<24;
        if(vert) {
          for(int x3=x;x3<=x2;x3++) {
            for(int p=y*Width+x3,pe=p+(y2-y)*Width;p<pe;p+=Width)
              if(0==(Data[p]&c24)) {
                int c1=Data[p-Width],p2=p,n=2;
                while(0==(Data[p+=Width]&c24)) n++;
                int c2=Data[p],i=1;
                while(p2<p) {
                  Data[p2]=Palette.RGBMix(c1,c2,i++,n);
                  p2+=Width;
                }
              }
          }
        }
        if(hori) {
          for(int y3=y;y3<=y2;y3++) {
            for(int p=y3*Width+x,pe=p+x2-x;p<pe;p++)
              if(0==(Data[p]&c24)) {
                int c1=Data[p-1],p2=p,n=2;
                while(0==(Data[p+=1]&c24)) n++;
                int c2=Data[p],i=1;
                while(p2<p) {
                  int c=Palette.RGBMix(c1,c2,i++,n);
                  if(vert) c=Palette.RGBMix(c,Data[p2],1,2);
                  Data[p2]=c;
                  p2++;
                }
              }
          }
        }
        ClearByte(x-1,y-1,x2+1,y2+1,0);
      }
			public void BW(int x,int y,int x2,int y2,int minmax,int blacklevel) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        for(int iy=y;iy<=y2;iy++) 
          for(int ix=x;ix<=x2;ix++) {
					  int c=Data[iy*Width+ix];
						int r=c&255,g=(c>>8)&255,b=(c>>16)&255;
						if(minmax<0) r=r<g?r<b?r:b:g<b?g:b;
            else if(minmax==2) r=r*r+g*g+b*b<blacklevel*blacklevel?0:255;
            else if(minmax==3) r=(r+3*g+2*b+1)/6;
						else if(minmax>0) r=r>g?r>b?r:b:g>b?g:b;
						else r=r+g+b;
						Data[iy*Width+ix]=r<blacklevel?0:White;
					}			  
			}
			public void C8(int x,int y,int x2,int y2,int level) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        for(int iy=y;iy<=y2;iy++) 
          for(int ix=x;ix<=x2;ix++) {
					  int c=Data[iy*Width+ix];
						int r=c&255,g=(c>>8)&255,b=(c>>16)&255;
            r=r<level?0:255;
            g=g<level?0:255;
            b=b<level?0:255;
						Data[iy*Width+ix]=r|(g<<8)|(b<<16);
					}			  
			}
			public void Gray(int x,int y,int x2,int y2,int minmax) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x2<0||y2<0||x>=Width||y>=Height) return;
        for(int iy=y;iy<=y2;iy++) 
          for(int ix=x;ix<=x2;ix++) {
					  int c=Data[iy*Width+ix];
						int r=c&255,g=(c>>8)&255,b=(c>>16)&255;
						if(minmax<0) r=r<g?r<b?r:b:g<b?g:b;
            else if(minmax==2) r=isqrt(r*r+g*g+b*b)*255/441;
            else if(minmax==3) r=(r+3*g+2*b+1)/6;
						else if(minmax>0) r=r>g?r>b?r:b:g>b?g:b;
						else r=(r+g+b)/3;
						Data[iy*Width+ix]=r|(r<<8)|(r<<16);
					}			  
			}
      public void MoveRectangle(int x,int y,int x2,int y2,int dx,int dy,int bgcolor,int trcolor,bool cs) {
        int w=x2-x+1,h=y2-y+1;
        bmap bm2=new bmap(w,h);
        bm2.Clear(bgcolor);
        bm2.CopyRectangle(this,x,y,x2,y2,0,0,-1);
        if(bgcolor!=-1) FillRectangle(x,y,x2,y2,bgcolor);
        if(cs) {
          if(x>dx&&y==dy) CopyRectangle(this,dx,y,x-1,y2,x2+dx-x+1,y,-1);
          if(x<dx&&y==dy) CopyRectangle(this,x2+1,y,x2+dx-x,y2,x,y,-1);
          if(dx==x&&y>dy) CopyRectangle(this,x,dy,x2,y-1,x,y2+dy-y+1,-1);
          if(dx==x&&y<dy) CopyRectangle(this,x,y2+1,x2,y2+dy-y,x,y,-1);
        }
        CopyRectangle(bm2,0,0,w-1,h-1,dx,dy,trcolor);
      }
      public void MoveRectangle(int x,int y,int x2,int y2,int dx,int dy,bmap back) {
        int a=x,b=y;
        IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        dx+=x-a;dy+=y-b;
        int dx2=dx+x2-x,dy2=dy+y2-y;
        a=dx;b=dy;
        IntersectRect(ref dx,ref dy,ref dx2,ref dy2,0,0,Width-1,Height-1);
        if(dx>=Width||dy>=Height||dx2<0||dy2<0) return;
        x+=dx-a;y+=dy-b;x2=x+dx2-dx;y2=y+dy2-dy;
        
        int w=x2-x+1,h=y2-y+1;
        bmap bm2=new bmap(w,h);
        bm2.CopyRectangle(this,x,y,x2,y2,0,0,-1);
        if(back!=null) CopyRectangle(back,x,y,x2,y2,x,y,-1);
        CopyRectangle(bm2,0,0,w-1,h-1,dx,dy,-1);
      }      
      
      public void CopyRectangle(bmap src,int x,int y,int x2,int y2,int dx,int dy,int trcolor) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        int tx=dx-x,ty=dy-y;
        if(!R.Intersect(ref x,ref y,ref x2,ref y2,0,0,src.Width-1,src.Height-1)) return;
        if(!R.Intersect(ref x,ref y,ref x2,ref y2,-tx,-ty,-tx+Width-1,-ty+Height-1)) return;        
        dx=x+tx;dy=y+ty;
        int n=x2-x+1,g=dy*Width+dx,h=y*src.Width+x;
        while(y<=y2) {
          for(int he=h+n;h<he;h++,g++) {
            int c=src.Data[h];
            if(c!=trcolor) Data[g]=c;
          }
          g+=Width-n;h+=src.Width-n;
          y++;
        }
      }
      public delegate int DelegateSearch(object param,bmap map,int x,int y,bmap search);
      public fillres SearchRectangle(bmap src,bmap search,int sx,int sy,int w,int h,bool over,int color,int trcolor,int cmode,DelegateSearch OnReplace,object param) {
        search.ClearByte();
        color&=White;
        int c00,c10,c01,c11,o00,o10,o01,o11;
        bool[] mask=null;
        fillres fr=new fillres();
        if(trcolor==-1) {
          o00=0;o10=w-1;o01=Width*(h-1);o11=o10+o01;
          c00=search.XY(sx,sy);c10=search.XY(sx+w-1,sy);c01=search.XY(sx,sy+h-1);c11=search.XY(sx+w-1,sy+h-1);
        } else {
          trcolor&=White;
          mask=new bool[w*h];
          bool f1,f2,f3,f4=f3=f2=f1=false;
          c00=c10=c01=c11=o00=o01=o10=o11=-1;
          for(int j=0;j<h;j++) for(int i=0;i<w;i++) mask[w*j+i]=search.XY(i,j)!=trcolor;
          for(int i=0;i<w*h;i++) {
            int a=i%w,b=i/w;
            if(!f1&&mask[b*w+a]) { c00=search.XY(a,b);o00=Width*b+a;f1=true;}
            a=w-a-1;b=h-b-1;
            if(!f2&&mask[b*w+a]) { c11=search.XY(a,b);o11=Width*b+a;f2=true;}
            a=i/h;b=h-i%h-1;
            if(!f3&&mask[b*w+a]) { c01=search.XY(a,b);o01=Width*b+a;f3=true;}
            a=w-a-1;b=h-b-1;
            if(!f4&&mask[b*w+a]) { c10=search.XY(a,b);o10=Width*b+a;f4=true;}
          }
          if(!(f1&&f2&&f3&&f4)) return fr;
        }
        c00&=White;c01&=White;c10&=White;c11&=White;
        ClearByte();        
        int[] data=src.Data,sdata=search.Data;
        for(int y=1;y<Height-h;y++) {
          for(int x=1,o=y*Width+1;x<Width-w;x++,o++) if(data[o+o00]==c00&&data[o+o10]==c10&&data[o+o01]==c01&&data[o+o11]==c11) {
            for(int j=0;j<h;j++)
              if(trcolor==-1) {
                for(int i=0,p=o+(j)*Width,q=(sy+j)*search.Width+sx;i<w;i++,p++,q++) if(data[p]!=sdata[q]) goto fail;
              } else {
                for(int i=0,p=o+(j)*Width,q=(sy+j)*search.Width+sx,r=j*w+i;i<w;i++,p++,q++,r++) if(mask[r]&&data[p]!=sdata[q]) goto fail;
              }
            if(fr.m==0) {fr.x0=x;fr.y0=y;fr.x1=x+w-1;fr.y1=y+h-1;}
            else R.Union(ref fr.x0,ref fr.y0,ref fr.x1,ref fr.y1,x,y,x+w-1,y+h-1);
            fr.m++;
            if(OnReplace==null||0>=OnReplace(param,this,x,y,search)) {
              if(trcolor==-1) FillRectangle(x,y,x+w-1,y+h-1,color,cmode);
              else for(int j=0;j<h;j++)
                for(int i=0,p=o+(j)*Width,r=j*w+i;i<w;i++,p++,r++) if(mask[r]) Data[p]=cmode>0?Palette.Colorize(cmode,color,Data[p]):color;
            }
            if(!over) {x+=w-1;o+=w-1;}
           fail:;
          }
        }
        return fr;
      }
      public long FindRectangle(ref int x,ref int y,int x2,int y2,bool backward,int level) {
        R.Norm(ref x,ref y,ref x2,ref y2);        
        long min=long.MaxValue;
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) { x=y=-1;return min;}
        ClearByte();
        int w=x2-x+1,h=y2-y+1,xi=x+w,yi=y,xf=-1,yf=-1,xd=backward?-1:1;
        long limit2=1+level*w*h;
        for(int ye=backward?0:Height-1-h;yi!=ye;) {
          bool i=yi>=y-h&&yi<=y2;
          for(int xe=backward?0:Width-1-w;xi!=xe;xi+=xd) {
            if(i&&xi>=x-w&&xi<=x2) continue;
            long d=DiffRect(x,y,x2,y2,xi,yi,limit2);
            if(d<min) {
              xf=xi;yf=yi;
              if((min=d)==0||d<limit2) goto found;
              //if(d<limit2) limit2=d;
            }
          }
          if(backward) {xi=Width-w-1;yi--;} else {xi=1;yi++;}
        }
       found:
        x=xf;y=yf;
        return min;
      }
      public static int DiffPixel(int src,int dst) {
        byte rs=(byte)(src&255),gs=(byte)(src>>8),bs=(byte)(src>>16);
        byte rd=(byte)(dst&255),gd=(byte)(dst>>8),bd=(byte)(dst>>16);
        return (rd>rs?rd-rs:rs-rd)+(gd>gs?gd-gs:gs-gd)+(bd>bs?bd-bs:bs-bd);
      }
      public long DiffRect(int x,int y,int x2,int y2,int dx,int dy,long limit) {
        long diff=0;
        int w=x2-x+1,h=y2-y+1;
        int src=y*Width+x,dst=dy*Width+dx;
        bool exact=limit==1;
        for(int yi=0;yi<h;yi++,src+=Width-w,dst+=Width-w) {          
          for(int xi=0;xi<w;xi++,src++,dst++) {
            int cs=Data[src],cd=Data[dst];
            if(exact) {
              if(cs!=cd) return long.MaxValue;
            } else
              diff+=DiffPixel(Data[src],Data[dst]);
          }            
          if(diff>=limit) return long.MaxValue;          
        }
        return exact?0:diff;
      }
      public static bool IntersectRect(ref int x,ref int y,ref int x2,ref int y2,int ix,int iy,int ax,int ay) {
        int r;
        if(x>x2) {r=x;x=x2;x2=r;};
        if(y>y2) {r=y;y=y2;y2=r;};
        if(ix>ax) {r=ix;ix=ax;ax=r;};
        if(iy>ay) {r=iy;iy=ay;ay=r;};
        if(x>ax||x2<ix||y>ay||y2<iy) return false;
        if(x<ix) x=ix;if(x2>ax) x2=ax;
        if(y<iy) y=iy;if(y2>ay) y2=ay;
        return true;        
      }
            
      public void Save(string filename) {
        Bitmap bm=new Bitmap(Width-2,Height-2,PixelFormat.Format32bppRgb);
        ToBitmap(this,bm,false);
        bm.Save(filename);
        bm.Dispose();
      }
      public void FromBitmap(Bitmap bm,int x,int y,int width,int height) {
        if(x<0) {width+=x;x=0;}
        if(y<0) {height+=y;y=0;}
        if(x+width>bm.Width) width=bm.Width-x;
        if(y+height>bm.Height) height=bm.Height-y;
        if(width<1||height<1) return;
        Rectangle r=new Rectangle(x,y,width,height);
        BitmapData bd=bm.LockBits(r,ImageLockMode.ReadOnly,PixelFormat.Format32bppRgb);
        for(int i=0;i<bd.Height;i++) {
          int addr=(1+y+i)*Width+1+x;
          Marshal.Copy(new IntPtr(bd.Scan0.ToInt64()+bd.Stride*i),Data,addr,bd.Width);
          for(int e=addr+bd.Width;addr<e;addr++) Data[addr]&=White;
        }
        bm.UnlockBits(bd);        
      }
      public static bmap FromBitmap(bmap map,Bitmap bm,int trcolor) {
        if(bm==null) return map;
        if(map==null) map=new bmap();
        map.Alloc(bm.Width+2,bm.Height+2);
        map.Clear();
        Rectangle r=new Rectangle(0,0,bm.Width,bm.Height);
        bool alpha=bm.PixelFormat==PixelFormat.Format32bppArgb;
        BitmapData bd=bm.LockBits(r,ImageLockMode.ReadOnly,alpha?PixelFormat.Format32bppArgb:PixelFormat.Format32bppRgb);
        for(int y=0;y<bd.Height;y++)
          Marshal.Copy(new IntPtr(bd.Scan0.ToInt64()+bd.Stride*y),map.Data,(1+y)*map.Width+1,bd.Width);
			  if(trcolor>=-1) map.ClearByte(alpha?trcolor<0?White:trcolor:-1);
        bm.UnlockBits(bd);
        return map;
      }
      public static bool IsAlpha(Bitmap b) { return b!=null&&0!=(b.PixelFormat&PixelFormat.Alpha);}
      public int[] CopyBitmap(Bitmap bm,int x,int y,int trcolor,bool trx,int diffmode,int mixlevel,int filter) {
        if(bm==null||x>=Width||y>=Height||x+bm.Width<=0||y+bm.Height<=0) return null;
        int[] sel=new int[] {x,y,x+bm.Width-1,y+bm.Height-1};
        if(!R.Intersect(sel,0,0,Width-1,Height-1)) return null;
        bool alpha=IsAlpha(bm),mix=mixlevel>0,xor=diffmode==1,diff=diffmode>1,fil=filter!=-1,filb=0!=(filter&0x1000000);
        Rectangle r=new Rectangle(sel[0]-x,sel[1]-y,sel[2]-sel[0]+1,sel[3]-sel[1]+1);
        BitmapData bd=bm.LockBits(r,ImageLockMode.ReadOnly,alpha?PixelFormat.Format32bppArgb:PixelFormat.Format32bppRgb);
        int g=sel[1]*Width+sel[0],n=sel[2]-sel[0]+1,stride=bd.Stride;
        long h=bd.Scan0.ToInt64();
        bool tr=trcolor!=-1;
        trx&=tr;
        int[] buf=alpha||diff||xor||tr||mix||fil?new int[n]:null,prev=trx?new int[n]:null,next=trx?new int[n]:null;
        trcolor&=White;
        if(next!=null) Marshal.Copy(new IntPtr(h),next,0,n);
        for(y=sel[1];y<=sel[3];y++) {
          if(buf==null) {
            Marshal.Copy(new IntPtr(h),Data,g,n);
          } else {
            if(prev!=null) Array.Copy(buf,prev,buf.Length);
            if(next!=null) {
              Array.Copy(next,buf,buf.Length);
              if(y<sel[3]) Marshal.Copy(new IntPtr(h+stride),next,0,n);
            } else
              Marshal.Copy(new IntPtr(h),buf,0,n);
            for(int i=0;i<n;i++) {
              int c=buf[i]&White;              
              if(!tr||c!=trcolor) {
                int c2;
                if(fil) {
                  c2=Data[g+i]&White;
                  if(filter>=0?c2!=filter:c2==(filter&White)||(filb&&c2==0)) continue;
                }
                if(alpha) {
                  int a=(buf[i]>>24)&255;
                  if(a==0) continue;
                  c=Palette.RGBMix(Data[g+i],c,a,255);
                }
                if(diff) {
                  c2=Data[g+i]&White;
                  bool eq=c==c2;
                  switch(diffmode) {
                   default:
                   case 2:c2=Palette.ColorIntensity765(c2,c==c2?511+Palette.RGBSum(c2)/3:Palette.RGBSum(Palette.RGBMix(c,c2,1,2))/3);break;
                   case 3:c2=Palette.ColorIntensity765(eq?c2:0xff0000,eq?511+Palette.RGBSum(c2)/3:Palette.RGBSum(Palette.RGBMix(c,c2,1,2))/3);break;
                   case 4:c2=Palette.ColorIntensity765(0,765-Palette.RGBSum(Palette.RGBDiff(c,c2)));break;
                   case 5:c2=Palette.RGBMin(c,c2);break;
                   case 6:c2=Palette.RGBMix(c,c2,1,2);break;
                   case 7:c2=Palette.RGBMax(c,c2);break;
                   case 8:c2=Palette.RGBEmbo(c,c2,4);break;
                   case 9:c2=Palette.RGBXmix(c,c2);break;
                   case 10:c2=White^Palette.RGBDiff(c,c2,4);break;
                   case 11:c2=White^Palette.RGBSqrt(c,c2,4);break;
                  }
                } else 
                  c2=xor?White^c^Data[g+i]:mix?Palette.RGBMix(Data[g+i],c,mixlevel,100):c;
                if(trx) {
                  int a=0,b=0,ab;
                  bool u=y>sel[1],d=y<sel[3];
                  if(u&&(prev[i]&White)==trcolor) a++;
                  if(d&&(next[i]&White)==trcolor) a++;
                  if(i>0) {
                    if((buf[i-1]&White)==trcolor) a++;
                    if(u&&(prev[i-1]&White)==trcolor) b++;
                    if(d&&(next[i-1]&White)==trcolor) b++;
                  }
                  if(i<n-1) {
                    if((buf[i+1]&White)==trcolor) a++;
                    if(u&&(prev[i+1]&White)==trcolor) b++;
                    if(d&&(next[i+1]&White)==trcolor) b++;
                  }
                  ab=(a>0?85:0)+(b>0?85:0);
                  c2=Palette.RGBMix(c,Data[g+i],ab,255);
                }
                Data[g+i]=c2&White;
              }
            }
          }
          g+=Width;h+=stride;
        }
        if(buf==null) AndOr(White,0,sel[0],sel[1],sel[2],sel[3]);
        bm.UnlockBits(bd);
        return sel;
      }
      public static void ToBitmap(bmap map,Bitmap bm,bool alpha) {
        Rectangle r=new Rectangle(0,0,bm.Width,bm.Height);                
        BitmapData bd=bm.LockBits(r,ImageLockMode.WriteOnly,alpha?PixelFormat.Format32bppArgb:PixelFormat.Format32bppRgb);
        for(int y=0;y<bd.Height;y++)
          Marshal.Copy(map.Data,(1+y)*map.Width+1,new IntPtr(bd.Scan0.ToInt64()+bd.Stride*y),bd.Width);
        bm.UnlockBits(bd);
        map.ClearByte();
      }      
      public static void ToBitmap(bmap map,int dx,int dy,Bitmap bm,int x0,int y0,int x1,int y1,bool alpha) {
        int e;
        if(x1<x0) {e=x0;x0=x1;x1=e;}
        if(y1<y0) {e=y0;y0=y1;y1=e;}
        if(x0<0) {dx-=x0;x0=0;}
        if(y0<0) {dy-=y0;y0=0;}
        if(x1>=bm.Width) x1=bm.Width-1;
        if(y1>=bm.Height) y1=bm.Height-1;
        if(dx<0) {x0-=dx;dx=0;}
        if(dy<0) {y0-=dy;dy=0;}
        int w=x1-x0+1,h=y1-y0+1;
        if(dx+w>map.Width) {w=map.Width-dx;x1=x0+w-1;}
        if(dy+h>map.Height) {h=map.Height-dy;y1=y0+h-1;}
        if(w<1||h<1||x0>=bm.Width||y0>=bm.Height||dx>=map.Width||dy>=map.Height) return;
        Rectangle r=new Rectangle(x0,y0,w,h);
        BitmapData bd=bm.LockBits(r,ImageLockMode.WriteOnly,alpha?PixelFormat.Format32bppArgb:PixelFormat.Format32bppRgb);
        for(int y=0;y<h;y++)
          Marshal.Copy(map.Data,(dy+y)*map.Width+dx,new IntPtr(bd.Scan0.ToInt64()+bd.Stride*y),w);
        bm.UnlockBits(bd);
      }
      
      public void Transparent(int color) {
        if(color<0) return;
        for(int i=0;i<Data.Length;i++) {
          int c=Data[i]&White;
          if(c==color) Data[i]&=White;
          else Data[i]|=255<<24;          
        }
      }

      //public static void ToBitmap(bmap map,Bitmap bm,int sx,int sy,int zoom,int border) {} 
      public static void Color(int c,out byte r,out byte g,out byte b) {
        r=(byte)(c&255);
        g=(byte)((c>>8)&255);
        b=(byte)((c>>16)&255);
      }
      public void Clear() { Clear(0xffffff);}
      public void Clear(int color) {
        for(int i=0;i<Data.Length;i++) Data[i]=color;
      }
      public void AndOr(int and,int or) {
        for(int i=0;i<Data.Length;i++) Data[i]=or|(and&Data[i]);
      }
      public void AndOr(int and,int or,int x0,int y0,int x1,int y1) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int h=y0*Width+x0;
          for(int he=h+x1-x0;h<=he;h++)
            Data[h]=or|(and&Data[h]);
          y0++;
        }        
      }      
      public void ClearByte() {
        for(int i=0;i<Data.Length;i++)
          Data[i]&=0xffffff;
      }
      public void ClearByte(int color) {
        if(color<0) { ClearByte();return;}
        int b0=color&255,b1=(color>>8)&255,b2=(color>>16)&255;
        for(int i=0;i<Data.Length;i++) {
          int a=(Data[i]>>24)&255;
          Data[i]&=0xffffff;          
          if(a<255) {
            int x=Data[i],b=255-a;
            int c0=(b*b0+a*(x&255))/255;
            int c1=(b*b1+a*((x>>8)&255))/255;
            int c2=(b*b2+a*((x>>16)&255))/255;
            Data[i]=c0|(c1<<8)|(c2<<16);
          }
        }
      }
      public void ClearByte(int x0,int y0,int x1,int y1,byte value) {
       for(int y=y0;y<=y1;y++)
         for(int x=x0,p=y*Width+x;x<=x1;x++,p++) 
           Data[p]=(value<<24)|(White&Data[p]);
      }
      public void ClearByte(int x0,int y0,int x1,int y1,bool neq,int color) {
       color&=White;
       for(int y=y0;y<=y1;y++)
         for(int x=x0,p=y*Width+x;x<=x1;x++,p++) {
           int c=Data[p]&White;
           byte b=(byte)((c==color)^neq?1:0);
           Data[p]=(b<<24)|c;
         }
      }
      public void RectByte(int x0,int y0,int x1,int y1,byte value) {
       for(int x=x0,p0=y0*Width+x,p1=y1*Width+x;x<=x1;x++,p0++,p1++) {
         Data[p0]=(value<<24)|(White&Data[p0]);
         Data[p1]=(value<<24)|(White&Data[p1]);
       }
       for(int y=y0,p0=y0*Width+x0,p1=y0*Width+x1;y<=y1;y++,p0+=Width,p1+=Width) {
         Data[p0]=(value<<24)|(White&Data[p0]);
         Data[p1]=(value<<24)|(White&Data[p1]);
       }
      }
      public void Border(int color) {
        for(int x=0;x<Width;x++)
          Data[x]=Data[Data.Length-1-x]=color;
        int h=0,g=Width-1;
        for(int y=0;y<Height;y++) {
          Data[h]=Data[g]=color;
          h+=Width;g+=Width;
        }
      }
      public void Border() {
        for(int x=0,x2=(Height-1)*Width;x<Width;x++,x2++) {
          Data[x]=Data[x+Width];
          Data[x2]=Data[x2-Width];
        }
        for(int y=0,h=0,g=Width-1;y<Height;y++) {
          Data[h]=Data[h+1];
          Data[g]=Data[g-1];
          h+=Width;g+=Width;
        }
      }
      int bitscan(int x) {
       unchecked {
        int r=0;
        ushort u;
        if(x==0) return -1;
        if(0!=(x&0xffff0000)) {r=16;u=(ushort)(x>>16);} else u=(ushort)x;
        if(0!=(u&0xff00)) {r+=8;u>>=8;}
        if(0!=(u&0xf0)) {r+=4;u>>=4;}
        if(0!=(u&0xc)) {r+=2;u>>=2;}
        return r+(u==3?1:u-1);
       }
      }
      
      public static int distance(int mode,int dx,int dy) {
        int d;      
        switch(mode) {
         case 6:d=Math.Abs(dx-dy);break; // \\
         case 5:d=Math.Abs(dx+dy);break; // //
         case 4:d=Math.Abs(dx);break;    // |
         case 3:d=Math.Abs(dy);break;    // -
         case 2:d=Math.Max(Math.Abs(dx),Math.Abs(dy));break; // []
         case 1:d=Math.Abs(dx)+Math.Abs(dy);break; // <>
         default:d=dx*dx+dy*dy;break; // O
        }
        return d;
      }
			public static int distance(int mode,int x,int y,int x0,int y0,int x1,int y1) {
			  x-=x0;y-=y0;
				int dx=x1-x0,dy=y1-y0;
				if(dx==0&&dy==0) return distance(mode,x,y);				
				int a=x*dx+y*dy,d=dx*dx+dy*dy;
				if(a<0) return distance(mode,x,y);
				if(a>d) return distance(mode,x-dx,y-dy);
				int nx=(int)((long)dx*a/d),ny=(int)((long)dy*a/d);
				return distance(mode,x-nx,y-ny);
			}
			public static int distance(int mode,int x,int y,PointPath dxy) {
			  if(dxy.Count<1) return 0;
				PathPoint pp=dxy[dxy.Count-1],pp2;

				int d=distance(mode,x-pp.x,y-pp.y);
			  if(dxy.Count<2) return d;
				pp.stop=!dxy.Closed;
				for(int i=0;i<dxy.Count;i++) { 
				  pp2=pp;pp=dxy[i];
					int d2=pp2.stop?distance(mode,x-pp.x,y-pp.y):distance(mode,x,y,pp2.x,pp2.y,pp.x,pp.y);
				  //int d2=distance(mode,x-dxy[i],y-dxy[i+1]);
					if(d2<d) d=d2;
				}
				return d;  
			}

      public fillres FloodFill(int[] pxy,int color1,int color2,bool x8,bool noblack,int mode,bool fill2black,PointPath gxy,bool zero,FillPattern pattern) {        
        if(pattern!=null&&(pattern.BMap==null||!pattern.Enabled)) pattern=null;
        if(mode<0&&pxy.Length>4) { int e;e=pxy[0];pxy[0]=pxy[pxy.Length-4];pxy[pxy.Length-4]=e;e=pxy[1];pxy[1]=pxy[pxy.Length-3];pxy[pxy.Length-3]=e;}
        int x=pxy[0],y=pxy[1];
        fillres res=new fillres() {x0=x,y0=y,x1=x,y1=y,m=0};
        if(x<1||x>=Width-1||y<1||y>=Height-1) return res;
        int xy=(y<<16)+x;
        int px=y*Width+x,px2;
        int clr=Data[px];
				int gx=gxy[0].x,gy=gxy[0].y;
				bool multg=gxy.Count>1;
        if(noblack&&(clr&0xffffff)==0) return res;        
        Border(fill2black?0:0x7fffffff);
        int[] fifo=new int[Width*Height];
        int n=0,m=0,max=distance(mode,x,y,gxy),min=zero?0:max,d;
        fifo[m++]=xy;
        Data[px]=-1;
        bool grad=color1!=color2&&(pattern==null||pattern.TrColor>=0)&&mode>=0;
        for(int i=2;i<pxy.Length;i+=2) {
          x=pxy[i];y=pxy[i+1];
          if(x<1||x>=Width-1||y<1||y>=Height-1) return res;          
          xy=(y<<16)+x;
          fifo[m++]=xy;
        }        
        while(n<m) {
          xy=fifo[n++];
          int x2=xy&65535,y2=(xy>>16),rd;
          if(!grad) d=1;          
          else {
					  d=multg?distance(mode,x2,y2,gxy):distance(mode,x2-gx,y2-gy);
            if(d>max) max=d;else if(d<min) min=d;
          }
          px=y2*Width+x2;
          rd=Data[(px2=px-Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65536;Data[px2]=-1;}
          rd=Data[(px2=px+Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65536;Data[px2]=-1;}
          rd=Data[(px2=px-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-1;Data[px2]=-1;}
          rd=Data[(px2=px+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+1;Data[px2]=-1;}
          if(x8) {
            rd=Data[(px2=px-Width-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65537;Data[px2]=-1;}
            rd=Data[(px2=px-Width+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy-65535;Data[px2]=-1;}
            rd=Data[(px2=px+Width-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65535;Data[px2]=-1;}
            rd=Data[(px2=px+Width+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=xy+65537;Data[px2]=-1;}
          }
        }
        n=0;
        bool sqr=mode<1||mode>6;        
        int[] cm=null;
        int[] radials=null;
        if(grad) {
          if(sqr) {min=isqrt(min);max=isqrt(max);}
          cm=new int[max-min+1];
          for(int i=0;i<cm.Length;i++) cm[i]=Palette.RGBMix(color1,color2,i,max-min);        
        }
        if(mode==-2) {
          int gc=gxy.Count;
          int sx=gxy.pt[gc-1].x,sy=gxy.pt[gc-1].y;
          radials=new int[2+Math.Max(1,gxy.Count-1)];
          radials[0]=sx;radials[1]=sy;
          if(gc>1) {    
            sx=gxy.pt[gc-1].x;sy=gxy.pt[gc-1].y;
            for(int i=0;i<gc-1;i++)
              radials[2+i]=(int)(Math.Atan2(gxy.pt[i].y-sy,gxy.pt[i].x-sx)*32768/Math.PI);
          } else 
            radials[2]=(int)(Math.Atan2(pxy[1]-sy,pxy[0]-sx)*32768/Math.PI);
        }
        while(n<m) {
          xy=fifo[n++];
          int x2=xy&65535,y2=(xy>>16);
          if(x2<res.x0) res.x0=x2;else if(x2>res.x1) res.x1=x2;
          if(y2<res.y0) res.y0=y2;else if(y2>res.y1) res.y1=y2;
          px=y2*Width+x2;
          if(grad) {
            d=multg?distance(mode,x2,y2,gxy):distance(mode,x2-gx,y2-gy);
            if(sqr) d=isqrt(d);
            //Data[px]=Palette.ColorMix(color1,color2,d-min,max-min);
            Data[px]=cm[d-min];
          } else if(mode<0) {
            if(mode==-2) {
              int c,mc,a=(int)(Math.Atan2(y2-radials[1],x2-radials[0])*32768/Math.PI);
              if(radials.Length==3) {
                c=a-radials[2];
                if(c<0) c+=65536;
                if(c>32768) c=65536-c;
                mc=32768;
              } else {
                int lo=a-65536,hi=a+65536;
                for(int i=2;i<radials.Length;i++) {
                  int r=radials[i],rlo=r,rhi=r;
                  if(rlo>a) rlo-=65536;if(rhi<a) rhi+=65536;
                  if(rlo>lo) lo=rlo;
                  if(rhi<hi) hi=rhi;
                }
                mc=hi-lo;
                int mi=lo+hi;
                a*=2;
                if(a<=mi) c=a-2*lo;else c=2*hi-a;
              }
              Data[px]=Palette.RGBMix(color1,color2,c,mc);
            } else {
              int ax=pxy[0],ay=pxy[1],bx=gx,by=gy,cx=bx,cy=by;
              if(gxy.Count>1) {
                ax=bx;ay=gy;cx=bx=gxy.pt[1].x;cy=by=gxy.pt[1].y;
                if(gxy.Count>2) {
                  bool b=gxy[1].stop;
                  cx=gxy.pt[2].y-(b?ay:by);cy=-(gxy.pt[2].x-(b?ax:bx));
                  if(cx*(bx-ax)+cy*(by-ay)<0) {cx=-cx;cy=-cy;}
                  cx+=ax;cy+=ay;
                }
              }
              int dx=x2-ax,dy=y2-ay;
              int sx=cx-ax,sy=cy-ay,sxy=sx*(bx-ax)+sy*(by-ay);
              int dxy=dx*sx+dy*sy;
              Data[px]=dxy<=0?color2:dxy>=sxy?color1:Palette.RGBMix(color2,color1,dxy,sxy);
            }
          } else 
            Data[px]=color1;
          if(pattern!=null) {
            int rc=pattern.Color(x2,y2);
            if(rc>=0) Data[px]=rc;
          }
        }
        res.m=m;
        return res;
      }      
      public fillres FloodFill1(int x,int y,bool x8,int[] rect,int incolor,int bcolor,int outcolor) {
			  if(!R.Intersect(rect,0,0,Width-1,Height-1)) return new fillres();
        if(incolor==-1&&bcolor==-1&&outcolor==-1) return new fillres();
        int sx0=0,sy0=0,sx1=Width-1,sy1=Height-1;
				if(rect!=null) {sx0=rect[0];sy0=rect[1];sx1=rect[2];sy1=rect[3];}
        int color=XY(x,y)&White;
        if((incolor<0||incolor==color)&&(bcolor<0||bcolor==color)&&outcolor<0) return new fillres();
        int w=sx1-sx0+1,h=sy1-sy0+1;
        int[] fifo=new int[w*h];
        int n=0,m=1;
        fifo[0]=(y<<16)|x;        
        fillres res=new fillres() {x0=x,y0=y,x1=x,y1=y,m=0};
        while(n<m) {
          int xy=fifo[n++],ry=xy>>16,rx=xy&65535,r=ry*Width+rx,r2;
          if(Data[r]==-1) continue;
          Data[r]=-1;
          int mi=0,ma=0;
          while(rx+mi>sx0&&Data[r2=r+mi-1]==color) {mi--;fifo[m++]=xy+mi;Data[r2]=-1;}
          while(rx+ma<sx1&&Data[r2=r+ma+1]==color) {ma++;fifo[m++]=xy+ma;Data[r2]=-1;}
          if(x8&&rx+mi>sx0) mi--;
          if(x8&&rx+ma<sx1) ma++;
          for(int i=mi;i<=ma;i++) {
            if(ry>sy0&&Data[r2=r-Width+i]==color) {fifo[m++]=xy-65536+i;Data[r2]=-2;}
            if(ry<sy1&&Data[r2=r+Width+i]==color) {fifo[m++]=xy+65536+i;Data[r2]=-2;}
          }
        }
        if(bcolor<0) bcolor=color;
        if(incolor<0) incolor=color;
        bool oc=outcolor>=0,mark=oc||bcolor>=0&&bcolor!=incolor;        
        if(mark) {bcolor|=(1<<24);incolor|=(1<<24);}
        w=Width;
        for(n=0;n<m;n++) {
          bool b=false;        
          int r=fifo[n],rx=r&65535,ry=(r>>16),r2;
          r=ry*Width+rx;
          if(mark) {
            if(rx>sx0&&0==(Data[r2=r-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(rx<sx1&&0==(Data[r2=r+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(ry>sy0&&0==(Data[r2=r-w]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(ry<sy1&&0==(Data[r2=r+w]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
            if(x8) {
              if(ry>sy0) {
                if(rx>sx0&&0==(Data[r2=r-w-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
                if(rx<sx1&&0==(Data[r2=r-w+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
              }
              if(ry<sy1) {
                if(rx>sx0&&0==(Data[r2=r+w-1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
                if(rx<sx1&&0==(Data[r2=r+w+1]&(255<<24))) {b=true;if(oc) Data[r2]=outcolor;}
              }
            }
          }
          Data[r]=b?bcolor:incolor;
          if(mark) fifo[n]=r;
        }
        if(mark) for(n=0;n<m;n++) {
          int r=fifo[n];
          Data[r]&=White;
        }
        return res;
      }
      public fillres FloodFill0(int x,int y,bool x8,int[] rect) {
			  if(!R.Intersect(rect,0,0,Width-1,Height-1)) return new fillres();
        int sx0=0,sy0=0,sx1=Width-1,sy1=Height-1;
				if(rect!=null) {sx0=rect[0];sy0=rect[1];sx1=rect[2];sy1=rect[3];}
        int w=sx1-sx0+1,h=sy1-sy0+1;
        int[] fifo=new int[w*h];
        int n=0,m=1;
        fifo[0]=(y<<16)|x;
        int color=XY(x,y)&White;
        Data[y*Width+x]|=c24;
        ClearByte(sx0,sy0,sx1,sy1,0);
        fillres res=new fillres() {x0=x,y0=y,x1=x,y1=y,m=0};
        while(n<m) {
          int xy=fifo[n++],ry=xy>>16,rx=xy&65535,r=ry*Width+rx,r2;
          if(rx<res.x0) res.x0=rx;else if(rx>res.x1) res.x1=rx;
          if(ry<res.y0) res.y0=ry;else if(ry>res.y1) res.y1=ry;
          int mi=0,ma=0;          
          while(rx+mi>sx0&&Data[r2=r+mi-1]==color) {mi--;fifo[m++]=xy+mi;Data[r2]|=c24;}
          while(rx+ma<sx1&&Data[r2=r+ma+1]==color) {ma++;fifo[m++]=xy+ma;Data[r2]|=c24;}
          if(x8&&rx+mi>sx0) mi--;
          if(x8&&rx+ma<sx1) ma++;
          for(int i=mi;i<=ma;i++) {
            if(ry>sy0&&Data[r2=r-Width+i]==color) {fifo[m++]=xy-65536+i;Data[r2]|=c24;}
            if(ry<sy1&&Data[r2=r+Width+i]==color) {fifo[m++]=xy+65536+i;Data[r2]|=c24;}
          }
        }
        res.m=m;
        return res;
      }
      public fillres ColorExtent(int x,int y,int[] rect) {
			  if(!R.Intersect(rect,0,0,Width-1,Height-1)) return new fillres();
        int sx0=0,sy0=0,sx1=Width-1,sy1=Height-1;
				if(rect!=null) {sx0=rect[0];sy0=rect[1];sx1=rect[2];sy1=rect[3];}        
        int color=XY(x,y)&White;
        fillres res=new fillres() {y0=x,y1=y,m=0};        
        for(;x>sx0&&(XY(x-1,y)&White)==color;x--);
        res.x0=x;
        for(x=res.y0;x<sx1&&(XY(x+1,y)&White)==color;x++);
        res.x1=x;
        for(x=res.y0;y>sy0&&(XY(x,y-1)&White)==color;y--);
        res.y0=y;
        for(y=res.y1;y<sy1&&(XY(x,y+1)&White)==color;y++);
        res.y1=y;
        return res;
      }
      public byte[] BorderMask(int x0,int y0,int x1,int y1) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return null;
        int w=x1-x0+1,h=y1-y0+1;
        if(w<3||h<3) return null;
        byte[] mask=new byte[w*h];
        short[] fifo=new short[2*w*h];
        int n=0,m=0,offset=y0*Width+x0;
        for(int i=0;i<w;i++) mask[i]=mask[w*(h-1)+i]=1;
        for(int i=1;i+1<h;i++) mask[i*w]=mask[i*w+w-1]=1;
        for(int i=1;i+1<w;i++) {
          int p;
          p=offset+i;if((Data[p]&White)==(Data[p+Width]&White)) {mask[i+w]=1;fifo[m++]=(short)i;fifo[m++]=1;}
          p+=(h-1)*Width;if((Data[p]&White)==(Data[p-Width]&White)) {mask[w*(h-2)+i]=1;fifo[m++]=(short)i;fifo[m++]=(short)(h-2);}
        }
        for(int i=2;i+2<h;i++) {
          int p;
          p=offset+i*Width;if((Data[p]&White)==(Data[p+1]&White)) {mask[i*w+1]=1;fifo[m++]=1;fifo[m++]=(short)i;}
          p+=w-1;if((Data[p]&White)==(Data[p-1]&White)) {mask[i*w+w-2]=1;fifo[m++]=(short)(w-2);fifo[m++]=(short)i;}
        }
        while(n<m) {
          int x=fifo[n++],y=fifo[n++],p=offset+y*Width+x,b=y*w+x,b2,c=Data[p]&White;
          if(mask[b2=b-1]==0&&(Data[p-1]&White)==c) { fifo[m++]=(short)(x-1);fifo[m++]=(short)y;mask[b2]=1;}
          if(mask[b2=b+1]==0&&(Data[p+1]&White)==c) { fifo[m++]=(short)(x+1);fifo[m++]=(short)y;mask[b2]=1;}
          if(mask[b2=b-w]==0&&(Data[p-Width]&White)==c) { fifo[m++]=(short)x;fifo[m++]=(short)(y-1);mask[b2]=1;}
          if(mask[b2=b+w]==0&&(Data[p+Width]&White)==c) { fifo[m++]=(short)x;fifo[m++]=(short)(y+1);mask[b2]=1;}
        }
        if(m==2*(w-1)*(h-1)) return null;
        return mask;
      }
      const int c24=0x1000000;
      int FillDiffStep(int[] fifo,int p,int mode,int diff,bool center,int color) {
        int n=0,m=0,p2,c,c2,c0;
        fifo[m++]=p;
        c0=Data[p]|c24;
        bool rgbavg=color<-1;
        if(color<0) color=c0;
        Data[p]=color;
        int s0=0,s1=0,s2=0;
        while(n<m) {
          p=fifo[n++];
          c=center?c0:Data[p];
          if(rgbavg) Palette.RGBAdd(Data[p],ref s0,ref s1,ref s2);
          else Data[p]=c0;
          if(0==(c24&(c2=Data[p2=p-1]))&&!Palette.RGBDiff(mode,diff,c,c2)) { fifo[m++]=p2;Data[p2]|=c24;}
          if(0==(c24&(c2=Data[p2=p+1]))&&!Palette.RGBDiff(mode,diff,c,c2)) { fifo[m++]=p2;Data[p2]|=c24;}
          if(0==(c24&(c2=Data[p2=p-Width]))&&!Palette.RGBDiff(mode,diff,c,c2)) { fifo[m++]=p2;Data[p2]|=c24;}
          if(0==(c24&(c2=Data[p2=p+Width]))&&!Palette.RGBDiff(mode,diff,c,c2)) { fifo[m++]=p2;Data[p2]|=c24;}
        }
        if(rgbavg) {
          n=0;
          c0=Palette.RGBAvg(m,s0,s1,s2)|c24;
          while(n<m)
            Data[fifo[n++]]=c0;
        }
        return m;
      }

      public int FillDiff(int x,int y,int mode,int diff,bool center,int color) {
        if(x<1||x+1>=Width||y<1||y+1>=Height||diff<1) return 0;
        ClearByte();
        Border(c24);
        int[] fifo=new int[Width*Height];
        int s=FillDiffStep(fifo,y*Width+x,mode,diff,center,color);
        ClearByte();
        return s;
      }
      public void FillDiff(int x0,int y0,int x1,int y1,int mode,int diff,bool center,bool rgbavg) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        ClearByte(x0,y0,x1,y1,0);
        RectByte(x0-1,y0-1,x1+1,y1+1,1);
        int[] fifo=new int[Width*Height];
        for(int y=y0;y<=y1;y++)
          for(int x=x0,p;x<=x1;x++)
            if(0==(Data[p=y*Width+x]&c24))              
              FillDiffStep(fifo,p,mode,diff,center,rgbavg?-2:-1);
      }
      public void ReplDiff(int x0,int y0,int x1,int y1,int mode,int diff) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        int w=x1-x0+1,h=y1-y0+1,wh=w*h,pe,y,p,i;
        int[] map=new int[wh];
        for(y=y0,i=0;y<=y1;y++)
          for(p=Width*y+x0,pe=p+w;p<pe;p++)
            map[i++]=p;
        for(int n=0,m=map.Length;n<m;) {
          int m2=m,c,s0=0,s1=0,s2=0,c2;
          p=map[n];c=Data[p];
          map[n]=map[--m];map[m]=p;
          Palette.RGBAdd(c,ref s0,ref s1,ref s2);
          for(i=n;i<m;) { 
            p=map[i];
            c2=Data[p];
            if(Palette.RGBDiff(mode,diff,c,c2)) i++;
            else {
              map[i]=map[--m];map[m]=p; 
              Palette.RGBAdd(c2,ref s0,ref s1,ref s2);
            }
          }
          c=Palette.RGBAvg(m2-m,s0,s1,s2);
          while(m2>m) {
            p=map[--m2];
            Data[p]=c;
          }
        }        
      }

      public fillres RemoveColor(int color,bool x8,bool repeat,int x0,int y0,int x1,int y1) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        Border(color);
        color&=White;
        ClearByte(x0,y0,x1,y1,true,color);
        RectByte(x0-1,y0-1,x1+1,y1+1,1);
        int c24=1<<24,c25=1<<25,h2,h=0,m=0,he;
        int[] fifo=new int[(x1-x0+1)*(y1-y0+1)];
        for(int px,y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(int x=x0;x<=x1;x++,px++) {
            int c=Data[px];
            if(0!=(c&c24)) continue;
            bool edge=0!=(c24&(Data[px-1]|Data[px+1]|Data[px-Width]|Data[px+Width]));
            if(!edge&&x8) edge=0!=(c24&(Data[px-Width-1]|Data[px-Width+1]|Data[px+Width-1]|Data[px+Width+1]));
            if(edge) {fifo[m++]=px;Data[px]|=c25;}
          }
        }
       loop:
        for(h2=h,he=m;h<he;) {
          int px2,px=fifo[h++];
          int s0=0,s1=0,s2=0,c2,n=0;              
          if(((c2=Data[px2=px-1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
          if(((c2=Data[px2=px+1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
          if(((c2=Data[px2=px-Width])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
          if(((c2=Data[px2=px+Width])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
          if(x8) {
            if(((c2=Data[px2=px-Width-1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
            if(((c2=Data[px2=px-Width+1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
            if(((c2=Data[px2=px+Width-1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
            if(((c2=Data[px2=px+Width+1])&c24)!=0) {n++;Palette.RGBAdd(c2,ref s0,ref s1,ref s2);} else if(0==(c2&c25)) {fifo[m++]=px2;Data[px2]|=c25;}
          }
          if(n==0) Data[px]=c25;
          else Data[px]=Palette.RGBAvg(n,s0,s1,s2)|c25;
        }
        for(h=h2;h<he;)
          Data[fifo[h++]]^=c24|c25;
        if(repeat&&m>he) goto loop;
        ClearByte(x0-1,y0-1,x1+1,y1+1,0);
        return res;
      }
      public fillres Replace(int search,int replace,int x0,int y0,int x1,int y1) { return Replace(search,replace,x0,y0,x1,y1);}
      public fillres Replace(int search,int replace,int x0,int y0,int x1,int y1,FillPattern pattern) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px,clr=search&White;
        for(int y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(int x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(c!=clr) continue;
            if(pattern!=null) {
              c=pattern.Color(x,y);
              if(c<0) continue;
              Data[px]=c;
            } else {
              Data[px]=replace;
            }
            
            if(res.m==0) { 
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;              
            }
            res.m++;
          }
        }
        return res;
      }
      public fillres ReplaceDiff(int search,int replace,int mode,int level,int x0,int y0,int x1,int y1) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px,clr=search&White;
        for(int y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(int x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(Palette.RGBDiff(mode,level,c,clr)) continue;
            Data[px]=replace;
            if(res.m==0) { 
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;              
            }
            res.m++;
          }
        }
        return res;
      }
      public fillres Replace(int search,bool x8,int incolor,int bcolor,int outcolor,bmap src,int x0,int y0,int x1,int y1) {
        if(outcolor==search) outcolor=-1;if(incolor==search) incolor=-1;if(bcolor==search) bcolor=-1;
        if(outcolor==-1&&incolor==bcolor) return Replace(search,incolor,x0,y0,x1,y1);
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px;
        search&=White;
        src.ClearByte();
        for(int y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(int x=x0;x<=x1;x++,px++) {
            int c=Data[px]&White;
            if(c!=search) {
              if(outcolor<0) continue;
              bool o=src.Data[px-1]==search||src.Data[px+1]==search||src.Data[px-Width]==search||src.Data[px+Width]==search;
              if(!o&&x8) o=src.Data[px-Width-1]==search||src.Data[px-Width+1]==search||src.Data[px+Width-1]==search||src.Data[px+Width+1]==search;
              if(o) Data[px]=outcolor;
            } else {
              bool b=src.Data[px-1]!=search||src.Data[px+1]!=search||src.Data[px-Width]!=search||src.Data[px+Width]!=search;
              if(!b&&x8) b=src.Data[px-Width-1]!=search||src.Data[px-Width+1]!=search||src.Data[px+Width-1]!=search||src.Data[px+Width+1]!=search;
              if(b&&bcolor>=0) Data[px]=bcolor;
              else if(!b&&incolor>=0) Data[px]=incolor;
              else continue;
            }
            if(res.m==0) { 
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;              
            }
            res.m++;
          }
        }
        return res;
      }
      public fillres Replace(int x,int y,int color1,int color2,bool noblack,int mode,int gx,int gy,bool zero,int x0,int y0,int x1,int y1,bool bmask) {
        fillres res=new fillres() {x0=x0,y0=y0,x1=x1,y1=y1,m=0};
        if(x<1||x>=Width-1||y<1||y>=Height-1) return res;
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return res;
        int px=y*Width+x,d,min=0,max=0,w=x1-x0+1;
        int clr=Data[px]&White;
        if(noblack&&clr==0) return res;
        byte[] mask=null;
        if(bmask) {
          mask=BorderMask(x0,y0,x1,y1);
          if(mask==null) return res;
        }
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            if(mask!=null&&mask[x-x0+(y-y0)*w]==1) continue;
            int c=Data[px]&White;
            if(c!=clr) continue;
            d=distance(mode,x-gx,y-gy);
            if(res.m==0) {
              min=zero?0:d;              
              max=d;
              res.x0=res.x1=x;res.y0=res.y1=y;
            } else {
              if(d>max) max=d;
              else if(d<min) min=d;
              if(x<res.x0) res.x0=x;else if(x>res.x1) res.x1=x;
              if(y<res.y0) res.y0=y;else if(y>res.y1) res.y1=y;
            }
            res.m++;
          }
        }
        bool sqr=mode<1||mode>6;        
        if(sqr) {min=isqrt(min);max=isqrt(max);}
        int[] cm=new int[max-min+1];
        for(int i=0;i<cm.Length;i++) cm[i]=Palette.RGBMix(color1,color2,i,max-min);                
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            if(mask!=null&&mask[x-x0+(y-y0)*w]==1) continue;
            int c=Data[px]&White;
            if(c!=clr) continue;
            d=distance(mode,x-gx,y-gy);
            if(sqr) d=isqrt(d);
            Data[px]=cm[d-min];
          }
        }        
        return res;  
      }
      public void Colorize(int cmode,int color1,int color2,int gmode,int gx,int gy,bool zero,int x0,int y0,int x1,int y1,bool bmask) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        int x,y,px,d,min=0,max=0,w=x1-x0+1;
        if(x0<=gx&&gx<=x1&&y0<=gy&&gy<=y1) zero=true;
        byte[] mask=null;
        if(bmask) {
          mask=BorderMask(x0,y0,x1,y1);
          if(mask==null) return;
        }
        bool first=true;
        //d=distance(gmode,x0-gx,y0-gy);
        //max=d;min=zero?0:d;
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            if(mask!=null&&mask[x-x0+(y-y0)*w]==1) continue;
            d=distance(gmode,x-gx,y-gy);
            if(first) { first=false;max=d;min=zero?0:d;}
            else {
              if(d>max) max=d;else if(!zero&&d<min) min=d;
            }
          }
        }
        bool sqr=gmode<1||gmode>6;        
        if(sqr) {min=isqrt(min);max=isqrt(max);}
        int[] cm=new int[max-min+1];
        for(int i=0;i<cm.Length;i++) cm[i]=Palette.RGBMix(color1,color2,i,max-min);                
        for(y=y0;y<=y1;y++) {
          px=y*Width+x0;
          for(x=x0;x<=x1;x++,px++) {
            if(mask!=null&&mask[x-x0+(y-y0)*w]==1) continue;
            d=distance(gmode,x-gx,y-gy);
            if(sqr) d=isqrt(d);
            int c=cm[d-min],p=Data[px]&White;
            Data[px]=Palette.Colorize(cmode,c,p);
          }
        }        
      }      
      
      // path gradient
      public int FloodFillGrad(int[] xy,int color1,int color2,bool border,bool d8,bool x8,bool noblack,bool fill2black) {
        int x=xy[0],y=xy[1];
        if(x<1||x>=Width-1||y<1||y>=Height-1) return 0;
        int px=y*Width+x,px2;
        int clr=Data[px];
        if(noblack&&(clr&0xffffff)==0) return 0;
        Border(fill2black?0:0x7fffffff);
        int[] fifo=new int[Width*Height];        
        int n=0,m=0,k=0,xyi=2;
        int d=-1,md=d;
        bool dual=d8!=x8&&!border;
       np:
        fifo[m++]=px;
        Data[px]=d;                
        if(xyi<xy.Length-1) {
         sp: 
          x=xy[xyi++];y=xy[xyi++];
          if(x<1||x>=Width-1||y<1||y>=Height-1) goto sp;
          px=y*Width+x;
          goto np;
        }
        k=m;
        d--;
        while(n<m) {
          px=fifo[n++];
          int d2=Data[px]-1;
          if(dual&&d2!=d) k=m;
          d=d2;
          bool fl=false,fr=false,ft=false,fb=false;
          int rd;
          rd=Data[(px2=px-Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;ft=true;}
          rd=Data[(px2=px+Width)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fb=true;}
          rd=Data[(px2=px-1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fl=true;}
          rd=Data[(px2=px+1)];if(fill2black?rd>0:rd==clr) {fifo[m++]=px2;Data[px2]=d;fr=true;}
          if(x8||d8) {
            if(!d8) d--;
            if(x8&&!d8) {
              if(!fl&&Data[px-1]<0) fl=true;
              if(!fr&&Data[px+1]<0) fr=true;
              if(!ft&&Data[px-Width]<0) ft=true;
              if(!fb&&Data[px+Width]<0) fb=true;
            }            
            rd=Data[(px2=px-Width-1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!ft&&!fl:ft||fl)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px-Width+1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!ft&&!fr:ft||fr)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px+Width-1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!fb&&!fl:fb||fl)) {fifo[m++]=px2;Data[px2]=d;}
            rd=Data[(px2=px+Width+1)];if((fill2black?rd>0:rd==clr)&&(x8?d8||!fb&&!fr:fb||fr)) {fifo[m++]=px2;Data[px2]=d;}
            if(!d8) d++;
          }
        }
        if(border) {
          n=0;
          d=-1;          
          unchecked { clr=(int)0x80000001;}         
          for(int i=0;i<m;i++) {
            px=fifo[i];
            bool go=Data[px-1]>=0||Data[px+1]>=0||Data[px+Width]>=0||Data[px-Width]>=0;
            if(!go&&x8&&(Data[px-Width-1]>=0||Data[px-Width+1]>=0||Data[px+Width-1]>=0||Data[px+Width+1]>=0)) go=true;
            if(go) {
              fifo[n++]=px;
              Data[px]=d;
            } else
              Data[px]=clr;
          }
          k=m=n;
          n=0;
          dual=d8!=x8;
          d--;
          while(n<m) {
            px=fifo[n++];
            int d2=Data[px]-1;
            if(dual&&d2!=d) k=m;
            d=d2;
            bool fl=false,fr=false,ft=false,fb=false;
            if(Data[(px2=px-Width)]==clr) {fifo[m++]=px2;Data[px2]=d;ft=true;};
            if(Data[(px2=px+Width)]==clr) {fifo[m++]=px2;Data[px2]=d;fb=true;};
            if(Data[(px2=px-1)]==clr) {fifo[m++]=px2;Data[px2]=d;fl=true;};
            if(Data[(px2=px+1)]==clr) {fifo[m++]=px2;Data[px2]=d;fr=true;};
            if(x8||d8) {
              if(!d8) d--;
              if(x8&&!d8) {
                if(!fl&&Data[px-1]<0) fl=true;
                if(!fr&&Data[px+1]<0) fr=true;
                if(!ft&&Data[px-Width]<0) ft=true;
                if(!fb&&Data[px+Width]<0) fb=true;
              }
              if(Data[(px2=px-Width-1)]==clr&&(x8?d8||!ft&&!fl:ft||fl)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px-Width+1)]==clr&&(x8?d8||!ft&&!fr:ft||fr)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px+Width-1)]==clr&&(x8?d8||!fb&&!fl:fb||fl)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};
              if(Data[(px2=px+Width+1)]==clr&&(x8?d8||!fb&&!fr:fb||fr)) {if(d8&&!x8) { if(k==m) m++;else fifo[m++]=fifo[k];fifo[k++]=px2;} else fifo[m++]=px2;Data[px2]=d;};              
              if(!d8) d++;
            }            
          }
        }
        d=-d;
        for(n=0;n<m;n++) {
          px=fifo[n];
          int d2=-Data[px];
          Data[px]=Palette.RGBMix(color1,color2,d2-1,d-1);
        }
        return m;      
      }
      internal void Expand(bool x8,bool wonly,bmap src,int[] rect,int color,int incolor,int bcolor,int outcolor) {
			  if(!R.Intersect(rect,1,1,Width-1,Height-1)) return;
        if(src==null) src=Clone();
        src.Border(White);
        src.ClearByte();
        if(incolor==-1&&bcolor==-1&&outcolor==-1) return;
				int w=Width-2,h=Height-2;
				if(rect!=null) {w=rect[2]-rect[0]+1;h=rect[3]-rect[1]+1;}
				int i=rect!=null?rect[0]+Width*(rect[1]):Width+1;
        color&=White;
        for(int y=0;y<h;y++,i+=Width-w)
				  for(int e=i+w;i<e;i++) if(src.Data[i]==color) {
          if(incolor!=-1&&incolor!=color||bcolor!=-1&&bcolor!=color) {
            bool inner=src.Data[i-1]==color&&src.Data[i+1]==color&&src.Data[i-Width]==color&&src.Data[i+Width]==color;
            if(inner&&x8&&(src.Data[i-Width-1]!=color||src.Data[i-Width+1]!=color||src.Data[i+Width-1]!=color||src.Data[i+Width+1]!=color)) inner=false;
            if(inner&&incolor!=-1) Data[i]=incolor;
            if(!inner&&bcolor!=-1) Data[i]=bcolor;
          }
          if(outcolor!=-1) {
            if(wonly) {
              if(Data[i-1]==White) Data[i-1]=outcolor;
              if(Data[i+1]==White) Data[i+1]=outcolor;
              if(Data[i-Width]==White) Data[i-Width]=outcolor;
              if(Data[i+Width]==White) Data[i+Width]=outcolor;
							if(x8) {
								if(Data[i-Width-1]==White) Data[i-Width-1]=outcolor;
								if(Data[i-Width+1]==White) Data[i-Width+1]=outcolor;
								if(Data[i+Width-1]==White) Data[i+Width-1]=outcolor;
								if(Data[i+Width+1]==White) Data[i+Width+1]=outcolor;
							}
            } else if((incolor==outcolor&&bcolor==outcolor)||outcolor==color) {
              Data[i-1]=Data[i+1]=Data[i-Width]=Data[i+Width]=outcolor;
              if(x8) Data[i-Width-1]=Data[i-Width+1]=Data[i+Width-1]=Data[i+Width+1]=outcolor;
            } else {
              if(Data[i-1]!=color) Data[i-1]=outcolor;
              if(Data[i+1]!=color) Data[i+1]=outcolor;
              if(Data[i-Width]!=color) Data[i-Width]=outcolor;
              if(Data[i+Width]!=color) Data[i+Width]=outcolor;
							if(x8) {
								if(Data[i-Width-1]!=color) Data[i-Width-1]=outcolor;
								if(Data[i-Width+1]!=color) Data[i-Width+1]=outcolor;
								if(Data[i+Width-1]!=color) Data[i+Width-1]=outcolor;
								if(Data[i+Width+1]!=color) Data[i+Width+1]=outcolor;
							}
            }
          }
        }
      }
      internal void Impand(int[] rect,int color,int color2,byte mask,bool repeat) {
        if(color==color2) return;
			  if(!R.Intersect(rect,1,1,Width-1,Height-1)) return;
        bmap src=new bmap(this,rect[0],rect[1],rect[2],rect[3],1);
        ClearByte();
        mask&=15;
       repeat:
        for(int j=0;j<4;j++) {
          if(0==(mask&(1<<j))) continue;
          int n=0;
          src.CopyRectangle(this,rect[0],rect[1],rect[2],rect[3],1,1,-1);
          for(int y=1;y<src.Height-1;y++) {
            int h=y*src.Width+1,he=h+src.Width-2,xh=rect[0]-h;
            for(;h<he;h++) if(src.Data[h]==color) {
              bool go=false,l,r,u,d,lu,ld,ru,rd;
              l=src.Data[h-1]==color;r=src.Data[h+1]==color;u=src.Data[h-src.Width]==color;d=src.Data[h+src.Width]==color;
              lu=src.Data[h-src.Width-1]==color;ld=src.Data[h+src.Width-1]==color;
              ru=src.Data[h-src.Width+1]==color;rd=src.Data[h+src.Width+1]==color;
	            switch(j) {
	              case 0:if(!u&&d&&((ld&&l)||(rd&&r))&&!(l&&r&&!(ld||rd))&&!(lu&&!l)&&!(ru&&!r)) go=true;break;
	              case 1:if(!l&&r&&((ru&&u)||(rd&&d))&&!(u&&d&&!(ru||rd))&&!(lu&&!u)&&!(ld&&!d)) go=true;break;
	              case 2:if(!d&&u&&((lu&&l)||(ru&&r))&&!(l&&r&&!(lu||ru))&&!(ld&&!l)&&!(rd&&!r)) go=true;break;
	              case 3:if(!r&&l&&((lu&&u)||(ld&&d))&&!(u&&d&&!(lu||ld))&&!(ru&&!u)&&!(rd&&!d)) go=true;break;
	            }
              if(go) {
                n=1;
                Data[Width*(y+rect[1]-1)+h+xh]=color2;
              }
            }
          }
          if(n==0) mask&=(byte)(~(1<<j));
        }
        if(repeat&&mask!=0) {
          goto repeat;
        }
      }
      public void Mirror(bool vertical,bool horizontal) { 
        int x,y;
        if(vertical) {
          for(y=0;y<Height-y-1;y++) {
            int h=y*Width,g=(Height-y-1)*Width;
            for(x=0;x<Width;x++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g++;h++;
            }
          }
        } 
        if(horizontal) {
          for(x=0;x<Width-x-1;x++) {
            int h=x,g=(Width-x-1);
            for(y=0;y<Height;y++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g+=Width;h+=Width;
            }
          }
        }
      }
      public void Mirror(bool vertical,bool horizontal,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        if(x<0) x=0;if(x2>Width-1) x2=Width-1;
        if(y<0) y=0;if(y2>Height-1) y2=Height-1;
        if(vertical) {
          for(int z=y,z2=y2;z<z2;z++,z2--) {
            int h=z*Width+x,g=z2*Width+x;
            for(int i=x;i<=x2;i++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g++;h++;
            }
          }
        }         
        if(horizontal) {
          for(;x<x2;x++,x2--) {
            int h=y*Width+x,g=y*Width+x2;
            for(int i=y;i<=y2;i++) {
              int b;
              b=Data[g];Data[g]=Data[h];Data[h]=b;
              g+=Width;h+=Width;
            }
          }
        }         
      }
      public void Insert(bool vertical,bool horizontal,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>=Width||y>=Height||x2<0||y2<0) return;
        if(x<0) x=0;if(x2>Width-1) x2=Width-1;
        if(y<0) y=0;if(y2>Height-1) y2=Height-1;
        int h,g;
        if(vertical) {
          for(int a=Height-1;a>y;a--) {
            g=a*Width;h=(a>y2?a-y2+y-1:y)*Width;
            for(int b=0;b<Width;b++) Data[g++]=Data[h++];
          }
        }
        if(horizontal) {
          for(int a=Width-1;a>x;a--) {
            g=a;h=a>x2?a-x2+x-1:x;
            for(int b=0;b<Height;b++,g+=Width,h+=Width) Data[g]=Data[h];
          }
        }
      }
      public void Remove(bool vertical,bool horizontal,int x,int y,int x2,int y2,int mix,int miy,int max,int may) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(x>max||y>=may||x2<mix||y2<miy) return;
        if(x<mix) x=mix;if(x2>max) x2=max;
        if(y<miy) y=miy;if(y2>may) y2=may;
        int h,g;
        if(vertical) {
          for(int a=y;a<=may;a++) {
            g=a*Width;h=a+y2-y+1;if(h>may) h=may;h*=Width;
            g+=mix;h+=mix;
            for(int b=mix;b<=max;b++) Data[g++]=Data[h++];
          }
        }
        if(horizontal) {
          for(int a=x;a<max;a++) {
            g=a;h=a+x2-x+1;if(h>max) h=max;
            g+=miy*Width;h+=miy*Width;
            for(int b=miy;b<=may;b++,g+=Width,h+=Width) Data[g]=Data[h];
          }
        }
      }
      
      
      public bmap Rotate90(bool right) {
        bmap map2=new bmap(Height,Width);
        int d=Height;
        d=right?-d:d;
       unsafe {
        fixed(int* pd2=map2.Data,pd=Data) {        
        for(int y=0;y<Height;y++) {
          int* g2=pd2+(right?(Width-1)*Height+y:(Height-y-1)),h2=pd+y*Width;
          for(int x=0;x<Width;x++) {
            *g2=*h2++;
            g2+=d;
          }
        }
       }}
        return map2;
      }      
      public bmap Rotate90(bool right,int x,int y,int w,int h) {
        if(w<1||h<1||x+w>Width||y+h>Height||x<0||y<0) return null;
        bmap map2=new bmap(h,w);
        int d=right?-h:h;
       unsafe {
        fixed(int *pd2=map2.Data,pd=Data) {
        int *pdx=pd+y*Width+x;
        for(int b=0;b<h;b++) {
          int* g2=pd2+(right?(w-1)*h+b:(h-b-1)),h2=pdx+b*Width;
          for(int a=0;a<w;a++) {
            *g2=*h2++;
            g2+=d;
          }
        }
       }}
        return map2;
      }
      public void CopyRotate90(bmap map2,int x,int y,bool dx,bool dy) {        
        int w=map2.Width,h=map2.Height;
        if(dx) x+=h-w;
        if(dy) y+=w-h;
        CopyRectangle(map2,0,0,w,h,x,y,-1);
      }
      public static double KneeF(int dx,int dy,int x,int y,double a) {
        double x1=x/(dx-a),y1=y/(dy-a);
        return x1*x1+y1*y1-1;
      }
      public static double KneeRadius(int dx,int dy,int x,int y,double min,double max) { // on dx-a/dy-a elipse        
        double qmin=KneeF(dx,dy,x,y,min),qmax=KneeF(dx,dy,x,y,max);
        if(qmin<0==qmax<0) return (min+max)/2;
        for(int i=0;i<10;i++) {
          double qd=qmax-qmin;
          double res=(min+max)/2;
          double q2=KneeF(dx,dy,x,y,res);
          if(q2<0) {min=res;qmin=q2;} else {max=res;qmax=q2;}
        }
        return (min+max)/2;
        //return (min+max)/2;
      }
      public void Knee(int x,int y,int x2,int y2,bool mx,bool my,bool outer) {
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        int dx=x2-x+1,dy=y2-y+1,p=y*Width+x,px=my?p+dy*Width:p-Width,py=mx?p+dx:p-1;

        for(int y1=0;y1<dy;y1++) {
          double ry=255.0*(my?dy-1-y1:y1)/dy;
          for(int x1=0;x1<dx;x1++) { 
            int ax,ay,ia;
            double rx=255.0*(mx?dx-1-x1:x1)/dx;
            if(rx==0&&ry==0) {
              ax=ay=0;ia=512;
            } else {              
              double r2=rx*rx+ry*ry;
              if(r2>sqr(258)) continue;
              double a=Math.Atan2(ry,rx),r=Math.Sqrt(r2);
              if(outer) {
                //rx=256*(x1-(Math.PI/2-a)*(dx-dy)/2/Math.PI)/dy;
                //r=Math.Sqrt(rx*rx+ry*ry);
                double q=(dx<dy?dx:dy)*(256-r)/256;
                q=KneeRadius(dx,dy,mx?dx-1-x1:x1,my?dy-1-y1:y1,0,dy);
                ax=(int)((dx-q)*256);
                ay=(int)((dy-q)*256);
              } else {
                ax=(int)Math.Floor(dx*r);
                ay=(int)Math.Floor(dy*r);
              }
              if(ax>256*dx||ay>256*dy) continue;
              ia=(int)(a*1024*2/Math.PI);
            }
            int x3=ax&255,y3=ay&255;
            ax/=256;ay/=256;
            int cx=Palette.RGBMix(Data[px+(mx?dx-1-ax:ax)],Data[px+(mx?dx-1-ax-1:ax+1)],x3,256);
            int cy=Palette.RGBMix(Data[py+(my?dy-1-ay:ay)*Width],Data[py+(my?dy-1-ay-1:ay+1)*Width],y3,256);
            //if(mx!=my) ia=1024-ia;
            Data[p+y1*Width+x1]=Palette.RGBMix(cx,cy,ia,1024);
          }        
        }
      }
      public void Corner(int x,int y,int x2,int y2,bool mx,bool my) {
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        int dx=x2-x+1,dy=y2-y+1,p=y*Width+x,px=my?p+dy*Width:p-Width,py=mx?p+dx:p-1;

        for(int y1=0;y1<dy;y1++) {
          int ry=my?dy-1-y1:y1;
          for(int x1=0;x1<dx;x1++) { 
            int rx=mx?dx-1-x1:x1;
            int ax,ay,ia,a;
            bool h=rx*dy<ry*dx;
            if(h) {
              ay=ry;ax=ry*dx/dy;a=ax;ia=rx;
            } else {
              ax=rx;ay=rx*dy/dx;a=ay;ia=a-ry;
            }
            int cx=Data[px+(mx?dx-1-ax:ax)];
            int cy=Data[py+(my?dy-1-ay:ay)*Width];
            int cm=Palette.RGBMix(cx,cy,1,2);
            if(h) cx=cm;else cy=cm;
            Data[p+y1*Width+x1]=Palette.RGBMix(cy,cx,ia,a);
          }        
        }
      }
      public void Wedge(int x,int y,int x2,int y2,bool hori,bool inv) {
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        int dx=x2-x+1,dy=y2-y+1,p=y*Width+x,p1=p+(hori?inv?dx:-1:inv?dy*Width:-Width),d1=hori?dy:dx,d2=hori?dx:dy;
        for(int y1=0;y1<dy;y1++) 
          for(int x1=0;x1<dx;x1++) { 
            int r1,r2;
            if(hori) {r1=y1;r2=x1;} else {r1=x1;r2=y1;}
            if(inv) r2=d2-1-r2;
            if(r1<d1/2) {
              if(2*r1*d2<r2*d1) continue;
            } else 
              if(2*(d1-1-r1)*d2<r2*d1) continue;
            Data[p+y1*Width+x1]=Data[p1+r1*(hori?Width:1)];
          }
      }
      public void HLine(int x,int x2,int y,int color) {
        if(x2<x) { int i=x;x=x2;x2=i;}
        for(int h=y*Width+x,he=h+x2-x;h<=he;h++)
          Data[h]=color;
      }
      public void VLine(int x,int y,int y2,int color) {
        if(y2<y) { int i=y;y=y2;y2=i;}
        for(int h=y*Width+x,he=h+(y2-y)*Width;h<=he;h+=Width)
          Data[h]=color;
      }
      public void Strip(int x,int y,int x2,int y2,bool hori,bool inv) {
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(hori) {
          int s=inv?x2+1:x-1;
          for(;y<=y2;y++)
            HLine(x,x2,y,Data[y*Width+s]);
        } else {
          int s=(inv?y2+1:y-1)*Width;
          for(;x<=x2;x++)
            VLine(x,y,y2,Data[s+x]);
        }
      }
      public void Cone(int x,int y,int x2,int y2,bool inv,int bgcolor) {
        int cx=x+x2;
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        cx-=2*x;
        int h=y*Width+x,g,dx=x2-x,dy=y2-y; 
        int[] res=new int[dx+1];
        for(int y1=0,yi=inv?2*dy+1:1;y1<=dy;y1++,yi+=inv?-2:2) {          
          g=(y+y1)*Width+x;
          if(yi==0) {
            Data[g+cx]=Palette.RGBAvg(Data,h,1,cx*256,cx*256);  
          } else
            for(int x1=0,xi=-cx;x1<=dx;x1++,xi+=2) { 
              int from=128*cx+128*(xi*2*(dy+1))/yi;
              int to=128*cx+128*((xi+2)*2*(dy+1))/yi;
              if(from<256*dx&&to>0)
                res[x1]=Palette.RGBAvg(Data,g,1,from,to);
              else
                res[x1]=bgcolor;
            }
          Array.Copy(res,0,Data,g,dx+1);
        }
      }


      public static Bitmap Rotate90(Bitmap bm,bool right) {
        if(bm==null) return null;
        bmap x=FromBitmap(null,bm,-2);
        x=x.Rotate90(right);
        Bitmap ret=new Bitmap(bm.Height,bm.Width,bm.PixelFormat);
        ToBitmap(x,1,1,ret,0,0,ret.Width-1,ret.Height-1,IsAlpha(bm));
        return ret;
      }
      public static void Mirror(Bitmap bm,bool vertical,bool horizontal) {
        if(bm==null) return;
        bmap x=FromBitmap(null,bm,-2);
        x.Mirror(vertical,horizontal);
        ToBitmap(x,1,1,bm,0,0,bm.Width-1,bm.Height-1,IsAlpha(bm));
      }
      public void Bold(bool rgb,bool max,bool vert,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(vert) {
          for(;y2>y;y2--) 
            for(int p2=Width*y2+x,p=p2-Width,pe=p+x2-x;p<pe;p++,p2++) {
              int c=Data[p],c2=Data[p2];
              c=max?Palette.RGBMax(c,c2,rgb):Palette.RGBMin(c2,c,rgb);
              if(c!=c2) {
                Data[p2]=c;
                c=c2;
              }
            }
        } else {
          for(;y<=y2;y++)
            for(int p=Width*y+x,c=Data[p],pe=p+++x2-x;p<pe;p++) {
              int c2=Data[p];
              c=max?Palette.RGBMax(c,c2,rgb):Palette.RGBMin(c2,c,rgb);
              if(c!=c2) {
                Data[p]=c;
                c=c2;
              }
            }              
        }
      }  
      public delegate int Filter1Delegate(object param,int c);
      public int Filter1(Filter1Delegate filter,object param,int x,int y,int x2,int y2,int alpha) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return -1;
        if(x>x2||y>y2) return -1;
        int g=y*Width+x,n=0,ax=256-alpha;
        for(;y<=y2;y++) {
          for(int ge=g+x2-x;g<=ge;g++) {
            int c2=Data[g]&White,c=filter(param,c2);
            if(c==-1) continue;
            c&=White;
            if(c!=c2) { 
              if(alpha!=0) {
                int a0=ax*(c&255)+alpha*(c2&255),a1=ax*((c>>8)&255)+alpha*((c2>>8)&255),a2=ax*((c>>8))+alpha*((c2>>8));
                c=(a0>>8)|(a1&0xff00)|(a2&0xff0000);                
              }
              Data[g]=c;
              n++;
            }
          }
          g+=Width-(x2-x+1);
        }
        return n;
      }
      public static int Filter1Replace(object param,int c) {
        int[] i2=param as int[];
        return c==i2[0]?i2[1]:-1;
      }
      public void Filter(FilterOp f,int param,bool bw,int x,int y,int x2,int y2,bmap undo) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(x>x2||y>y2) return;
        int g=y*Width+x;
        bool bwi=bw&&(f==FilterOp.Invert||f==FilterOp.InvertIntensity);
        byte[] ba=null;
        if(f==FilterOp.Contrast) {
          ba=new byte[6];
          ba[0]=ba[1]=ba[2]=255;
          for(int yy=y,gg=g;yy<=y2;yy++) {
            for(int ge=gg+x2-x;gg<=ge;gg++) {
              int c=Data[gg];
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              if(c0<ba[0]) ba[0]=c0;else if(c0>ba[3]) ba[3]=c0;
              if(c1<ba[1]) ba[1]=c1;else if(c1>ba[4]) ba[4]=c1;
              if(c2<ba[2]) ba[2]=c2;else if(c2>ba[5]) ba[5]=c2;
            }
            gg+=Width-(x2-x+1);
          }
          if(ba[3]<=ba[0]) ba[3]=ba[0];
          if(ba[4]<=ba[1]) ba[4]=ba[1];
          if(ba[5]<=ba[2]) ba[5]=ba[2];
          if(!bw) {
            if(ba[1]<ba[0]) ba[0]=ba[1];
            if(ba[2]<ba[0]) ba[0]=ba[2];
            ba[1]=ba[2]=ba[0];
            if(ba[4]>ba[3]) ba[3]=ba[4];
            if(ba[5]>ba[3]) ba[3]=ba[5];
            ba[4]=ba[5]=ba[3];
          }
        }
        for(;y<=y2;y++) {
          for(int ge=g+x2-x;g<=ge;g++) {
            int c=Data[g]&White;
            if(f==FilterOp.Contrast) {
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              if(ba[0]!=ba[3]) c0=(byte)((c0-ba[0])*255/(ba[3]-ba[0]));
              if(ba[1]!=ba[4]) c1=(byte)((c1-ba[1])*255/(ba[4]-ba[1]));
              if(ba[2]!=ba[5]) c2=(byte)((c2-ba[2])*255/(ba[5]-ba[2]));
              Data[g]=c0|(c1<<8)|(c2<<16);
              continue;
            }
            if(f==FilterOp.Border) {
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              int csum=c0+c1+c2;
              bool wh=false,go=false;
              for(int i=0,n=bw?8:4;i<n;i++) {
                int d=undo.Data[g+(i<4?i<2?i==1?1:-1:i==2?-Width:Width:i<6?i==5?-Width+1:-Width-1:i==6?Width-1:Width+1)]&White;
                byte d0=(byte)(d&255),d1=(byte)((d>>8)&255),d2=(byte)((d>>16)&255);
                int dsum=d0+d1+d2;
                if(csum>dsum||(csum==dsum&&c>d)) continue;
                //if(d0>c0+param||d1>c1+param||d2>c2+param) {
                if(Palette.RGBDiff(2,param,c,d)) {
                  go=true;
                  break;
                }
              }
              if(go^wh) Data[g]=wh?White:0;
              continue;
            }
            if(c==0||c==White) {
              if(bwi) Data[g]=c==0?White:0; 
            } else if(f==FilterOp.InvertIntensity) Data[g]=Palette.InvertIntensity(c,0);
            else if(f==FilterOp.Saturate) Data[g]=Palette.Saturate(c,param);
            else if(f==FilterOp.Grayscale) Data[g]=Palette.Grayscale(c,param);
            else if(f==FilterOp.Levels) Data[g]=Palette.Levels(c,param);
            else if(f==FilterOp.Strips) Data[g]=Palette.Strips(c,param,0,White);
            else if(f==FilterOp.ToWhite) Data[g]=Palette.ToWhite(c,param);
            else if(f==FilterOp.ToBlack) Data[g]=Palette.ToBlack(c,param);
            else if(f==FilterOp.Channel) {
              bool rgb=0!=(param&16);
              int p=param&15;
              int i;
              if(p<3) i=(p==1?c>>8:p==0?c>>16:c)&255;
              else if(p==6) i=isqrt(Palette.RGBSqr(c,0))*255/441;
              else if(p>=7) {
                int c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255;
                if(p==7) {i=c0<c1?c0:c1;if(c2<i) i=c2;}
                else if(p==9) {i=c0>c1?c0:c1;if(c2>i) i=c2;}
                else i=(c0+c1+c2)/3;
              }
              else {
                int c0=((c>>(p==3?16:0))&255),c1=(c>>(p==5?16:8))&255;
                i=c0<c1?c0:c1;
              }
              if(rgb)
                Data[g]=Palette.ColorIntensity765(c,i*3,true);
              else
                Data[g]=i*0x10101;
            } else if(f==FilterOp.Substract) Data[g]=Palette.RGBSub(c,param,(param>>24)&7,0!=((param>>28)&1));
            else if(f==FilterOp.Hue) Data[g]=Palette.RGBHue(c,0!=(param&4096),param&2047);
            else Data[g]^=White;                        
          }
          g+=Width-(x2-x+1);
        }
      }
      public static int Filter256(object map,int c) {
        byte[] m=map as byte[];
        return Palette.RGBMap(c,m);
      }
      public static int Filter765c(object map,int c) {
        int[] m=map as int[];
        return Palette.RGBMapic(c,m);
      }
      public static int Filter765i(object map,int c) {
        int[] m=map as int[];
        return Palette.RGBMapii(c,m,true);
      }
      public static int FilterSatur(object desat,int c) {
        char ch=(char)desat;
        return Palette.Saturate(c,ch=='d',ch=='o'); 
      }
      public static int FilterReplace(object sr,int c) {
        int[] ia=sr as int[];
        return Palette.RGBReplace(c,ia[0],ia[1],ia[2]);
      }
      public delegate int Filter33Delegate(bmap map,int offset,object param);
      public void Filter33(Filter33Delegate fx,object param,bool bw,int x,int y,int x2,int y2,bmap undo) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        undo.Border();
        for(;y<=y2;y++) 
          for(int p=y*Width+x,pe=p+x2-x;p<=pe;p++) {
            if(!bw&&((undo.Data[p]&White)==White||(undo.Data[p]&White)==0)) continue;
            Data[p]=fx(undo,p,param);
          }
      }
      public static int Filter33Emboss(bmap map,int p,object param) {
        int r=0,b=0,g=0,div=param==null?4:(int)param;
        if(div==0) div=1;
        Palette.RGBAdd(map.Data[p-1],10,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width],10,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width-1],4,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p],-24,ref b,ref r,ref g);
        r=128-r/div;if(r<0) r=0;else if(r>255) r=255;
        g=128-g/div;if(g<0) g=0;else if(g>255) g=255;
        b=128-b/div;if(b<0) b=0;else if(b>255) b=255;
        return b|(r<<8)|(g<<16);
      }
      public static int Filter33Blur(bmap map,int p,object param) {
        int r=0,b=0,g=0;
        Palette.RGBAdd(map.Data[p-1],ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+1],ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p-map.Width],ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width],ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p],4,ref b,ref r,ref g);
        return Palette.RGBAvg(8,b,r,g);
      }
      public static int Filter33Sharp(bmap map,int p,object param) {
        int r=0,b=0,g=0;
        Palette.RGBAdd(map.Data[p-1],-1,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+1],-1,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p-map.Width],-1,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width],-1,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p-map.Width-1],-2,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p-map.Width+1],-2,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width-1],-2,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p+map.Width+1],-2,ref b,ref r,ref g);
        Palette.RGBAdd(map.Data[p],24,ref b,ref r,ref g);
        return Palette.RGBAvg2(12,b,r,g);
      }
      public static int Filter33Min(bmap map,int p,object param) {
        int r=0,b=0,g=0;
        Palette.RGBMin(map.Data[p-1],ref b,ref r,ref g);
        Palette.RGBMin(map.Data[p+1],ref b,ref r,ref g);
        Palette.RGBMin(map.Data[p-map.Width],ref b,ref r,ref g);
        Palette.RGBMin(map.Data[p+map.Width],ref b,ref r,ref g);
        Palette.RGBMin(map.Data[p],ref b,ref r,ref g);
        return Palette.RGBAvg(1,b,r,g);
      }
      public static int Filter33Edge(bmap map,int p,object param) {
        int i0=255,i1=255,i2=255,a0=0,a1=0,a2=0;
        Palette.RGBMinMax(map.Data[p],ref i0,ref i1,ref i2,ref a0,ref a1,ref a2);
        Palette.RGBMinMax(map.Data[p+1],ref i0,ref i1,ref i2,ref a0,ref a1,ref a2);
        Palette.RGBMinMax(map.Data[p+map.Width],ref i0,ref i1,ref i2,ref a0,ref a1,ref a2);
        int mul=(int)param;
        a0=255-mul*(a0-i0);
        a1=255-mul*(a1-i1);
        a2=255-mul*(a2-i2);
        return Palette.RGBAvg2(1,a0,a1,a2);
      }
      public static int Filter33Edge1(bmap map,int p,object param) {
        int a0=0,a1=0,a2=0;
        int c,c2,c1,c0,e,d;
        c=map.Data[p];c0=c&255;c1=(c>>8)&255;c2=(c>>16)&255;
        e=map.Data[p-1];d=(e&255)-c0;if(d>a0) a0=d;d=((e>>8)&255)-c1;if(d>a1) a1=d;d=((e>>16)&255)-c2;if(d>a2) a2=d;
        e=map.Data[p+1];d=(e&255)-c0;if(d>a0) a0=d;d=((e>>8)&255)-c1;if(d>a1) a1=d;d=((e>>16)&255)-c2;if(d>a2) a2=d;
        e=map.Data[p-map.Width];d=(e&255)-c0;if(d>a0) a0=d;d=((e>>8)&255)-c1;if(d>a1) a1=d;d=((e>>16)&255)-c2;if(d>a2) a2=d;
        e=map.Data[p+map.Width];d=(e&255)-c0;if(d>a0) a0=d;d=((e>>8)&255)-c1;if(d>a1) a1=d;d=((e>>16)&255)-c2;if(d>a2) a2=d;
        int mul=(int)param;
        a0=255-mul*a0;
        a1=255-mul*a1;
        a2=255-mul*a2;
        return Palette.RGBAvg2(1,a0,a1,a2);
      }
      public static int Filter33Neq(bmap map,int p,object param) {
        bool x8=param!=null,eq;
        int c=map.Data[p];
        eq=c==map.Data[p-1]&&c==map.Data[p+1]&&c==map.Data[p-map.Width]&&c==map.Data[p+map.Width];
        if(eq&&x8) 
          eq=c==map.Data[p-map.Width-1]&&c==map.Data[p-map.Width+1]&&c==map.Data[p+map.Width-1]&&c==map.Data[p+map.Width+1];
        return eq?White:c;
      }
      public static int Filter33HDR(bmap map,int p,object param) {
        bool x8=param!=null;
        int c,min=255,max=0,avg=0;
        Palette.RGBMinMax(c=map.Data[p],ref min,ref max,ref avg);
        Palette.RGBMinMax(map.Data[p-1],ref min,ref max,ref avg);
        Palette.RGBMinMax(map.Data[p+1],ref min,ref max,ref avg);
        Palette.RGBMinMax(map.Data[p-map.Width],ref min,ref max,ref avg);
        Palette.RGBMinMax(map.Data[p+map.Width],ref min,ref max,ref avg);
        if(x8) { //&&(min>0||max<255)
          Palette.RGBMinMax(map.Data[p-map.Width-1],ref min,ref max,ref avg);
          Palette.RGBMinMax(map.Data[p-map.Width+1],ref min,ref max,ref avg);
          Palette.RGBMinMax(map.Data[p+map.Width-1],ref min,ref max,ref avg);
          Palette.RGBMinMax(map.Data[p+map.Width+1],ref min,ref max,ref avg);
        }
        //if(min==0&&max==255||(min==max)) return c;
        if(min==max) return c;
        avg/=x8?27:15;
        int b=c&255,g=(c>>8)&255,r=(c>>16)&255,b2,g2,r2;
        //int b2=(b-min)*255/(max-min),g2=(g-min)*255/(max-min),r2=(r-min)*255/(max-min);
        b2=b==min?0:b==max?255:b>=avg?128+(b-avg)*127/(max-avg):(b-min)*127/(avg-min);
        g2=g==min?0:g==max?255:g>=avg?128+(g-avg)*127/(max-avg):(g-min)*127/(avg-min);
        r2=r==min?0:r==max?255:r>=avg?128+(r-avg)*127/(max-avg):(r-min)*127/(avg-min);
        b=(3*b+b2)/4;g=(3*g+g2)/4;r=(3*r+r2)/4;
        return b|(g<<8)|(r<<16);
      }
      public void Color256(int mode,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] sum=new int[(mode==8?8:mode==6?64:mode>=4?4096:mode==3?512:256)*4];
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            int c=Data[p],b=c&255,g=(c>>8)&255,r=(c>>16)&255,i;
            if(mode==6) 
              i=b/64*16+g/64*4+r/64;
            else if(mode==8) 
              i=b/128*4+g/128*2+r/128;
            else if(mode==4) 
              i=b/16*256+g/16*16+r/16;
            else if(mode==3) 
              i=b/32*64+g/32*8+r/32;            
            else if(mode==2) {
              int s=r+g+b,d=abs(r-g)+abs(g-b)+abs(b-r),rgb=((r&128)!=0?4:0)|((g&128)!=0?2:0)|((b&128)!=0?1:0);
              i=(s+2)/96*32+(d+1)/128*8+rgb;
            } else if(mode==1) {
              i=(r+38)/42*35+(g+38)/42*5+(b+4)/52;
            } else {
              i=r/32*32+g/32*4+b/64;
            }
            i*=4;
            sum[i]++;sum[i+1]+=b;sum[i+2]+=g;sum[i+3]+=r;
          }
        for(int i=0;i<sum.Length;i+=4) 
          if(sum[i]!=0) sum[i]=Palette.RGBAvg(sum[i],sum[i+1],sum[i+2],sum[i+3]);
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            int c=Data[p],b=c&255,g=(c>>8)&255,r=(c>>16)&255,i;
            if(mode==6) 
              i=b/64*16+g/64*4+r/64;
            else if(mode==8) 
              i=b/128*4+g/128*2+r/128;
            else if(mode==4) 
              i=b/16*256+g/16*16+r/16;
            else if(mode==3)  
              i=b/32*64+g/32*8+r/32;            
            else if(mode==2) {
              int s=r+g+b,d=abs(r-g)+abs(g-b)+abs(b-r),rgb=((r&128)!=0?4:0)|((g&128)!=0?2:0)|((b&128)!=0?1:0);
              i=(s+2)/96*32+(d+1)/128*8+rgb;
            } else if(mode==1) {
              i=(r+38)/42*35+(g+38)/42*5+(b+4)/52;
            } else {
              i=r/32*32+g/32*4+b/64;
            }
            Data[p]=sum[4*i];
          }         
      }
      public void Color765(int satur,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] sum=new int[766];
        int i,s=Palette.RGBSum(Data[y*Width+x]),si,c,n=0,min=s,max=s;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            i=Palette.RGBSum(Data[p]);
            if(i<min) min=i;else if(i>max) max=i;
            sum[i]++;
            n++;
          }
        if(min==max) return;
        n-=sum[min]+sum[max];
        bool limit=true;
        if(limit) {
          int l=n/254;
          for(i=min+1;i<max;i++) 
            if((si=sum[i])>l) { n-=si-l;sum[i]=l;}  
        }
        for(s=0,i=min+1;i<max;i++)
          if(sum[i]!=0) {
            si=sum[i];
            s+=si;
            sum[i]=1+s*764/n;
          }
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            c=Data[p];
            int s0=c&255,s1=(c>>8)&255,s2=(c>>16)&255;
            i=s0+s1+s2;
            if(i<=min) c=0;
            else if(i>=max) c=White;
            else {
              s=sum[i];
              c=Palette.ColorIntensity765(s0,s1,s2,s,satur);
            }
            Data[p]=c;
          }        
      }
      public void Color765rgb(int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] s0=new int[256],s1=new int[256],s2=new int[256];
        int c=Data[y*Width+x],ph0,ph1,ph2,s0i=c&255,s1i=(c>>8)&255,s2i=(c>>16)&255,s0a=s0i,s1a=s1i,s2a=s2i,n0,n1,n2,s,i,si;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            c=Data[p];
            s0[ph0=c&255]++;s1[ph1=(c>>8)&255]++;s2[ph2=(c>>16)&255]++;
            if(ph0<s0i) s0i=ph0;else if(ph0>s0a) s0a=ph0;
            if(ph1<s1i) s1i=ph1;else if(ph1>s1a) s1a=ph1;
            if(ph2<s2i) s2i=ph2;else if(ph2>s2a) s2a=ph2;
          }
        n0=n1=n2=(x2-x+1)*(y2-y+1);
        if(s0i==s0a&&s1i==s1a&&s2i==s2a) return;
        n0-=s0[s0i]+s0[s0a];
        n1-=s1[s1i]+s1[s1a];
        n2-=s2[s2i]+s2[s2a];
        if(n0<1&&n1<1&&n2<1) return;
        bool limit=true;
        if(limit) {
          int l0=n0/254,l1=n1/254,l2=n2/254;
          for(i=0;i<255;i++) {
            if(i>s0i&&i<s0a&&(si=s0[i])>l0) {n0-=si-l0;s0[i]=l0;}
            if(i>s1i&&i<s1a&&(si=s1[i])>l1) {n1-=si-l1;s1[i]=l1;}
            if(i>s2i&&i<s2a&&(si=s2[i])>l2) {n2-=si-l2;s2[i]=l2;}
          }  
        }
        if(s0i<s0a) {s0[s0i]=0;s0[s0a]=255;}
        if(s1i<s1a) {s1[s1i]=0;s1[s1a]=255;}
        if(s2i<s2a) {s2[s2i]=0;s2[s2a]=255;}
        n0++;n1++;n2++;
        for(s=0,i=s0i+1;i<s0a;i++)
          if((si=s0[i])>0) { s+=si; s0[i]=s*255/n0; }
        for(s=0,i=s1i+1;i<s1a;i++)
          if((si=s1[i])>0) { s+=si; s1[i]=s*255/n1; }
        for(s=0,i=s2i+1;i<s2a;i++)
          if((si=s2[i])>0) { s+=si; s2[i]=s*255/n2; }
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            c=Data[p];
            ph0=c&255;ph1=(c>>8)&255;ph2=(c>>16)&255;
            if(s0i<s0a) ph0=s0[ph0];
            if(s1i<s1a) ph1=s1[ph1];
            if(s2i<s2a) ph2=s2[ph2];
            Data[p]=ph0|(ph1<<8)|(ph2<<16);
          }
      }
      public void Color765bw2(int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] si=new int[766];
        int s,s2,i,a;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            s=Palette.RGBSum(Data[p]);
            if(p+3<pe) {
              s2=Palette.RGBSum(Data[p+1]);
              if(s<s2) {i=s;a=s2;} else {i=s2;a=s;}
              if(i<a) {si[i]++;si[a]--;}
            }
            if(y3<y2) {
              s2=Palette.RGBSum(Data[p+Width]);
              if(s<s2) {i=s;a=s2;} else {i=s2;a=s;}
              if(i<a) {si[i]++;si[a]--;}
            }
          }
        for(i=0,s=0,a=765/2,s2=0;i<766;i++) {
          s+=si[i];
          if(s>s2) {a=i;s2=s;}
        }
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++)
            Data[p]=Palette.RGBSum(Data[p])<=a?0:White;

      }
      public void Color765grx(int x,int y,int x2,int y2,int lev,bool avg) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] pi=new int[766],ni=new int[766],si=avg?new int[766]:null;
        int s,s2,i,a,e;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            s=Palette.RGBSum(Data[p]);
            if(avg) si[s]++;
            if(p+3<pe) {
              s2=Palette.RGBSum(Data[p+1]);
              if(s<s2) {i=s;a=s2;} else {i=s2;a=s;}
              if(i<a) {pi[i]++;ni[a-1]++;}
            }
            if(y3<y2) {
              s2=Palette.RGBSum(Data[p+Width]);
              if(s<s2) {i=s;a=s2;} else {i=s2;a=s;}
              if(i<a) {pi[i]++;ni[a-1]++;}
            }
          }
        bool[] bi=new bool[766];
        for(int l=1;l<lev;l++) {
          for(i=0,s=0,a=-1,s2=0;i<766;i++) {
            s+=pi[i];
            if(s>s2) {a=i;s2=s;}
            s-=ni[i];
          }
          if(a<0) {
            lev=l;
            break;
          }
          bi[a+1]=true;          
          for(i=a-1,e=0,s=s2-pi[a]+ni[a];i>=0&&s>0;i--) {
            if(pi[i]>0) {              
              int sii=pi[i],es=Math.Min(e,sii);
              e-=es;sii-=es;
              es=Math.Min(sii,s);
              s-=es;pi[i]-=es;              
            }
            if(ni[i]>0) e+=ni[i];
          }
          for(i=a+1,e=0,s=s2;i<766&&s>0;i++) {
            if(ni[i]>0) {              
              int sii=ni[i],es=Math.Min(e,sii);              
              e-=es;sii-=es;
              es=Math.Min(sii,s);
              s-=es;ni[i]-=es;            
            }
            if(pi[i]>0) e+=pi[i];
          }
          pi[a]=ni[a]=0;
        }        
        for(i=a=s=0,e=0;i<766;i++) {
          if(avg) {
            if(i==e) {
              int j=i,n=0;s=0;
              do {
                n+=si[j];s+=j*si[j];
                if(bi[j++]) break;
              } while(j<766);
              s=(s/n)/3;
              //s=(j-1+i)/2/3;
              e=j;
            }
          }            
          pi[i]=s*0x10101;  
          if(!avg)
            if(bi[i]) {a++;s=a*255/(lev-1);}
        }
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++)
            Data[p]=pi[Palette.RGBSum(Data[p])];

      }
      static int gravg(int[] si,int f,int t) {
        int i,n=0,s=0;
        for(i=f;i<t;i++) {n+=si[i];s+=i*si[i];}
        return n>0?s/n:0;
      }
      static int grerr(int[] si,int f,int t) {
        int i,n=0,s=0,a;
        for(i=f;i<t;i++) {n+=si[i];s+=i*si[i];}
        if(n<1) return 0;
        a=s/n;
        for(i=f,s=0;i<a;i++) s+=(a-i)*si[i];
        for(i=a+1;i<t;i++) s+=(i-a)*si[i];
        return s;
      }
      int grerr2(int[] si,int f,int m,int t) {
        return grerr(si,f,m)+grerr(si,m,t);
      }
      public void Color765gro(int x,int y,int x2,int y2,int lev,bool avg) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] si=new int[766];
        int[] ll=new int[lev+1];
        int s,i,j,l,chg;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            s=Palette.RGBSum(Data[p]);
            si[s]++;
          }
        for(l=0;l<=lev;l++)
          ll[l]=(l*766/lev);
        j=0;
        do {
          chg=i=0;
          for(;i<lev-1&&j<4096;j++) {
            int li=ll[i],l1=ll[i+1],l2=ll[i+2];
            int e2,e=grerr2(si,li,l1,l2),mi=l1;
            for(l1=li+1;l1<l2;l1++) 
              if(si[l1]!=0) {
  	            e2=grerr2(si,li,l1,l2);
	              if(e2<e) {e=e2;mi=l1;}
              }
            //printf("%d. %d %d %d \n",j,i,l1,ll[i+1]);
            if(mi!=ll[i+1]) {
	            ll[i+1]=mi;
	            chg=1;
            }
            i++;
          }
        } while(chg==1);
        for(i=0,s=0,l=0;i<766;i++) {
          if(ll[l]==i) {s=gravg(si,ll[l],ll[l+1])/3;l++;}
          si[i]=s*0x10101;
        }
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++)
            Data[p]=si[Palette.RGBSum(Data[p])];

      }
      public void Color256x3(int x,int y,int x2,int y2,bool x3) {
        R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,1,1,Width-2,Height-2)) return;
        if(x>x2||y>y2) return;
        int[] si=new int[x3?768:256];
        int c,c2,s,s2,i,j,a,sx,sd=x3?256:0,r,l0,l1,l2;
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            c=Data[p];
            if(p+1<pe) {
              c2=Data[p+1];
              for(sx=0,j=0;j<24;j+=8,sx+=sd) {
                i=(c>>j)&255;a=(c2>>j)&255;
                if(i>a) { r=i;i=a;a=r;}
                si[sx+i]++;si[sx+a]--;
              }
            }
            if(y3<y2) {
              c2=Data[p+Width];
              for(sx=0,j=0;j<24;j+=8,sx+=sd) {
                i=(c>>j)&255;a=(c2>>j)&255;
                if(i>a) { r=i;i=a;a=r;}
                si[sx+i]++;si[sx+a]--;
              }
            }
          }
        for(sx=0,j=0;j<(x3?3:1);j++,sx+=256) {
          for(i=0,s=0,a=127,s2=0;i<256;i++) {
            s+=si[sx+i];
            if(s>s2) {a=i;s2=s;}
          }
          si[j]=a;
        }           
        l0=si[0];
        if(x3) {l1=si[1];l2=si[2];} else {l1=l2=l0;}
        for(int y3=y;y3<=y2;y3++) 
          for(int p=y3*Width+x,pe=p+x2-x;p<=pe;p++) {
            c=Data[p];
            int c0=c&255,c1=(c>>8)&255;c2=(c>>16)&255;
            c0=c0<=l0?0:255;
            c1=c1<=l1?0:255;
            c2=c2<=l2?0:255;
            Data[p]=c0|(c1<<8)|(c2<<16);
          }
      }

      internal class xpal {
        internal int n,s0,s1,s2;
        internal byte i0,a0,i1,a1,i2,a2;        

      public override string ToString() {
        return ""+i0+"-"+a0+","+i1+"-"+a1+","+i2+"-"+a2;
      }
    }

      internal int xpal_dist(xpal[] map,int n,bool max,int c,out int ix,bool ps2) {
        byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255),x0,x1,x2;
        int m=766,d=0,r1,r2,s;
        ix=-1;
        for(int i=0;i<n;i++) {
          xpal mi=map[i];
          if(ps2) {
            x0=mi.i0;x1=mi.i1;x2=mi.i2;
            d=(c0>x0?c0-x0:x0-c0)+(c1>x1?c1-x1:x1-c1)+(c2>x2?c2-x2:x2-c2);
          } else {
            d=0;
            x0=mi.i0;x1=mi.a0;
            d+=x1-x0;
            if((s=x0-c0)>0) d+=s;else if((s=c0-x1)>0) d+=s;
            x0=mi.i1;x1=mi.a1;
            r1=x1-x0;
            if((s=x0-c1)>0) r1+=s;else if((s=c1-x1)>0) r1+=s;
            x0=mi.i2;x1=mi.a2;
            r2=x1-x0;
            if((s=x0-c2)>0) r2+=s;else if((s=c2-x1)>0) r2+=s;
            if(max) {
              if(r1>d) d=r1;
              if(r2>d) d=r2;
            } else 
              d+=r1+r2;
          }
          if(d<m) {m=d;ix=i;}
        }
        return m;
      }
      internal int xpal_join(xpal[] map,int n,bool max,ref int dist) {
        int i,im=-1,j,jm=-1,d,r1,r2,mi=766;
        byte i0,j0,i1,j1;
        xpal ib,jb;
  
        for(i=0;i<n-1;i++) {
          ib=map[i];
          for(j=i+1;j<n;j++) {
            jb=map[j];
            i0=ib.i0;i1=ib.a0;j0=jb.i0;j1=jb.a0;
            d=(j1>i1?j1:i1)-(j0<i0?j0:i0);
            i0=ib.i1;i1=ib.a1;j0=jb.i1;j1=jb.a1;      
            r1=(j1>i1?j1:i1)-(j0<i0?j0:i0);      
            i0=ib.i2;i1=ib.a2;j0=jb.i2;j1=jb.a2;      
            r2=(j1>i1?j1:i1)-(j0<i0?j0:i0);
            if(max) {
              if(r1>d) d=r1;
              if(r2>d) d=r2;
            } else 
              d+=r1+r2;
            if(d<mi) {mi=d;im=i;jm=j;}
          }
        }        
        ib=map[im];jb=map[jm];
        ib.n+=jb.n;
        ib.s0+=jb.s0;
        ib.s1+=jb.s1;
        ib.s2+=jb.s2;
        if(jb.i0<ib.i0) ib.i0=jb.i0;
        if(jb.a0>ib.a0) ib.a0=jb.a0;
        if(jb.i1<ib.i1) ib.i1=jb.i1;
        if(jb.a1>ib.a1) ib.a1=jb.a1;
        if(jb.i2<ib.i2) ib.i2=jb.i2;
        if(jb.a2>ib.a2) ib.a2=jb.a2;
        d=ib.a0-ib.i0+ib.a1-ib.i1+ib.a2-ib.i2;
        if(d>dist) dist=d;
        return jm;
      }

      public void MaxCount(int count,bool max,int x,int y,int x2,int y2) {
 			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(count<1||count>4096) return;
        xpal[] map=new xpal[count];        
        xpal xp;
        int n=0,dist=0,ix=0,c,d=1;
        for(int i=0;i<count;i++) map[i]=new xpal();
        for(int yi=y;yi<=y2;yi++)
            for(int xi=x,i=yi*Width+x,j;xi<=x2;xi++,i++) {
              c=Data[i]&White;              
              byte c0=(byte)(c&255),c1=(byte)((c>>8)&255),c2=(byte)((c>>16)&255);
              if(n>0) {
                c=c0|(c1<<8)|(c2<<16);
                if(n==count) {
                  xp=map[ix];                
                  if(c0<xp.i0||c0>xp.a0||c1<xp.i1||c1>xp.a1||c2<xp.i2||c2>xp.a2) ix=-1;
                  else d=dist;
                } else ix=-1;
                if(ix<0)
                  d=xpal_dist(map,n,max,c,out ix,false);
              }
              bool res;
              if((res=(n<count&&d>0)))
                ix=n++;
              else if((res=d>dist)) 
                ix=xpal_join(map,n,max,ref dist);
              if(res) {
                xp=map[ix];
                xp.n=xp.s0=xp.s1=xp.s2=0;
                xp.i0=xp.a0=c0;
                xp.i1=xp.a1=c1;
                xp.i2=xp.a2=c2;                
              }
              xp=map[ix];
              xp.n++;
              xp.s0+=c0;
              xp.s1+=c1;
              xp.s2+=c2;
              if(c0<xp.i0) xp.i0=c0;
              else if(c0>xp.a0) xp.a0=c0;
              if(c1<xp.i1) xp.i1=c1;
              else if(c1>xp.a1) xp.a1=c1;
              if(c2<xp.i2) xp.i2=c2;
              else if(c2>xp.a2) xp.a2=c2;
            }
          for(int i=0;i<n;i++) {
            xp=map[i];
            d=xp.n;
            byte c0=(byte)(xp.s0/d),c1=(byte)(xp.s1/d),c2=(byte)(xp.s2/d);
            xp.i0=c0;
            xp.i1=c1;
            xp.i2=c2;            
            xp.n=c0|(c1<<8)|(c2<<16);
          }
          for(int yi=y;yi<=y2;yi++)
            for(int xi=x,i=yi*Width+x;xi<=x2;xi++,i++) {
              c=Data[i]&White;              
              xpal_dist(map,n,max,c,out ix,true);                
              Data[i]=map[ix].n;
            }
      }


     
      public void RemoveDots(bool black,bool white,char mode,bmap src) {
        Border(-1);
        ClearByte();
        src.ClearByte();
        int h=Height-2,w=Width-2,i=Width+1;
        bool all=!black&&!white;
        bool x3=mode=='3',x8=mode=='8',x4=!x3&&!x8;
        int[] data=src.Data;
        for(int y=0;y<h;y++,i+=2) 
          for(int x=0;x<w;x++,i++) {            
            if(black&&data[i]==0||white&&data[i]==White||all) {
              int c=data[i],c2=c;
              bool dot=data[i-1]!=c&&data[i+1]!=c&&data[i+Width]!=c&&data[i-Width]!=c;
              if(x8)
                 if(data[i-Width-1]==c||data[i-Width+1]==c||data[i+Width-1]==c||data[i+Width+1]==c) dot=false;              
              c=dot?Palette.RGBAvg4(data[i-1],data[i+1],data[i-Width],data[i+Width]):-1;
              if(!dot&&x3) {
                c=c2;
                bool l=data[i-1]!=c,r=data[i+1]!=c,u=data[i-Width]!=c,d=data[i+Width]!=c;
                if(l&&r&&(d||u)) c=Palette.RGBAvg3(data[i-1],data[i+1],data[i+(d?Width:-Width)]);
                else if(d&&u&&(l||r)) c=Palette.RGBAvg3(data[i-Width],data[i+Width],data[i+(r?1:-1)]);
              }
              if(c!=-1) Data[i]=c;
            }
          }
      }
      static byte[] bc16={0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4};
      public static int bitcount(int x) {
        int i,n;
        if(x==0) n=0;
        else if(x==-1) n=32;
        else for(i=n=0;i<32;i+=4) n+=bc16[(x>>i)&15];
        return n;
      }

      public int ColorCount(int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return 0;
        if(x==x2&&y==y2) return 1;
        int[] map=new int[1<<19];
        int c,n=0;
        for(int yi=y;yi<=y2;yi++)
          for(int xi=x,i=yi*Width+x;xi<=x2;xi++,i++) {
            c=Data[i]&White;
            map[c>>5]|=1<<(c&31);
          }            
        foreach(int m in map) n+=bitcount(m);
        return n;
      }
      public void PalN(int n,bool avg,int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(n<1||n>64) return;
        int a=0,b=255/n+1;
        while(256+a<n*b) a++;
        int[] sum=null;
        if(avg) {
          sum=new int[4*n*n*n];
          for(int yi=y;yi<=y2;yi++)
            for(int xi=x,i=yi*Width+x,j;xi<=x2;xi++,i++) {
              int c=Data[i]&White;
              if(c==0||c==White) continue;
              int c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255;
              if(n==2) j=(c0>127?1:0)+(c1>127?2:0)+(c2>127?4:0);            
              j=(c0+a)/b+n*((c1+a)/b+(c2+a)/b*n);
              j*=4;
              sum[j++]++;sum[j++]+=c0;sum[j++]+=c1;sum[j]+=c2;
            }
          for(int i=0,i4=0;i4<sum.Length;i++,i4+=4) {
            int s=sum[i4];
            if(s>0) sum[i]=sum[i4+1]/s+((sum[i4+2]/s)<<8)+((sum[i4+3]/s)<<16);
          }
        }
        for(int yi=y;yi<=y2;yi++)
          for(int xi=x,i=yi*Width+x,j;xi<=x2;xi++,i++) {
            int c=Data[i]&White;
            if(c==0||c==White) continue;
            int c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255;
            if(avg) {
              if(n==2) j=(c0>127?1:0)+(c1>127?2:0)+(c2>127?4:0);            
              j=(c0+a)/b+n*((c1+a)/b+(c2+a)/b*n);
              Data[i]=sum[j];            
            } else {
              c0=(c0+a)/b*255/(n-1);
              c1=(c1+a)/b*255/(n-1);
              c2=(c2+a)/b*255/(n-1);
              Data[i]=c0+(c1<<8)+(c2<<16);
            }
          }
      }
      public void RemoveDust(int max,int color1,int color2,bool x8,int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(max<1||color1==color2) return;
        ClearByte();
        int[] q=new int[max+4];
        for(int yi=y;yi<=y2;yi++)
          for(int xi=x,i=yi*Width+x,h,xy;xi<=x2;xi++,i++) if(Data[i]==color1) {
            int n=0,m=1,nx,ny;
            q[n]=(xi&0xffff)|(yi<<16);Data[i]=color2;
            while(n<m&&m<=max) {
              xy=q[n++];nx=xy&0xffff;ny=xy>>16;
              h=Width*ny+nx;
              if(nx>x&&Data[h-1]==color1) {q[m++]=xy-1;Data[h-1]=color2;}
              if(nx<x2&&Data[h+1]==color1) {q[m++]=xy+1;Data[h+1]=color2;}
              if(ny>y&&Data[h-Width]==color1) {q[m++]=xy-0x10000;Data[h-Width]=color2;}
              if(ny<y2&&Data[h+Width]==color1) {q[m++]=xy+0x10000;Data[h+Width]=color2;}
              if(x8) {
                if(ny>y) {
                  if(nx>x&&Data[h-Width-1]==color1) {q[m++]=xy-0x10000-1;Data[h-Width-1]=color2;}
                  if(nx<x2&&Data[h-Width+1]==color1) {q[m++]=xy-0x10000+1;Data[h-Width+1]=color2;}
                }
                if(ny<y2) {
                  if(nx>x&&Data[h+Width-1]==color1) {q[m++]=xy+0x10000-1;Data[h+Width-1]=color2;}
                  if(nx<x2&&Data[h+Width+1]==color1) {q[m++]=xy+0x10000+1;Data[h+Width+1]=color2;}
                }
              }
            }
            bool go=m<max;
            if(!go) for(n=0;n<m;n++) {
              xy=q[n];nx=xy&0xffff;ny=xy>>16;
              h=Width*ny+nx;
              Data[h]=color1;
            }
          }
      }

      public void Bright(bool dark,bool bw,int level,int x,int y,int x2,int y2) {
			  R.Norm(ref x,ref y,ref x2,ref y2);
				if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        if(level<1||level>255) return;
				int i=y*Width+x,dx=x2-x+1;
				while(y<=y2) {
				  for(int ie=i+dx;i<ie;i++) {
						int c=Data[i];
            if(bw&&(c&White)==(dark?White:0)) continue;
						int b0=c&255,b1=(c>>8)&255,b2=(c>>16)&255;
						if(dark) {b0=b0*level/255;b1=b1*level/255;b2=b2*level/255;}
						else {b0=255-((255-b0)*level/255);b1=255-((255-b1)*level/255);b2=255-((255-b2)*level/255);}
						c=b0|(b1<<8)|(b2<<16);
						Data[i]=c;
					}
				  i+=Width-dx;
					y++;
				}
      }
      public void NoWhite(bool white,bool black) {
        if(!white&&!black) return;
        for(int i=0;i<Data.Length;i++) {
          int x=Data[i];
          if(white&&(x&White)==White) Data[i]=0xfefefe;
          else if(black&&(x&White)==Black) Data[i]=0x010101;
        }        
      }
      public void Contour(bool white,int x,int y,int x2,int y2) {
        R.Norm(ref x,ref y,ref x2,ref y2);
        if(!IntersectRect(ref x,ref y,ref x2,ref y2,0,0,Width-1,Height-1)) return;
        int n=Data.Length-Width-1;
        ClearByte(x,y,x2,y2,0);
				for(int y3=y;y3<=y2;y3++)
				  for(int i=y3*Width+x,i0=i,ie=i+x2-x+1;i<ie;i++) {
            int ci=Palette.RGBSum(Data[i]);            
            if(i>0&&ci<Palette.RGBSum(Data[i-1])||i<ie-1&&ci<Palette.RGBSum(Data[i+1])||y3>y&&ci<Palette.RGBSum(Data[i-Width])||y3<y2&&ci<Palette.RGBSum(Data[i+Width]))
              Data[i]|=c24;
          }
				for(int y3=y;y3<=y2;y3++)
				  for(int i=y3*Width+x,i0=i,ie=i+x2-x+1;i<ie;i++) 
            if(0!=(Data[i]&c24))
              Data[i]=Black;
            else if(white) Data[i]=White;        
      }
      public static int Blur(int c,int c0,int c1,int c2,int c3,int d0,int d1,int d2,int d3) {
        int r,g,b;
        r=(32*(c&255)+5*((c0&255)+(c1&255)+(c2&255)+(c3&255))+3*((d0&255)+(d1&255)+(d2&255)+(d3&255)))/64;
        g=((32*(c&0xff00)+5*((c0&0xff00)+(c1&0xff00)+(c2&0xff00)+(c3&0xff00))+3*((d0&0xff00)+(d1&0xff00)+(d2&0xff00)+(d3&0xff00)))/64)&0xff00;
        b=((32*(c&0xff0000)+5*((c0&0xff0000)+(c1&0xff0000)+(c2&0xff0000)+(c3&0xff0000))+3*((d0&0xff0000)+(d1&0xff0000)+(d2&0xff0000)+(d3&0xff0000)))/64)&0xff0000;
        return r|g|b|(c&(255<<24));
      }
      public void Filter(int x0,int y0,int x1,int y1,bool closed,int mode) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,1,1,Width-2,Height-2)) return;
        if(x0>x1||y0>y1) return;
        int[] line=new int[2*Width];
        int g,w=x1-x0+1,x,idx;
        bool even=false;        
        for(int y=y0;y<=y1;y++) {
          g=even?Width:0;
          for(x=0,idx=y*Width+x0;x<w;x++,idx++) {
            int c=Data[idx],c0=Data[idx-1],c1=Data[idx+1],c2=Data[idx-Width],c3=Data[idx+Width];
            int d0=Data[idx-Width-1],d1=Data[idx-Width+1],d2=Data[idx+Width-1],d3=Data[idx+Width+1];
            if(closed) {
              if(x==0) c0=d0=d2=c;
              if(x==w-1) c1=d1=d3=c;
              if(y==y0) c2=d0=d1=c;
              if(y==y1) c3=d2=d3=c;
            }
            line[g++]=Blur(c,c0,c1,c2,c3,d0,d1,d2,d3);
          }
          g=even?0:Width;
          if(y>y0) for(x=0,idx=(y-1)*Width+x0;x<w;x++,idx++) Data[idx]=line[g+x];
          g=even?0:Width;
          even^=true;
        }
        g=even?0:Width;
        idx=y1*Width+x0;
        for(x=0;x<w;x++,idx++) Data[idx]=line[g+x];
      }
      public void RGB2CMY(bool inv) {
        if(Data!=null) for(int i=0;i<Data.Length;i++) Data[i]=Palette.RGB2CMY(Data[i],inv);
      }
      public void RGB2CMY(int x0,int y0,int x1,int y1,bool inv) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int idx=y0*Width+x0;
          for(int x=x0;x<=x1;x++,idx++)
            Data[idx]=Palette.RGB2CMY(Data[idx],inv);
          y0++;
        }
      }
      public void RGBShift(int mode) {
        if(Data!=null) for(int i=0;i<Data.Length;i++) Data[i]=Palette.RGBShift(mode,Data[i]);
      }
      public void RGBShift(int mode,int x0,int y0,int x1,int y1) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        while(y0<=y1) {
          int idx=y0*Width+x0;
          for(int x=x0;x<=x1;x++,idx++)
            Data[idx]=Palette.RGBShift(mode,Data[idx]);          
          y0++;
        }
      }
      public void C4(int c00,int c01,int c10,int c11,int x0,int y0,int x1,int y1) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);        
        int y2=0,w=x1-x0,h=y1-y0;
        while(y0<=y1) {
          int idx=y0*Width+x0;
          int c0=Palette.RGBMix(c00,c10,y2,h),c1=Palette.RGBMix(c01,c11,y2,h);
          for(int x=x0,x2=0;x<=x1;x++,idx++,x2++) {
            int c=Palette.RGBMix(c0,c1,x2,w);
            Data[idx]=c;
/*            if(ccc>=0) {
              int y3=y2==0?0:y2*w/h;
              int scc=sqr(w/2-x2,w/2-y3);
              if(4*scc<sqr(w))
                c=Palette.RGBMix(ccc,c,2*isqrt(scc),w);
            }*/
           /*else {
            int y3=y2==0?0:y2*w/h;
            for(int x=x0,x2=0;x<=x1;x++,idx++,x2++) {
              int div=32;
              //int s00=256*w*h/(1+w*h/div+sqr(x2,y2*w/h)),s01=256*w*h/(1+w*h/div+sqr(w-x2,y2*w/h)),s10=256*w*h/(1+w*h/div+sqr(x2,w-y2*w/h)),s11=256*w*h/(1+w*h/div+sqr(w-x2,w-y2*w/h)),scc=256*w*h/(1+w*h/div+sqr(w/2-x2,w/2-y2*w/h));
              int s00=sqr(x2,y3);s00=4*s00<sqr(w,w)?sqr(w-isqrt(2*s00)):0;
              int s01=sqr(w-x2,y3);s01=4*s01<sqr(w,w)?sqr(w-isqrt(2*s01)):0;
              int s10=sqr(x2,w-y3);s10=4*s10<sqr(w,w)?sqr(w-isqrt(2*s10)):0;
              int s11=sqr(w-x2,w-y3);s11=4*s11<sqr(w,w)?sqr(w-isqrt(2*s11)):0;
              int scc=sqr(w/2-x2,w/2-y3);scc=4*scc<sqr(w,w)?sqr(w-isqrt(2*scc)):0;
              int s0=0,s1=0,s2=0;
              Palette.RGBAdd(c00,s00,ref s0,ref s1,ref s2);
              Palette.RGBAdd(c01,s01,ref s0,ref s1,ref s2);
              Palette.RGBAdd(c10,s10,ref s0,ref s1,ref s2);
              Palette.RGBAdd(c11,s11,ref s0,ref s1,ref s2);
              Palette.RGBAdd(ccc,scc,ref s0,ref s1,ref s2);
              Data[idx]=Palette.RGBAvg(s00+s01+s10+s11+scc,s0,s1,s2);*/
            /*int dy=abs(2*y2-h);
            for(int x=x0,x2=0;x<=x1;x++,idx++,x2++) {
              int dx=abs(2*x2-w),a,d,c0;
              if(dx*h<dy*w) {
                a=dy;d=h;c0=2*y2<h?Palette.RGBMix(c00,c01,w*dy+(2*x2-w)*h,2*w*dy):Palette.RGBMix(c10,c11,w*dy+(2*x2-w)*h,2*w*dy);
              } else {
                a=dx;d=w;c0=2*x2<w?Palette.RGBMix(c00,c10,h*dx+(2*y2-h)*w,2*h*dx):Palette.RGBMix(c01,c11,h*dx+(2*y2-h)*w,2*h*dx);
              }
              Data[idx]=Palette.RGBMix(ccc,c0,a,d);
            */            
          }
          y0++;y2++;
        }
      }

      public void Average(bool hor,bool ver,int x0,int y0,int x1,int y1) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1)) return;
        int[] v=ver&&hor?new int[3*(x1-x0+1)]:null;
        int idx,s0=0,s1=0,s2=0,nx=x1-x0+1,ny=y1-y0+1,c;
        if(ver||!hor) {          
          for(int x=x0;x<=x1;x++,idx++) { 
            idx=y0*Width+x;
            if(ver) s0=s1=s2=0;
            for(int y=y0;y<=y1;y++,idx+=Width)
              Palette.RGBAdd(Data[idx],ref s0,ref s1,ref s2);
            if(v!=null) { idx=3*(x-x0);v[idx++]=s0;v[idx++]=s1;v[idx++]=s2;}
            else if(ver)
              VLine(x,y0,y1,Palette.RGBAvg(ny,s0,s1,s2));
          }
        }
        if(!hor) {
          if(!ver) FillRectangle(x0,y0,x1,y1,Palette.RGBAvg(nx*ny,s0,s1,s2));
          return;
        }
        for(int y=y0;y<=y1;y++) {
          idx=y*Width+x0;
          if(hor) s0=s1=s2=0;
          for(int x=x0;x<=x1;x++,idx++) 
            Palette.RGBAdd(Data[idx],ref s0,ref s1,ref s2);
          if(v!=null) {
            idx=y*Width+x0;
            for(int x=x0,i=0;x<=x1;x++,idx++,i+=3)
              Data[idx]=Palette.RGBAvg(nx+ny,s0+v[i],s1+v[i+1],s2+v[i+2]);
          } else if(hor)
            HLine(x0,x1,y,Palette.RGBAvg(nx,s0,s1,s2));
        }
      }

      public void Pixels(int size,int x0,int y0,int x1,int y1) {
        if(size<2||!IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1)) return;
        for(int y=y0,y2;y<=y1;y=y2) {
          y2=(y+size)/size*size;
          if(y2>y1+1) y2=y1+1;
          for(int x=x0,x2;x<=x1;x=x2) {
            x2=(x+size)/size*size;
            if(x2>x1+1) x2=x1+1;
            Average(false,false,x,y,x2-1,y2-1);
          }
        }
      }

      static readonly byte[] matrix={
    0,192,48,240,12,204,60,252,3,195,51,243,15,207,63,255,
    128,64,176,112,140,76,188,124,131,67,179,115,143,79,191,127,
    32,224,16,208,44,236,28,220,35,227,19,211,47,239,31,223,
    160,96,144,80,172,108,156,92,163,99,147,83,175,111,159,95,
    8,200,56,248,4,196,52,244,11,203,59,251,7,199,55,247,
    136,72,184,120,132,68,180,116,139,75,187,123,135,71,183,119,
    40,232,24,216,36,228,20,212,43,235,27,219,39,231,23,215,
    168,104,152,88,164,100,148,84,171,107,155,91,167,103,151,87,
    2,194,50,242,14,206,62,254,1,193,49,241,13,205,61,253,
    130,66,178,114,142,78,190,126,129,65,177,113,141,77,189,125,
    34,226,18,210,46,238,30,222,33,225,17,209,45,237,29,221,
    162,98,146,82,174,110,158,94,161,97,145,81,173,109,157,93,
    10,202,58,250,6,198,54,246,9,201,57,249,5,197,53,245,
    138,74,186,122,134,70,182,118,137,73,185,121,133,69,181,117,
    42,234,26,218,38,230,22,214,41,233,25,217,37,229,21,213,
    170,106,154,90,166,102,150,86,169,105,153,89,165,101,149,85,
  };
      public static int Matrix(int color,int x,int y,bool rgb,int level) {
        int off=((y&15)<<4)|(x&15),m=matrix[off];
        if(rgb) {
          int r=color&255,g=(color>>8)&255,b=(color>>16)&255;
          if(level<2) {          
            r=r>m||r==255?255:0;
            g=g>m||g==255?255:0;
            b=b>m||b==255?255:0;
          } else {
            r=Palette.Matrix(r,m,level);
            g=Palette.Matrix(g,m,level);
            b=Palette.Matrix(b,m,level);
          }
          return r|(g<<8)|(b<<16);
        } else {
          int s=Palette.RGBSum2(color);
          if(level<2)
            return s==765||s>3*m?White:Black;
          return 0x10101*Palette.Matrix((s+1)/3,m,level);
        }
      }
      public void Matrix(int x0,int y0,int x1,int y1,bool rgb,bool abs,int level) {
        IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1);
        int y2=abs?y0:0;
        while(y0<=y1) {
          int idx=y0*Width+x0;
          for(int x=x0,x2=abs?x:0;x<=x1;x++,idx++,x2++)
            Data[idx]=Matrix(Data[idx],x2,y2,rgb,level);
          y0++;y2++;
        }
      }
      public void Diffuse(int x0,int y0,int x1,int y1,bool rgb,int level) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1)) return;
        int width=x1-x0,ph,ep,eb,eb0,eb1,eb2,e,e0,e1,e2,de,de3;
        if(rgb) {
          int[] emem=new int[3*(width+2)];
          while(y0<=y1) {
            ph=y0*Width+x0;
            ep=3;emem[0]=emem[1]=emem[2]=eb0=eb1=eb2=e0=e1=e2=0;
            for(int x=x0;x<=x1;x++,ph++,ep+=3) {
              int c=Data[ph],c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255;
              e0+=emem[ep]+c0;e1+=emem[ep+1]+c1;e2+=emem[ep+2]+c2;
              if(level>2) {                
                c0=Palette.RGBLevel1(e0,level);e0-=c0;
                c1=Palette.RGBLevel1(e1,level);e1-=c1;
                c2=Palette.RGBLevel1(e2,level);e2-=c2;
              } else {
                if(e0>127) e0-=(c0=255);else c0=0;
                if(e1>127) e1-=(c1=255);else c1=0;
                if(e2>127) e2-=(c2=255);else c2=0;
              }
              Data[ph]=c0|(c1<<8)|(c2<<16);
              de3=e0/3;de=de3/3;
              emem[ep-3]+=de;emem[ep]=eb0+de3;
              e0-=de+de3+de;eb0=de;
              de3=e1/3;de=de3/3;
              emem[ep-2]+=de;emem[ep+1]=eb1+de3;
              e1-=de+de3+de;eb1=de;
              de3=e2/3;de=de3/3;
              emem[ep-1]+=de;emem[ep+2]=eb2+de3;
              e2-=de+de3+de;eb2=de;
            }
            y0++;
          }

        } else {
          int[] emem=new int[width+2];          
          while(y0<=y1) {
            ph=y0*Width+x0;
            ep=1;emem[0]=eb=e=0;
            for(int x=x0;x<=x1;x++,ph++,ep++) {
              int s=Palette.RGBSum(Data[ph]);
	            e+=emem[ep]+s;
	            if(e>382) {e-=765;s=White;} else s=0;
              Data[ph]=s;
	            de=e/9;
	            emem[ep-1]+=de;
	            de3=e/3;
	            emem[ep]=eb+de3;
	            e-=de+de3+de;
	            eb=de;
            }
            y0++;
          }
        }
      }
      public void Diffuse(int x0,int y0,int x1,int y1,int n,int[] pal) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1)) return;
        int width=x1-x0,ph,ep,eb0,eb1,eb2,e0,e1,e2,de,de3;
        int[] emem=new int[3*(width+2)];
          while(y0<=y1) {
            ph=y0*Width+x0;
            ep=3;emem[0]=emem[1]=emem[2]=eb0=eb1=eb2=e0=e1=e2=0;
            for(int x=x0;x<=x1;x++,ph++,ep+=3) {
              int c=Data[ph],c0=c&255,c1=(c>>8)&255,c2=(c>>16)&255;
              e0+=emem[ep]+c0;e1+=emem[ep+1]+c1;e2+=emem[ep+2]+c2;
              c=pal[Palette.search(e0,e1,e2,n,pal)];
              Data[ph]=c;
              e0-=c&255;e1-=(c>>8)&255;e2-=(c>>16)&255;              
              de3=e0/3;de=de3/3;emem[ep-3]+=de;emem[ep]=eb0+de3;e0-=de+de3+de;eb0=de;
              de3=e1/3;de=de3/3;emem[ep-2]+=de;emem[ep+1]=eb1+de3;e1-=de+de3+de;eb1=de;
              de3=e2/3;de=de3/3;emem[ep-1]+=de;emem[ep+2]=eb2+de3;e2-=de+de3+de;eb2=de;
            }
            y0++;
          }
      }
      public void Nearest(int x0,int y0,int x1,int y1,int n,int[] pal,int mode) {
        if(!IntersectRect(ref x0,ref y0,ref x1,ref y1,0,0,Width-1,Height-1)) return;
        while(y0<=y1) {
          for(int x=x0,idx=y0*Width+x0;x<=x1;x++,idx++)
            Data[idx]=pal[Palette.search(Data[idx],n,pal,mode)];
        }
      }
      
      public void Line(int x0,int y0,int x1,int y1,int color,bool whiteonly) {
        int r;
        if((x0<x1?x0>=Width||x1<0:x1>=Width||x0<0)||(y0<y1?y0>=Height||y1<0:y1>=Height||y0<0)) return;
        int dx=x1-x0,dy=y1-y0;
        if(dx<0) dx=-dx;if(dy<0) dy=-dy;
        int d=dx>dy?dx:dy;
        if(d==0) {XY(x0,y0,color,whiteonly);return;}
        dx=x1-x0;dy=y1-y0;
        for(int i=0;i<=d;i++) {
          int x=(d+2*(d*x0+i*dx))/d/2,y=(d+2*(d*y0+i*dy))/d/2;
          if(x>=0&&y>=0&&x<Width&&y<Height) {
            if(!whiteonly||(Data[y*Width+x]&0xffffff)==White)
              Data[y*Width+x]=color;
          }
        }
           
      }
/*      public int FillSide(int x,int y,int x0,int y0,int x1,int y1) {
        if(y0<y&&y1<y||y0>y&&y1>y||y0==y1) return 0;
        int x2=x0+(x1-x0)*(y-y0)/(y1-y0);
        return x2<x?y==y0?y1>y0?1:0:y==y1?y0>y1?1:0:1:0;
      }*/
      public void FillPath(List<int> path,int dx,int dy,int color,int cmode) {
        int[] p=new int[path.Count];
        for(int i=0;i<p.Length;i+=2) {p[i]=path[i]+dx;p[i+1]=path[i+1]+dy;}
        FillPath(p,color,cmode);
      }
      public void FillPath(int[] p,int color,int cmode) {
        int ix=p[0],iy=p[1],ax=p[0],ay=p[1];
        for(int i=0;i<p.Length;i+=2) {
          if(p[i]<ix) ix=p[i];else if(p[i]>ax) ax=p[i];
          if(p[i+1]<iy) iy=p[i+1];else if(p[i+1]>ay) ay=p[i+1];
        }
        if(ix>=Width||iy>=Height||ax<0||ay<0) return;
        if(ix<0) ix=0;if(iy<0) iy=0;
        if(ax>=Width) ax=Width-1;if(ay>=Height) ay=Height-1;
        int[] xa=new int[p.Length];
        bool[] ha=new bool[p.Length];
        for(int y=iy;y<=ay;y++) {
          int x1=p[p.Length-2],y1=p[p.Length-1],x2,y2;
          for(int i=0;i<p.Length;i+=2) {
            x2=x1;y2=y1;
            x1=p[i];y1=p[i+1];
            ha[i]=y1<y&&y2<y||y1>y&&y2>y||y1==y2;
            if(ha[i]) continue;
            int fx=x2-x1,fy=y2-y1;
            if(fx<0) fx=-fx;if(fy<0) fy=-fy;            
            int d=fx>fy?fx:fy,e=y2<y1?y1-y:y-y1;
            xa[i]=1+2*x1+2*(x2-x1)*e/fy;
          }        
          for(int x=ix;x<=ax;x++) {
            int n=0;
            x1=p[p.Length-2];y1=p[p.Length-1];
            for(int i=0;i<p.Length;i+=2) {
              x2=x1;y2=y1;
              x1=p[i];y1=p[i+1];
              if(ha[i]) continue;
              int r=xa[i]<=2*x?y==y1?y2>y1?1:0:y==y2?y1>y2?1:0:1:0;
              //int r=FillSide(x,y,x1,y1,x2,y2);
              n+=r;
            }
            if(0!=(n&1))
              Data[Width*y+x]=cmode>0?Palette.Colorize(cmode,color,Data[Width*y+x]):color;
          }
        }
      }
      public void BrushLine(int x0,int y0,int x1,int y1,int color,bmap brush,bool whiteonly) {
        BrushLine(x0,y0,x1,y1,color,brush,whiteonly,null,0);
      }
      public void BrushLine(int x0,int y0,int x1,int y1,int color,bmap brush,bool whiteonly,float[] dash,float dashoff) {
        if(brush==null) {
          if(dash==null) {
            Line(x0,y0,x1,y1,color,whiteonly);
            return;
          }
          brush=new bmap(1,1);
          brush.Data[0]=1;
        }
        int r;
        int bx=brush.Width/2,by=brush.Height/2;
        if((x0<x1?x0>=Width+brush.Width||x1<-brush.Width:x1>=Width+brush.Width||x0<-brush.Width)||(y0<y1?y0>=Height+brush.Height||y1<-brush.Height:y1>=Height+brush.Height||y0<-brush.Height)) return;
        int dx=x1-x0,dy=y1-y0;
        if(dx<0) dx=-dx;if(dy<0) dy=-dy;
        int d=dx>dy?dx:dy;
        if(d==0) {Brush(x0,y0,color,brush,whiteonly);return;}
        dx=x1-x0;dy=y1-y0;
        int patx=x0,paty=y0;
        float pattlen=dash==null?0:dash[dash.Length-1];
        for(int i=0;i<=d;i++) {
          //int x=x0+i*dx/d,y=y0+i*dy/d;
          int x=(d+2*(d*x0+i*dx))/d/2,y=(d+2*(d*y0+i*dy))/d/2;
          if(dash!=null) {
            float pi=(float)((dashoff+Math.Sqrt(sqr(x0-x,y0-y)))%pattlen);
            int p=0;
            while(p<dash.Length&&pi>=dash[p]) p++;
            if(0==(p&1))
              Brush(x,y,color,brush,whiteonly);
          } else
            Brush(x,y,color,brush,whiteonly);
        }
      }
      public void BrushQArc(int x0,int y0,int radius,bool px,bool py,bool vertical,int color,bmap brush,bool whiteonly) {
        int x1=x0+radius*(px?1:-1),y1=y0+radius*(py?-1:1);
        int bw=brush==null?1:brush.Width,bh=brush==null?1:brush.Height;
        int bx=bw/2,by=bh/2;
        if((x0<x1?x0>=Width+bw||x1<-bw:x1>=Width+bw||x0<-bw)||(y0<y1?y0>=Height+bh||y1<-bh:y1>=Height+bh||y0<-bh)) return;
        int dx=x1-x0,dy=y1-y0;
        if(dx<0) dx=-dx;if(dy<0) dy=-dy;
        int d=dx>dy?dx:dy;
        if(d==0) {Brush(x0,y0,color,brush,whiteonly);return;}
        dx=x1-x0;dy=y1-y0;
        for(int i=0;i<=2*radius;i++) {
          double a=i*Math.PI/radius/4,si=0.5+radius*Math.Sin(a),co=0.5+radius*Math.Cos(a);
          int x,y;
          if(vertical) {x=radius-(int)co;y=(int)si;} else {x=(int)si;y=radius-(int)co;}
          x=x0+x*(px?1:-1);y=y0+y*(py?1:-1);
          if(brush==null) XY(x,y,color,whiteonly);
          Brush(x,y,color,brush,whiteonly);
        }
      }
      public bmap Extend(int x0,int y0,int x1,int y1,int color,bool border) {
        R.Norm(ref x0,ref y0,ref x1,ref y1);
        if(x0>0) x0=0;if(y0>0) y0=0;
        if(x1<Width-1) x1=Width-1;if(y1<Height-1) y1=Height-1;
        if(x0==0&&y0==0&&x1==Width-1&&y1==Height-1) return null;        
        int w=x1-x0+1,h=y1-y0+1;
        if(w>16384||h>16384||w*h>64*1048576) return null;
        bmap dst=new bmap(w,h);
        dst.Clear(color);
        if(border) dst.CopyRectangle(this,1,1,Width-2,Height-2,1-x0,1-y0,-1);
        else dst.CopyRectangle(this,0,0,Width,Height,-x0,-y0,-1);
        return dst;        
      }
      public void Morph(bmap source,int[] pts) {
        int s1=sabs(pts[2]-pts[0],pts[3]-pts[1]),s2=sabs(pts[8]-pts[2],pts[9]-pts[3]);
        int s3=sabs(pts[6]-pts[4],pts[7]-pts[5]),s4=sabs(pts[0]-pts[6],pts[1]-pts[7]);
        int s5=sabs(pts[4]-pts[0],pts[5]-pts[1]),s6=sabs(pts[6]-pts[2],pts[7]-pts[3]);
        int d1=sabs(pts[10]-pts[8],pts[11]-pts[9]),d2=sabs(pts[12]-pts[10],pts[13]-pts[11]);
        int d3=sabs(pts[14]-pts[12],pts[15]-pts[13]),d4=sabs(pts[8]-pts[14],pts[9]-pts[15]);
        int d5=sabs(pts[12]-pts[8],pts[13]-pts[9]),d6=sabs(pts[14]-pts[10],pts[15]-pts[11]);                
        if(d3>d1) d1=d3;if(d4>d2) d2=d4;if(d6>d5) d5=d6;if(d3>d1) d1=d3;if(d5>d1) d1=d5;
        if(s3>s1) s1=s3;if(s4>s2) s2=s4;if(s6>s5) s5=s6;if(s3>s1) s1=s3;if(s5>s1) s1=s5;
        if(s1>d1) d1=s1;
        int n1=32,n=(d1+n1)&~(n1-1),n2=n/n1,n22=n2/2;
        int[] count=new int[Data.Length];
        for(int y0=0,y1=n;y1>=0;y0++,y1--)
          for(int x0=0,x1=n;x1>=0;x0++,x1--) {
            int dxa=(x1*pts[8]+x0*pts[10])/n1,dxb=(x1*pts[14]+x0*pts[12])/n1,dx=((y1*dxa+y0*dxb)/n+n22)/n2;
            int dya=(x1*pts[9]+x0*pts[11])/n1,dyb=(x1*pts[15]+x0*pts[13])/n1,dy=((y1*dya+y0*dyb)/n+n22)/n2;
            if(dx<0||dy<0||dx>=Width||dy>=Height) continue;
            int sxa=(x1*pts[0]+x0*pts[2])/n1,sxb=(x1*pts[6]+x0*pts[4])/n1,sx=(y1*sxa+y0*sxb)/n;
            int sya=(x1*pts[1]+x0*pts[3])/n1,syb=(x1*pts[7]+x0*pts[5])/n1,sy=(y1*sya+y0*syb)/n;
            dx=dy*Width+dx;
            int c=count[dx],color=source.Color(n2,sx,sy);
            if(color<0) continue;
            if(c>0) color=Palette.RGBMix(color,Data[dx],1,c);
            count[dx]=c+1;
            Data[dx]=color;
          }
      }
      public int Color(int div,int x,int y) {
        if(x<0||y<0) return -1;
        int px=x/div,py=y/div,cx=x-div*px,cy=y-div*py;
        if(px>=Width-1||py>=Height-1) return -1;
        int i=py*Width+px;
        int c0=Data[i],c1=Data[i+1],c2=Data[i+Width],c3=Data[i+Width+1];
        int dx=div-cx,dy=div-cy;
        int e0=dx*dy,e1=cx*dy,e2=dx*cy,e3=cx*cy;
        div=div*div;
        int r=(e0*(c0&255)+e1*(c1&255)+e2*(c2&255)+e3*(c3&255))/div;
        int g=(e0*((c0>>8)&255)+e1*((c1>>8)&255)+e2*((c2>>8)&255)+e3*((c3>>8)&255))/div;
        int b=(e0*((c0>>16)&255)+e1*((c1>>16)&255)+e2*((c2>>16)&255)+e3*((c3>>16)&255))/div;
        return (r&255)|(g<<8)|(b<<16);
      }
    }
				public struct PathPoint {
		  public int x,y;
			public bool stop;
			public PathPoint(int X,int Y,bool Stop) { x=X;y=Y;stop=Stop;}
			public PathPoint(int X,int Y) { x=X;y=Y;stop=false;}
			public PointPath List() { PointPath l=new PointPath();l.Add(this);return l;}
		  public override string ToString() { return ""+x+","+y+(stop?",O":"")+"";}
	  }
    public class FillPattern {
      public bmap BMap;
      public int X,Y,TrColor;
      public bool MX,MY,HX,HY;
      public bool Enabled;

      public FillPattern(int trcolor) { TrColor=trcolor;}

      public int Color(int x,int y) {
         int rx,ry,rc;
         x-=X;y-=Y;
         ry=bmap.modp(y,2*BMap.Height);
         rx=bmap.modp(x,2*BMap.Width);
         if(HX&&ry>=BMap.Height) { rx+=BMap.Width/2;if(rx>=2*BMap.Width) rx-=2*BMap.Width;}
         if(HY&&rx>=BMap.Width) { ry+=BMap.Height/2;if(ry>=2*BMap.Height) ry-=2*BMap.Height;}
         if(rx>=BMap.Width) rx=MX?2*BMap.Width-1-rx:rx-BMap.Width;
         if(ry>=BMap.Height) ry=MY?2*BMap.Height-1-ry:ry-BMap.Height;
         rc=BMap.Data[BMap.Width*ry+rx]&bmap.White;
         return rc==TrColor?-1:rc;
      }
    }
		public class PointPath {
		  public PathPoint[] pt=new PathPoint[16];
			public int Count;
			public bool Closed;
			public void Add(int x,int y) { Add(new PathPoint(x,y));}
			public void Add(PathPoint pp) {
			  if(Count==pt.Length) Array.Resize(ref pt,Count*2);
				pt[Count++]=pp;
			}
			public void SetStop() {if(Count>0) {			  
			  PathPoint pp=pt[Count-1];
				pp.stop=true;
			  pt[Count-1]=pp;
			  } else Closed=true;
			}
			public PathPoint this[int index] { get {return pt[index];} set {pt[index]=value;}}
			public void Clear() {Count=0;Closed=false;}
      public int X { get {return Count<1?int.MaxValue:pt[0].x;}}
      public int Y { get {return Count<1?int.MaxValue:pt[0].y;}}

		}

    public static class R {
      public static int[] Copy(int[] rect) { return rect==null?null:rect.Clone() as int[];}
      public static int Width(int[] rect) { return Math.Abs(rect[2]-rect[0])+1;}
      public static int Height(int[] rect) { return Math.Abs(rect[3]-rect[1])+1;}
      public static bool IsPoint(int[] rect) { return rect[0]==rect[2]&&rect[1]==rect[3];}
      public static bool Intersected(int[] rect,int x,int y,int x2,int y2) {
        return !(x>rect[2]||x2<rect[0]||y>rect[3]||y2<rect[1]);
      }      
      public static void Union(int[] rect,int x,int y,int x2,int y2) {
        if(x<rect[0]) rect[0]=x;if(x2>rect[2]) rect[2]=x2;
        if(y<rect[1]) rect[1]=y;if(y2>rect[3]) rect[3]=y2;
      }
      public static void Union(int[] rect,int[] r) { Union(rect,r[0],r[1],r[2],r[3]);}
      public static bool Union(ref int l,ref int t,ref int r,ref int b,int x,int y) { return Union(ref l,ref t,ref r,ref b,x,y,x,y);}
      public static bool Union(ref int l,ref int t,ref int r,ref int b,int x,int y,int x2,int y2) {
        if(x<l) l=x;if(x2>r) r=x2;
        if(y<t) t=y;if(y2>b) b=y2;
        return true;
      }      
      public static bool Intersect(int[] rect,int x,int y,int x2,int y2) {
        if(x>rect[2]||x2<rect[0]||y>rect[3]||y2<rect[1]) return false;
        if(x>rect[0]) rect[0]=x;if(x2<rect[2]) rect[2]=x2;
        if(y>rect[1]) rect[1]=y;if(y2<rect[3]) rect[3]=y2;
        return true;
      }
      public static bool Intersect(ref int x,ref int y,ref int x2,ref int y2,int xa,int ya,int xb,int yb) {
        if(x>xb||x2<xa||y>yb||y2<ya) return false;
        if(xa>x) x=xa;if(xb<x2) x2=xb;
        if(ya>y) y=ya;if(yb<y2) y2=yb;        
        return true;
      }
      public static void Norm(int[] rect) {
        if(rect==null) return;
        int r;
        if(rect[0]>rect[2]) {r=rect[0];rect[0]=rect[2];rect[2]=r;}
        if(rect[1]>rect[3]) {r=rect[1];rect[1]=rect[3];rect[3]=r;}
      }
      public static void Norm(ref int x,ref int y,ref int x2,ref int y2) {
        int r;
        if(x>x2) {r=x;x=x2;x2=r;}
        if(y>y2) {r=y;y=y2;y2=r;}
      }      
			public static bool Inside(int[] rect,int x,int y) {			  
			  return rect[0]<=x&&x<=rect[2]&&rect[1]<=y&&y<=rect[3];
			}
			public static bool Inside(int[] rect,int x,int y,int x2,int y2) {			  
			  return rect[0]>=x&&rect[2]<=x2&&rect[1]>=y&&rect[3]<=y2;
			}
			public static void Shift(int[] rect,int dx,int dy) {
        if(rect==null) return;
			  rect[0]+=dx;rect[1]+=dy;
				rect[2]+=dx;rect[3]+=dy;
			}

    }
}
